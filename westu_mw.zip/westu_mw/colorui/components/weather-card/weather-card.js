// components/weather-card/weather-card.js

Component({
  lifetimes: {
    attached() {
      this.getWeather()
    }
  },

  options: {
    addGlobalClass: true
  },

  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    // 所在城市
    city: "",
    // 获取到的天气信息
    weather: null,
    // 默认天气类别
    weatherClass: '',
    // 未来五日天气显示boolean
    showMoreForecast: false,
  },

  /**
   * 组件的方法列表
   */
  methods: {
    /* 显示未来五日预报 */
    showMoreForecast() {
      wx.navigateTo({
        url: '/pages/more/weather'
      })
      // this.setData({
      //   showMoreForecast: !this.data.showMoreForecast
      // })
    },
    /* 获取天气信息 */
    getWeather: function() {
      var that = this;
      this.setData({
        city: '金平'
      })

      wx.request({
        url: 'https://free-api.heweather.com/s6/weather',
        method: 'GET',
        data: {
          key: "bff5cc9bcfdf46b0a0e9bf0c260ff14f",
          location: "CN101280506",
          lang: "zh",
          unit: "m"
        },
        success: function(res) {
          var wendu = res.data.HeWeather6[0].now.tmp;
          var type = res.data.HeWeather6[0].now.cond_txt;
          var low = res.data.HeWeather6[0].daily_forecast[0].tmp_min;
          var high = res.data.HeWeather6[0].daily_forecast[0].tmp_max;
          var r = Math.floor(Math.random() * 6); 
          var tips = res.data.HeWeather6[0].lifestyle[r]['txt'];   
          that.setData({
            weather: {
              wendu : wendu,
              type: type,
              low: low,
              high: high,
              tips: tips,
            }
          });

          // /* 设置弹出框内容 */
          // for (var i = 0; i < 5; i++) {
          //   var str1 = 'actions[' + i + '].subname';
          //   var str2 = 'actions[' + i + '].name';
          //   that.setData({
          //     [str1]: that.data.weather.forecast[i].date,
          //     [str2]: '「' + that.data.weather.forecast[i].type + '」' + that.data.weather.forecast[i].low + ' ' + that.data.weather.forecast[i].high
          //   });
          // }
          if (type.indexOf('晴') != -1) {
            let now = new Date();
            let hour = now.getHours();
            let seconds = now.getSeconds();
            if (hour > 6 && hour < 19) {
              that.setData({
                weatherClass: seconds % 2 == 0 ? 'sunny' : 'rainbow'
              });
            } else {
              that.setData({
                weatherClass: 'starry'
              });
            }
          } else if (type.indexOf('雷') != -1 || type.indexOf('电') != -1 || type.indexOf('暴') != -1) {
            that.setData({
              weatherClass: 'stormy'
            });
          } else if (type.indexOf('雪') != -1 || type.indexOf('霜') != -1 || type.indexOf('冰') != -1) {
            that.setData({
              weatherClass: 'snowy'
            });
          } else if (type.indexOf('雨') != -1) {
            that.setData({
              weatherClass: 'rainy'
            });
          } else if (type.indexOf('阴') != -1 || type.indexOf('云') != -1) {
            that.setData({
              weatherClass: 'cloudy'
            });
          }
        }
      })
    },

    
  }
})