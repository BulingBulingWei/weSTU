// pages/login/login.js
const app = getApp();
const Tools = require('../../utils/common.js');
const KB = require('../../utils/toKb.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    TabCur: 0,
    scrollLeft: 0,
    swiperList:[],
    iconList: [{
      icon: 'similar',
      color: '#4C83FF',
      badge: 0,
      name: '我要蹭课',
      url: '../core/ck/ck'
    }, {
      icon: 'calendar',
      color: '#ff0844',
      badge: 0,
      name: '我的校历',
      url: '../core/xl/xl'
    }, {
      icon: 'list',
      color: '#330867',
      badge: 0,
      name: '考试安排',
      url: '../core/ks/ks'
    }, {
      icon: 'font',
      color: '#8baaaa',
      badge: 0,
      name: '成绩查询',
      url: '../core/cj/cj'
    }, {
      icon: 'friend',
      color: '#0fd850',
      badge: 0,
      name: '课程评价',
      url: '../core/ping/list'
    }, {
      icon: 'news',
      color: '#50c9c3',
      badge: 0,
      name: '一卡通',
      url: '../core/ykt/ykt'
    }, {
      icon: 'creative',
      color: '#0c3483',
      badge: 0,
      name: '水电费',
      url: '../core/sdf/sdf'
    }, {
      icon: 'subscription',
      color: '#f7b79c',
      badge: 0,
      name: '校园网',
      url: '../core/wifi/wifi'
    }, {
      icon: 'read',
      color: '#ff758c',
      badge: 0,
      name: '图书馆',
      url: '../core/lib/menu'
    }, {
      icon: 'tag',
      color: 'gray',
      badge: 0,
      name: '二手交易',
      url: '../core/run/run'
    }],
    card: {
      'ks': {
        show: false,
        data: {}
      },
      'kb': {
        show: false,
        data: {},
        today: true
      },
      'ykt': {
        show: false,
        data: {
          'last_time': '',
          'balance': 0,
          'cost_status': false,
          'today_cost': {
            value: '',
            total: 0
          }
        }
      },
      'oa':{
        show: false,
        data:[]
      }
    },
    gridCol: 5,
    remind: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log('options0', options,app)
    //提前加载
    this.initSwiper();//加载海报
    if (app.user.is_bind) {
      console.log('getCard')
      if (app.user.status == 'stu') {
        this.setData({
          stu: true
        })
      } else {
        this.setData({
          stu: false
        })
      }
      this.getCard();//加载卡片
    }

    if(options.action == 'reLogin'){
      wx.setStorageSync('version', app.version)
      var data = wx.getStorageInfoSync();
      if (data && data.keys.length) {
        data.keys.forEach(function (key) {
          var value = wx.getStorageSync(key);
          if (value) {
            app.cache[key] = value;
          }
        });
        if (!app.empty(app.cache.user)) app.user = app.cache.user;
        if (!app.empty(app.cache.wx)) app.wx = app.cache.wx;
        if (!app.empty(app.cache.design)) app.design = app.cache.design;
      }
      console.log('app.cache', app.cache)
      /**获取当前屏幕信息 */
      wx.getSystemInfo({
        success: e => {
          console.log('sysInfo', e)
          app.globalData.StatusBar = e.statusBarHeight;
          app.globalData.CustomBar = e.platform == 'android' ? e.statusBarHeight + 50 : e.statusBarHeight + 45;
          app.globalData.CustomHeight = e.windowHeight;
          app.globalData.CustomWidth = e.windowWidth;
        }
      })
      //获取当前时间
      var timestamp = Date.parse(new Date());
      app.time = Tools.GetTime(timestamp, app.globalData.xn_start);
      
    }
    //lalala
    if (options.from == 'wetrack'){
      app.saveCache('from','wetrack');
    }else if (options.do == '1') {
      this.setData({
        reload: true
      })
    } else if (options.id == 'sumckb') {
      wx.navigateTo({
        url: '../core/kb/sumckb',
      })
    } else if (options.id == 'kb') {
      wx.navigateTo({
        url: '../core/kb/kb',
      })
    } else if (options.id == 'ykt') {
      wx.navigateTo({
        url: '../core/ykt/ykt',
      })
    } else if (options.id == 'xl') {
      wx.navigateTo({
        url: '../core/xl/xl',
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    console.log('ready',app.user)
    if(!this.data.card.ykt.show){
      if (app.user.is_bind) {
        if (app.user.status == 'stu') {
          this.setData({
            stu: true
          })
        } else {
          this.setData({
            stu: false
          })
        }
        this.getCard();//加载卡片
      }
    }
    // this.initSwiper();//加载海报
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    if (app.user.status == 'sumc') {
      var iconList = this.data.iconList;
      //iconList[0].url = '../core/kb/sumckb';
      iconList[4].name = '邻班课表';
      // iconList[4].url = '../core/ping/sumc/list';
      this.setData({
        iconList:iconList
      })
    }
    //加载模态窗
    var that = this;
    app.modal == 'bottom' && that.setData({
      modalName: 'bottomModal'
    }), setTimeout(function () {
      that.setData({
        modalName: ''
      }),app.modal = {}
    }, 3000)
    //判断是否登陆成功，登陆成功含跳转参数就跳转
    if(app.user.is_bind == true && app.cache.from == 'wetrack'){
      wx.showModal({
        title: '提醒',
        content: '您已成功登陆WeSTU,是否返回WeTrack',
        showCancel: true,
        cancelText: '待会再说',
        confirmText: '立即返回',
        success: function (res) {
          if (res.confirm) {
            wx.navigateToMiniProgram({
              appId: 'wxba5ee0abbcd8cbae',
              path: 'pages/index/index',
              envVersion: 'trial',
            })
          }
        },
      })
      app.removeCache('from');
    }
  },

  /**
   * 获取卡片信息，暂时只一卡通和课表
   */
  getCard() {
    console.log('time here')
    var that = this,
      user = app.user,
      loadsum = 0,
      stu = that.data.stu;
    //先读取缓存，有就直接加载
    if (!app.empty(app.cache.todayYkt)) {
      initYkt(app.cache.todayYkt);
    }
    if (!app.empty(app.cache.kb)) {
      initKb(app.cache.kb);
    } else if(Number(app.user.uid)>=1000000000){
      //判断是否为本科生
      load_kb();
    }
    // if (!app.empty(app.cache.ks)) {
    //   initKs(app.cache.ks);
    // }
    initOa();
    //开始加载数据
    // that.setData({
    //   isLoad: true
    // });

    //获取考试安排（有缓存不更新）
    if (!app.cache.ks) {
      if (that.data.stu) {
        wx.request({
          url: app.server + "stuks/getks",
          method: 'POST',
          data: app.key({
            username: app.user.username,
            uid: app.user.uid,
            psw: app.user.psw
          }),
          success: function (res) {
            if (res.data && res.data.state == 1) {
              var list = res.data.data;
              if (list) {
                //保存考试缓存
                app.saveCache('ks', list);
                initKs(list);
              } else {
                that.setData({
                  remind: '暂无数据'
                });
              }
            }
          }
        });
      } else {
        wx.request({
          url: app.server + "stuks/sumcks",
          method: 'POST',
          data: app.key({
            classname: app.user.classname
          }),
          success: function (res) {
            if (res.data && res.data.state == 1) {
              var list = res.data.data;
              if (list) {
                //保存考试缓存
                app.saveCache('ks', list);
                initKs(list);
              }
            }
          }
        });
      }
    }
    
    //oa通知渲染
    function initOa(){
      app.post('stu_oa/oalist',{
        page: 1,
        key: '',
        sub: 0,
        g_openid: app.wx.g_openid
      }).then(function(res){
        if (res.state == 1) {
          var data = JSON.parse(res.data),
              oaList = [];
          for (var i = 0; i < 3; i++) {
            oaList.push(data[i].DOCSUBJECT)
          }
          that.setData({
            'card.oa.show': true,
            'card.oa.data': oaList
          });
          app.cache.stuoa = [];
          for (var i = 0; i < data.length; i++) {
            app.cache.stuoa.push(data[i])
          }
        }
      })
    }

    //考试安排渲染
    function initKs(list) {
      if (app.empty(list)) {
        that.setData({
          'car.ks.show': false
        });
        return false;
      }
      var ks = []
      for (var i = 0, len = list.length; i < len; ++i) {
        var temp = {
          "what": '',
          "where": '',
          "when": ''
        };
        if (!that.data.stu) {
          var reg = RegExp(/^1月/);
          if (list[i].date.match(reg)) {
            list[i].date = list[i].date.trim().replace(/-/g, '/').replace(/日/g, '');
          } else {
            list[i].date = list[i].date.trim().replace(/-/g, '/').replace(/日/g, '');
          }
        } else {
          list[i].date = list[i].date.trim().replace(/\./g, '/');
        }
        temp.what = list[i].sub;
        temp.where = list[i].date.replace(/\d\d\d\d-/, '') + "@" + list[i].room;

        //计算倒计时天数
        var oDate1, oDate2, iDays
        oDate1 = Date.parse(new Date())
        oDate2 = Date.parse(new Date(list[i].date))
        list[i].days = Math.ceil((oDate2 - oDate1) / 1000 / 60 / 60 / 24)  //把毫秒数转换为天数
        console.log('days', list[i].days)
        temp.when = list[i].days;
        

        if (list[i].days >= 0 && list[i].time !='-') {
          ks.push(temp)
        }
      }
      console.log('ks0', ks)
      //排序今天>正数>负数
      ks.sort(function (x, y) {
        if (x.when > 0 && y.when > 0) {
          return (x.when - y.when);
        } else if (x.when < 0 && y.when > 0) {
          return (1);
        } else if (x.when > 0 && y.when < 0) {
          return (-1);
        } else if (x.when == 0) {
          return (-1);
        } else if (y.when == 0) {
          return (1);
        } else {
          return (y.when - x.when);
        }
      });
      console.log('ks', ks)
      list = []
      if (ks.length > 2) {
        for (var i = 0; i < 2; i++) {
          if (ks[i].when == 0) {
            ks[i].when = '今';
          }
          list.push(ks[i]);
        }
      } else if (ks.length == 0) {
        that.setData({
          'card.ks.show': false
        });
        return;
      } else {
        for (var i = 0; i < ks.length; i++) {
          if (ks[i].when == 0) {
            ks[i].when = '今';
          }
          list.push(ks[i]);
        }
      }
      console.log('ks', ks)

      that.setData({
        'card.ks.show': true,
        'card.ks.data': list
      });
      console.log('csrd',that.data.card)
    }

    //渲染一卡通
    function initYkt(info) {
      if (!app.empty(info.bill)) {
        var values = '',
          sum = 0;
        info.bill.forEach(function(val) {
          var money = -Number(val.money);
          if (money > 0) {
            values = values + '+' + money;
            sum += money;
          }
        })
        if (info.bill.length <= 1) {
          values = '';
        } else {
          values = values.substr(1) + ' = ';
        }
        sum = Math.round(sum * 100) / 100;
        that.setData({
          'card.ykt.data.today_cost.value': values,
          'card.ykt.data.today_cost.total': sum,
          'card.ykt.data.cost_status': true
        });
      }
      that.setData({
        'card.ykt.data.last_time': info.last_time,
        'card.ykt.data.balance': info.ye,
        'card.ykt.show': true,
        'remind': ''
      });
    }

    //获取一卡通数据(联网更新数据)
    var cookie = '';
    !app.empty(app.cache.todayYkt) ? cookie = app.cache.todayYkt.cookie : cookie = '';
    app.post('ykt/index',{
      start: app.time.stamp,
      end: app.time.stamp,
      ye: true,
      cookie: ''
    }).then(function(res){
      console.log(res)
      if (res.state == 1) {
        //判断是否有其他通知消息
        if (!app.empty(res.msg)) that.toInit(res.msg);
        var list = res.data
        //获取当前时间
        var time = Tools.GetTime(Date.parse(new Date()));
        time.M = Number(time.M + 1)
        time.M < 10 ? time.M = '0' + time.M : 1;
        time.D < 10 ? time.D = '0' + time.D : 1;
        time.H < 10 ? time.H = '0' + time.H : 1;
        time.Min < 10 ? time.Min = '0' + time.Min : 1;
        var last_time = time.M + "/" + time.D + " " + time.H + ":" + time.Min;
        list['last_time'] = last_time;
        console.log('last_time', last_time)
        if (list) {
          //保存一卡通缓存
          app.saveCache('todayYkt', list);
          initYkt(list);
        }
      } else {
        wx.showToast({
          icon: 'none',
          title: '获取消费数据失败',
        })
        app.removeCache('ykt');
      }
    })
    // wx.request({
    //   url: app._server + 'ykt/index',
    //   method: 'POST',
    //   data: app.key({
    //     g_openid: 'o0ktL1LyQjEUdK1HJUETFQnrRK5k',
    //     start: app.time.stamp,
    //     end: app.time.stamp,
    //     ye: true,
    //     cookie: ''
    //   }),
    //   success: function(res) {
    //     console.log(res.data)
    //     if (res.data.state == 1) {
    //       //判断是否有其他通知消息
    //       if (!app.empty(res.data.msg)) toInit(res.data.msg);
    //       var list = res.data.data
    //       //获取当前时间
    //       var time = Tools.GetTime(Date.parse(new Date()));
    //       time.M = Number(time.M + 1)
    //       time.M < 10 ? time.M = '0' + time.M : 1;
    //       time.D < 10 ? time.D = '0' + time.D : 1;
    //       time.H < 10 ? time.H = '0' + time.H : 1;
    //       time.Min < 10 ? time.Min = '0' + time.Min : 1;
    //       var last_time = time.M + "/" + time.D + " " + time.H + ":" + time.Min;
    //       list['last_time'] = last_time;
    //       console.log('last_time',last_time)
    //       if (list) {
    //         //保存一卡通缓存
    //         app.saveCache('todayYkt', list);
    //         initYkt(list);
    //       }
    //     } else {
    //       wx.showToast({
    //         icon: 'none',
    //         title: '获取消费数据失败',
    //       })
    //       app.removeCache('ykt');
    //     }
    //   },
    //   complete: function() {}
    // });
    if (that.data.card.kb.show == true && that.data.card.ykt.show == true) {
      that.setData({
        isLoad: false
      });
    }

    //渲染课表
    function initKb(info) {
      //判断天数
      if (app.time.H > 19) {
        var day = app.time.day+1;
        var card = that.data.card;
        card.kb.today = false
        that.setData({
          card: card
        })
      } else {
        var day = app.time.day
      }
      if (day == 7) {
        day = 0;
      }
      //处理课表数据
      if (!that.data.stu) {
        var week = app.time.week;
        var nowkb = app.cache.kb[week];
        var todayKb = [];
        console.log('nowkb', nowkb);
        if (!app.empty(nowkb)) {
          nowkb.forEach(function (val) {
            val.numday == day && todayKb.push(val);
          })
        }
        var list = [],
          time = Tools.stu_time;
        todayKb.forEach(function(val, key) {
          var a = parseInt(val.start) - 1,
            b = parseInt(val.start) + parseInt(val.length) - 2;
          list.push({
            where: val.room,
            what: val.sub,
            when: val.jieci + '节' +
              '（' + time[a].begin + '~' + time[b].end + '）',
            a:a
          })
        })
      } else {
        var week = app.time.week;
        var nowkb = app.cache.kb[week];
        var todayKb = [];
        console.log('nowkb', nowkb);
        if (!app.empty(nowkb)) {
          nowkb.forEach(function(val) {
            val.day == day && todayKb.push(val);
          })
        }
        var list = [],
          time = Tools.stu_time;
        todayKb.forEach(function(val, key) {
          var a = parseInt(val.start) - 1,
            b = parseInt(val.start) + parseInt(val.length) - 2;
            
          list.push({
            where: val.room,
            what: val.title,
            when: val.jieci + '节' +
              '（' + time[a].begin + '~' + time[b].end + '）',
            a:a
          })
        })
      }
      //排序
      list.sort(function (x, y) {
        return x['a'] - y['a'];
      });
      that.setData({
        'card.kb.data': list,
        'card.kb.show': true,
        'card.kb.nothing': !list.length,
        'remind': ''
      });
      if (that.data.card.kb.show == true && that.data.card.ykt.show == true) {
        that.setData({
          isLoad: false
        });
      }
    }

    function load_kb() {
      var that = this;
      var x = 0;

      function countSecond() {
        var that = this;
        x = x + 1
        //console.log('x', x)
        if (!app.empty(app.cache.kb)) {
          initKb(app.cache.kb);
          return;
        }
        if(x > 60){
          //app.showError('提示','课表加载失败')
          return;
        }
        setTimeout(function() {
          countSecond();
        }, 500)
      }
      if (stu) {
        //stu
        KB.load_stu_kb()
        //开始定时检查
        countSecond();
      } else {
        //sumc
        KB.load_sumc_list();
        //开始定时检查
        countSecond();
      }
    }
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },


  tapIcon(e) {
    //区分图标
    var that = this,
      iconList = that.data.iconList;
    if (app.user.status == 'sumc') {
      //iconList[0].url = '../core/kb/sumckb';
      iconList[4].name = '邻班课表';
      //iconList[4].url = '../core/ping/sumc/list';
      iconList[4].url = '../core/class/class';
    }
    console.log(e)
    var list = iconList,
      index = e.currentTarget.dataset.index;
    var content = '';
    switch (index) {
      case 8:
        content = '您好，使用查询图书查询功能需要先登录，是否前往？'
        break;
    
      case 6:
        content = '您好，使用查询水电费功能需要先登录，是否前往？'
        break;
    }
    if (content && !app.user.psw) {
      wx.showModal({
        title: '提示',
        content: content,
        success: function (res) {
          if (res.confirm) {
            wx.navigateTo({
              url: '../login/login'
            })
          }
        }
      })
      return;
    }
    if(index == 1){
      wx.navigateTo({
        url: list[index].url,
      })
    } else if (index == 9) {
      wx.navigateToMiniProgram({
        appId: 'wxba5ee0abbcd8cbae',
        path: 'pages/index/index',
      })
    } else if (app.user.is_bind === false) {
      wx.showModal({
        title: '提醒',
        content: '抱歉，您未绑定校园网账号，无权限查看此内容！',
        showCancel: true,
        cancelText: '以后再说',
        confirmText: '前往绑定',
        success: function(res) {
          if (res.confirm) {
            wx.navigateTo({
              url: '../login/login',
            })
          }
        },
      })
    } else {
      wx.navigateTo({
        url: list[index].url,
      })
    }
  },

  toOaList(){
    wx.switchTab({
      url : '/pages/news/list'
    })
  },

  toOa(e){
    var index = e.currentTarget.dataset.index;
    //查看记录
    var docid = app.cache.stuoa[index].docid,
      oaHistory = app.cache.oaHistory || [];
    oaHistory.push(docid);
    app.saveCache('oaHistory', oaHistory);
    wx.navigateTo({
      url: '../news/detail?oa=stu&page=1&index=' + index
    })
  },

  /**
   * 处理远程通知
   * @param {*} e 
   */
  toInit(e){
    if(e.swiperList){
      this.initSwiper(e.swiperList)
    }
    if(e.ps){
      this.initPs(e.ps)
    }
  },

  /**
   * 初始化课表页面
   * @param {*} e 
   */
  initSwiper(e){
    if(!app.empty(e)){
      this.setData({
        swiperList: e
      })
      app.saveCache('swiperList',e)
    }else if(!app.empty(app.cache.swiperList)){
      this.setData({
        swiperList: app.cache.swiperList
      })
    }else{
      this.setData({
        swiperList: Tools.swiperList
      })
    }
  },

  /**
   * 点击海报事件
   * @param {*} e 
   */
  swipertap(e) {
    var list = this.data.swiperList,
      id = e.currentTarget.dataset.id;
    if (list[id].tap == 'w') {
      wx.navigateTo({
        url: '../more/weather'
      })
    }else if(list[id].mini){
      if (list[id].mini == 'wetrack'){
        wx.navigateToMiniProgram({
          appId: 'wxba5ee0abbcd8cbae',
          path: 'pages/index/index'
        })
      }
    }else if (list[id].tap) {
      wx.navigateTo({
        url: '../more/web-view?url=' + list[id].tap
      })
    }
  },

  log(){
    wx.navigateTo({
      url: '../more/about/log',
    })
  }
})