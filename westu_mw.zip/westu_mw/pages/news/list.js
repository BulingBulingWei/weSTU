// pages/news/list.js
const app = getApp()
const Sub = require('../../utils/sub.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    sub_list: Sub.stu_sub,
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    TabCur: 0,
    navigation: 'OA',
    tab: ['汕大OA', '汕医OA', '汕医教务'],
    scrollLeft: 0,
    list: [],
    page: 1,
    margin: '下拉加载更多',
    sub: 0,
    remind: true,
    page_stu: 1,
    page_sumc: 1,
    page_jiaowu: 1
  },

  tabSelect(e) {
    var that = this;
    console.log(e);
    var tab = e.currentTarget.dataset.id;
    that.setData({
      TabCur: tab,
      scrollLeft: (tab - 1) * 60,
      remind: true,
      list: []
    })
    if (tab == 0) {
      that.setData({
        navigation: '汕大OA'
      })
      that.getStu();
    } else if (tab == 1) {
      that.setData({
        navigation: '汕医OA'
      })
      that.getSumc();
    } else {
      that.setData({
        navigation: '汕医教务'
      })
      that.getJiaowu();
    }
  },

  detail: function (e) {
    console.log(e)
    var index = e.currentTarget.dataset.index;
    var tab = this.data.TabCur;
    //查看记录
    var docid = this.data.list[index].docid,
      oaHistory = app.cache.oaHistory || [];
    oaHistory.push(docid);
    app.saveCache('oaHistory', oaHistory);
    var list = this.data.list;
    list[index].old = true;
    this.setData({
      list: list
    })

    if (tab == 0) {
      if (this.data.searched) {
        wx.navigateTo({
          url: 'detail?oa=stu&page=' + this.data.page + '&index=' + index + '&is_search=1',
        })
      } else {
        wx.navigateTo({
          url: 'detail?oa=stu&page=' + this.data.page + '&index=' + index
        })
      }

    } else if (tab == 1) {
      wx.navigateTo({
        url: 'detail?oa=sumc&page=' + this.data.page + '&index=' + index,
      })
    } else {
      wx.navigateTo({
        url: 'detail?oa=jiaowu&page=' + this.data.page + '&index=' + index,
      })
    }
  },

  getStu: function (page = 1, key = '', sub = 0, is_search = false) {
    var that = this;
    if (app.cache.stuoa && app.cache.stuoa.length >= page * 10 && !key && !sub) {
      that.toList(app.cache.stuoa);
    } else {
      that.setData({
        remind: true
      })
      wx.request({
        url: app.server + 'stu_oa/oalist',
        data: app.key({
          page: page,
          key: key,
          sub: sub,
          g_openid: app.wx.g_openid
        }),
        method: 'POST',
        success: function (res) {
          if (res.data.state == 1) {
            var data = JSON.parse(res.data.data);
            app.empty(app.cache.stuoa) ? app.cache.stuoa = [] : 1;
            if (is_search == false) {
              //不需要检索
              for (var i = 0; i < data.length; i++) {
                app.cache.stuoa.push(data[i])
              }
              that.toList(app.cache.stuoa, true);
              that.setData({
                searched: false
              })
            } else {
              //检索
              var his = app.cache.his || [];
              console.log('qqo',app.cache.his)
              if (app.empty(his)) {
                app.cache.his = data
              } else {
                for (var i = 0; i < data.length; i++) {
                  app.cache.his.push(data[i])
                }
              }
              console.log('qq1', app.cache.his)
              that.setData({//用于判断当前是否为检索列表
                searched: true
              })
              that.toList(app.cache.his, true);
            }
            var margin = data.length < 10 ? '我也是有底限的' : '下拉加载更多';
            that.setData({
              margin: margin
            })
          }
        },
        fail: function (res) { },
        complete: function (res) {
          that.setData({
            remind: false
          })
        },
      })
    }
  },

  /**处理传回的json */
  toList: function (data) {
    console.log('1', data)
    if (!app.empty(data)) {
      var list = new Object(),
        oaHistory = app.cache.oaHistory || [];
      //console.log(oaHistory)
      for (var i = 0; i < data.length; i++) {
        var title = data[i].DOCSUBJECT;
        list[i] = {
          title: title,
          sub: data[i].SUBCOMPANYNAME,
          time: data[i].DOCVALIDDATE,
          docid: data[i].ID,
          old: oaHistory.includes(data[i].ID)
        };
      }
      //console.log(list);
      this.setData({
        list: list,
        remind: false
      })
    } else {
      this.setData({
        margin: '当前暂无数据'
      })
    }
  },

  getSumc: function (page = 1, key = '', sub = '') {
    var that = this;
    if (app.cache.sumcoa && app.cache.sumcoa.length >= page * 10) {
      that.setData({
        list: app.cache.sumcoa
      })
    } else {
      that.setData({
        remind: true
      })
      wx.request({
        url: app.server + 'Sumc_oa/sumcoalist',
        method: 'post',
        data: app.key({
          page: page,
          key: key,
          sub: sub,
          g_openid: app.wx.g_openid
        }),
        success: function (res) {
          console.log(res);
          var data = res.data.data;
          if (res.data.state == 1) {
            var oa = app.cache.sumcoa;
            if (app.empty(oa)) {
              app.cache.sumcoa = data
            } else if (oa.length >= page * 10) {
              app.cache.sumcoa = data
            } else {
              for (var i = 0; i < data.length; i++) {
                app.cache.sumcoa.push(data[i])
              }
            }
            //标记已阅读文章
            var oaHistory = app.cache.oaHistory || [],
              list = app.cache.sumcoa;
            list.forEach(function (val, key) {
              list[key].old = oaHistory.includes(val.docid);
            })

            if (app.empty(app.cache.sumcoa)) {
              that.setData({
                list: list,
                margin: '温馨提示：服务器校园网断了，晚点再来哦'
              })
            } else {
              that.setData({
                list: list,
                remind: false
              })
            }
          }
        },
        complete: function (res) {
          that.setData({
            remind: false
          })
        },
      })
    }
  },

  getJiaowu: function (page = 1, keyword = '+') {
    var that = this;
    if (app.cache.jiaowu && app.cache.jiaowu.length >= page * 10) {
      that.setData({
        list: app.cache.jiaowu
      })
    } else {
      that.setData({
        remind: true
      })
      wx.request({
        url: app.server + 'Sumc_oa/jiaowulist',
        method: 'post',
        data: app.key({
          page: page,
          keyword: keyword,
          g_openid: app.wx.g_openid
        }),
        success: function (res) {
          console.log(res)
          var data = res.data.data;
          if (res.data.state == 1) {
            var oa = app.cache.jiaowu;
            if (app.empty(oa)) {
              app.cache.jiaowu = data
            } else if (oa.length >= page * 10) {
              app.cache.jiaowu = data
            } else {
              for (var i = 0; i < data.length; i++) {
                app.cache.jiaowu.push(data[i])
              }
            }
            //标记已阅读文章
            var oaHistory = app.cache.oaHistory || [],
              list = app.cache.jiaowu;
            list.forEach(function (val, key) {
              list[key].old = oaHistory.includes(val.docid);
            })
            if (app.empty(app.cache.jiaowu)) {
              that.setData({
                list: list,
                margin: '温馨提示：汕医教务网目前仅在上班时间可以访问'
              })
            } else {
              that.setData({
                list: list,
                remind: false
              })
            }
          }
        },
        complete: function (res) {
          that.setData({
            remind: false
          })
        },
      })
    }
  },

  /**
   * 检索btn
   * @param page
   * @param sub
   * @param key
   */
  search(page = 1) {
    var sub = this.data.sub,
      key = this.data.key,
      TabCur = this.data.TabCur;
    if (TabCur == 0) {
      this.data.searched ? this.getStu(page, key, sub, true) : this.getStu(page, key, sub, false);
    } else if (TabCur == 1) {
      this.data.searched ? this.getSumc(page, key, sub, true) : this.getSumc(page, key, sub, false);
    } else {
      this.data.searched ? this.getJiaowu(page, key, sub, true) : this.getJiaowu(page, key, sub, false);
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    if (app.user.is_bind == false) {
      this.setData({
        toBind: true
      })
      return;
    }
    var that = this;
    var tab = that.data.TabCur;
    if (tab == 0) {
      that.getStu()
    } else if (tab == 1) {
      that.getSumc();
    } else {
      that.getJiaowu();
    }

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  //直接使用该函数会传递tap对象与page冲突
  searchBtn() {
    if (!this.data.sub && !this.data.key && app.empty(app.cache.his)) {
      app.showError('提示', '请先输入检索条件哦~');
      return;
    }
    app.cache.his = [];
    this.setData({
      modalName: null,
      list: [],
      searched: true
    })
    this.search();
    
  },

  showModal(e) {
    let TabCur = this.data.TabCur;
    let list = TabCur == 0 ? Sub.stu_sub : TabCur == 1 ? Sub.sumc_sub : [];
    this.setData({
      modalName: true,
      sub_list: list
    })
  },

  hideModal(e) {
    this.setData({
      modalName: null
    })
  },

  ChooseCheckbox(e) {
    //改成单选
    let items = this.data.sub_list;
    let values = e.currentTarget.dataset.value;
    for (let i = 0, lenI = items.length; i < lenI; ++i) {
      if (items[i].value == values) {
        items[i].checked = true;
        this.setData({
          sub: items[i].value
        })
      } else {
        items[i].checked = false;
      }
    }
    this.setData({
      sub_list: items
    })
  },

  keyInput(e) {
    console.log(e.detail.value)
    this.setData({
      key: e.detail.value
    })
  },


  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    console.log('here')
    var that = this;
    var tab = that.data.TabCur;
    if (page >= 10) {
      that.setData({
        margin: '还没找到想要的内容吗，试试搜索功能吧~'
      })
      return;
    }
    if (tab == 0) {
      var page = that.data.page_stu;
      that.setData({
        page_stu: ++page
      })
    } else if (tab == 1) {
      var page = that.data.page_sumc;
      that.setData({
        page_sumc: ++page
      })
    } else {
      var page = that.data.page_jiaowu;
      that.setData({
        page_jiaowu: ++page
      })
    }
    that.data.searched ? that.search(page) : that.search(page);
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})