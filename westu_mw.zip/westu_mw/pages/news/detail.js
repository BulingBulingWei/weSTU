var a = getApp(),
  t = require("../../wxParse/wxParse.js");

Page({
  data: {
    StatusBar: a.globalData.StatusBar,
    CustomBar: a.globalData.CustomBar,
    node: "",
    title: !1,
    remind: !1,
    fjList: []
  },
  onLoad: function (a) {
    if (console.log(a), a) {
      var t = "OA";
      t = "stu" == a.oa ? "汕大OA" : "sumc" == a.oa ? "汕医OA" : "汕医教务", this.setData({
        page: a.page,
        index: a.index,
        oa: a.oa,
        navigation: t,
        searched: a.is_search || false
      });
    }
  },
  onReady: function () {
    var a = this,
      t = a.data.oa;
    "stu" == t ? a.loadStu() : "sumc" == t ? a.loadSumc() : "jiaowu" == t && a.loadJiaowu();
  },
  loadStu: function () {
    var e = this,
      o = e.data.index,
      s = this.data.searched == true ? a.cache.his[o] : a.cache.stuoa[o];
    console.log("stuoa", s), s.ACCESSORYCOUNT > 0 && e.stuFile(s.ID);
    var i = s.DOCCONTENT;
    console.log('i', i)
    i = i.replace(/.*?!@#\$%\^&\*/, "").replace(/\/weaver\/weaver/, "http://note.stuhb.top:8081/weaver/weaver").replace(/<o:p>/g, "").replace(/pt/g, "*2rpx"),
      t.wxParse("article", "html", i, e);
  },
  stuFile: function (t) {
    var e = this;
    wx.showLoading({
      title: "加载附件信息中.."
    }), a.post("stu_oa/stufile", {
      docid: t
    }).then(function (a) {
      1 == a.state && e.setData({
        fjList: a.data.file
      });
    });
  },
  loadSumc: function () {
    var e = this,
      o = e.data.index,
      s = a.cache.sumcoa[o].docid;
    e.setData({
      remind: !0
    }), wx.request({
      url: a.server + "sumc_oa/sumcoadel",
      data: a.key({
        docid: s,
        g_openid: a.wx.g_openid
      }),
      method: "POST",
      success: function (a) {
        if (console.log("res", a), 1 == a.data.state) {
          var o = a.data.data.text;
          o = o.replace(/<o:p>/g, "").replace(/pt/g, "*2rpx").replace(/<\?xml.*?\/>/g, ""),
            t.wxParse("article", "html", o, e);
          var s = a.data.data.file;
          console.log("fj", s), s && e.setData({
            fjList: s
          });
        }
      },
      fail: function (a) { },
      complete: function (a) {
        e.setData({
          remind: !1
        });
      }
    });
  },
  loadJiaowu: function () {
    var e = this,
      o = e.data.index,
      s = a.cache.jiaowu[o].docid;
    e.setData({
      remind: !0
    }), wx.request({
      url: a.server + "sumc_oa/jiaowudel",
      data: a.key({
        docid: s,
        g_openid: a.user.g_openid
      }),
      method: "POST",
      success: function (o) {
        if (1 == o.data.state) {
          var s = o.data.data.text;
          s = s.replace(/<o:p>/g, "").replace(/pt/g, "*2rpx"), console.log("node"), t.wxParse("article", "html", s, e);
          var i = e.data.index,
            c = a.cache.jiaowu[i].title;
          e.setData({
            title: c
          });
          var n = o.data.data.file;
          console.log("fj", n), n && e.setData({
            fjList: n
          });
        }
      },
      fail: function (a) { },
      complete: function (a) {
        e.setData({
          remind: !1
        });
      }
    });
  },
  loadFile: function (t) {
    console.log(t);
    var e = t.currentTarget.dataset.index,
      o = this.data.fjList,
      s = o[e].token,
      i = o[e].type,
      c = "stu";
    if (a.empty(i)) {
      a.showError('提示', '未知的文件类型，可点击右上方复制图标，然后进入浏览器打开');
      return;
    } else if (i == '未知的文件类型') {
      a.showError('提示', '不支持的文件类型，可点击右上方复制图标，然后进入浏览器打开');
      return;
    }
    if ("stu" != this.data.oa && (c = "sumc"), 0 != s) {
      var n = "https://file.stuhb.top/getFile.php?token=" + s + "&d=" + c;
      wx.showLoading({
        title: "loading.."
      }), wx.downloadFile({
        url: n,
        success: function (a) {
          if (200 === a.statusCode) {
            console.log(a);
            var t = a.tempFilePath;
            wx.openDocument({
              filePath: t,
              fileType: i,
              success: function (a) {
                console.log("open success", a);
              },
              fail: function (a) {
                console.log("fail open", a);
              }
            });
          }
        },
        fail: function (a) {
          console.log("fail", a);
        },
        complete: function (a) {
          wx.hideLoading();
        }
      });
    } else a.showError("提示", i);
  },
  onShow: function () { },
  onShareAppMessage: function () { },
  copyfj: function (a) {
    console.log("copyfj", a);
    var t = a.currentTarget.dataset.index,
      e = "http://oa.stu.edu.cn/weaver/weaver.file.FileDownload?fileid=" + this.data.fj[t].url + "&download=1& requestid=0";
    wx.setClipboardData({
      data: e,
      success: function (a) { }
    });
  },
  copyUrl: function () {
    var that = this;
    wx.showActionSheet({
      itemList: ['复制网址', '标题+网址'],
      success: function (res) {
        switch (res.tapIndex) {
          case 0:
            urlOnly()
            break;
          case 1:
            urlTitle()
            break;
          // case 2:
          //   wx.navigateTo({
          //     url: 'append/list',
          //   })
          //   break;
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })
    function urlOnly(){
      var t = that.data.oa,
        e = that.data.index;
      if ("stu" == t) i = "http://oa.stu.edu.cn/page/maint/template/news/newstemplateprotal.jsp?templatetype=1&templateid=3&docid=" + (s = (o = a.cache.stuoa)[e].ID);
      else if ("sumc" == t) i = "http://int.med.stu.edu.cn/index.php?action=article&id=" + (s = (o = a.cache.sumcoa)[e].docid);
      else var o = a.cache.jiaowu,
        s = o[e].docid,
        i = "http://jiaowu.med.stu.edu.cn/bencandy.php?fid=3&id=" + s;
      console.log(o), console.log(s), wx.setClipboardData({
        data: i,
        success: function (a) { }
      });
    }

    function urlTitle(){
      var t = that.data.oa,
        e = that.data.index;
      if ("stu" == t) i = "汕大OA：\n" + (o = a.cache.stuoa)[e].DOCSUBJECT + "\n网址：http://oa.stu.edu.cn/page/maint/template/news/newstemplateprotal.jsp?templatetype=1&templateid=3&docid=" + (s = o[e].ID);
      else if ("sumc" == t) i = "汕医OA：\n" + ((o = a.cache.sumcoa))[e].title + "\n网址：http://int.med.stu.edu.cn/index.php?action=article&id=" + (s = o[e].docid);
      else var o = a.cache.jiaowu,
        s = o[e].docid,
        i = "汕医教务：\n" + ((o = a.cache.jiaowu))[e].title + "\n网址：http://jiaowu.med.stu.edu.cn/bencandy.php?fid=3&id=" + s;
      console.log(o), console.log(s), wx.setClipboardData({
        data: i,
        success: function (a) { }
      });
    }

    function copyfj(){

    }
  },

  shareOa: function (){
    return {
      title: title,
      path: '/pages/core/kb/sumckb?view=' + view + ' & abbr=' + abbr,
    }
  },

  wxParseTagATap: function (t) {
    console.log(t), !a.empty(t.currentTarget.dataset.src) && wx.setClipboardData({
      data: t.currentTarget.dataset.src,
      success: function (a) { }
    });
  }
});