const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    cardCur: 0,
    mode: '关联uc进度表账号'
  },

  //登录验证信息
  binduc: function () {
    var that = this;
    if (!that.data.uid || !that.data.psw) {
      app.showError('错误', '账号密码不能为空');
      return false;
    }
    wx.showLoading({
      title: '绑定中...',
    });
    app.post('syjx/login',{
      uid: that.data.uid,
      upsw: that.data.psw,
      g_openid: app.wx.g_openid,
    }).then(function(res){
      if(res.state == 1){
        app.toast('绑定成功')
        wx.redirectTo({
          url: '../core/kb/sumckb'
        })
      }

    })

  },

  onLoad(options) {
   
  },


  question: function (e) {
    this.setData({
      help: true
    })
  },

  close: function (e) {
    this.setData({
      help: false
    })
  },


  uidInput: function (e) {
    this.setData({
      uid: e.detail.value
    });
  },
  pswInput: function (e) {
    this.setData({
      psw: e.detail.value
    });
  },
  inputFocus: function (e) {
    if (e.target.id == 'uid') {
      this.setData({
        'uid_focus': true
      });
    } else if (e.target.id == 'psw') {
      this.setData({
        'psw_focus': true
      });
    }
  },
  inputBlur: function (e) {
    if (e.target.id == 'uid') {
      this.setData({
        'uid_focus': false
      });
    } else if (e.target.id == 'psw') {
      this.setData({
        'psw_focus': false
      });
    }
  },

});