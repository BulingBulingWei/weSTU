const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    cardCur: 0,
    mode: '绑定账号'
  },

  //登录验证信息
  login: function (encryptedData, iv) {
    var that = this;
    if (!that.data.uid || !that.data.psw) {
      app.showError('错误', '账号密码不能为空');
      return false;
    }
    if (app.wx.x_openid == "" || that.data.session_key == "") {
      app.showError('绑定失败', '请删除小程序后重新进入');
      return;
    }
    wx.showLoading({
      title: '绑定中...',
    });
    wx.request({
      method: 'POST',
      url: app.server + 'login/login',
      data: app.key({
        username: that.data.uid,
        psw: that.data.psw,
        x_openid: app.wx.x_openid,
        g_openid: app.wx.g_openid,
        session_key: that.data.session_key,
        encryptedData: encryptedData,
        iv: iv,
      }),
      success: res => {
        if (res.data.state == 1) {
          var data = res.data.data;
          //重置缓存
          var mini_from = !app.empty(app.cache.from) ? app.cache.from : '';
          app.cache = {};
          wx.clearStorage();
          //保存用户信息
          app.wx.g_openid = data.g_openid; //g_openid
          var user = {
            "id": 2,
            "name": data.name,
            "uid": data.uid,
            "department": data.department,
            "username": that.data.uid,
            "psw": that.data.psw,
            "classname": data.classname,
            "is_bind": true,
            "ks_remind": data.ks_remind,
            "xf_remind": data.xf_remind,
            "kb_remind": data.kb_remind,
            "xn": app.globalData.xn,
            'xq': app.globalData.xq
          };
          data.department == "医学院" ? user.status = 'sumc' : user.status = 'stu';
          app.saveCache('user', user);
          app.saveCache('wx', app.wx);
          app.saveCache('version', app.version)
          wx.setStorage({
            key: 'user',
            data: user,
          })
          wx.setStorage({
            key: 'wx',
            data: app.wx,
          })
          app.user = app.cache.user;
          console.log('login_user', wx.getStorageSync('user'))
          //判断时候为跳转登陆
          mini_from != '' ? app.cache.from = mini_from : 1;
          wx.showToast({
            title: '绑定成功',
            icon: 'success',
            duration: 1500
          });
          wx.reLaunch({
            url: '../index/index',
          })
        } else {
          app.showError('绑定失败', res.data.msg);
        }
      },
      fail: res => {
        console.log(res);
        app.showError('绑定失败', res.errMsg);
      },
      complete: res => {
        wx.hideLoading();
      }
    })
  },

  //获取小程序openid
  get_x_openid: function () {
    var that = this;
    //微信登陆获取openid
    wx.login({
      success: res => {
        console.log('code', res)
        wx.request({
          url: app.server + '/wemini/session',
          method: 'post',
          data: app.key({
            code: res.code
          }),
          success: function (res) {
            console.log("x_openid", res);
            app.wx.x_openid = res.data.data.openid;
            app.saveCache('wx', app.wx);
            that.setData({
              session_key: res.data.data.session_key
            })
          },
          fail: function (res) {
            wx.showToast({
              title: '网络错误！请重新打开！',
              icon: 'none',
              duration: 2000
            });
          }
        })
      }
    })
  },

  onLoad(options) {
    //微信登陆获取openid
    this.get_x_openid();
    //微信登陆获取用户信息
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    } else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    } else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
    console.log('111',options)
    if (!app.empty(options)) {
      this.setData({
        mode: '绑定成绩查询系统'
      })
    }
  },

  getUserInfo: function (e) {
    console.log('e', e);
    if (e.detail.userInfo) {
      app.globalData.userInfo = e.detail.userInfo
      this.setData({
        userInfo: e.detail.userInfo,
        hasUserInfo: true
      })
      app.wx.userInfo = e.detail.userInfo
      app.saveCache('wx', app.wx)
      this.login(e.detail.encryptedData, e.detail.iv);
    } else {
      wx.showModal({
        title: '授权失败',
        content: '拒绝授权将导致无法关联校园网账号并影响正常使用,请授权后再登陆！',
        showCancel: true,
        cancelText: '以后再说',
        confirmText: '重新授权',
        success: function (res) {
          wx.clearStorageSync();
          wx.reLaunch({
            url: '../index/index',
          })
        },
        fail: function (res) {
          wx.reLaunch({
            url: '../index/index',
          })
        },
        complete: function (res) { },
      })
    }
  },


  /**
   * 绑定医学院成绩账号
   */
  bindcj: function () {
    var that = this;
    if (!that.data.uid || !that.data.psw) {
      app.showError('账号及密码不能为空', '提醒');
      return false;
    }
    wx.showLoading({
      title: '绑定中..',
    })
    //update westu_users t1,sumc_users t2 set t1.classname = t2.class where t1.userid = t2.userid;
    wx.request({
      method: 'POST',
      url: 'https://www.stuhb.top/beta0.2.0/sumc/cjbind.php',
      data: app.key({
        userid: that.data.uid,
        cjpsw: that.data.psw
      }),
      success: function (res) {
        console.log("res", res);
        if (res.data.state == 1) {
          wx.showLoading({
            title: 'loading..',
          })
          var user = app.cache.user;
          user.ucpsw = that.data.psw;
          console.log('user', user);
          app.saveCache('user', user);
          app.user = app.cache.user;
          wx.showToast({
            title: '绑定成功',
            icon: 'success',
            duration: 1500
          });
          wx.redirectTo({
            url: '../core/cj/cj',
          })
        } else {
          wx.hideToast();
          app.showError('绑定失败', res.data.msg);
        }
      },
      fail: function (res) {
        app.showError(res.errMsg, '绑定失败');
      },
      complete: function (res) {
        wx.hideLoading();
      }
    });
  },



  question: function (e) {
    this.setData({
      help: true
    })
  },

  close: function (e) {
    this.setData({
      help: false
    })
  },

  uidInput: function (e) {
    this.setData({
      uid: e.detail.value.replace(/(^\s*)|(\s*$)/g, "")
    });
  },
  pswInput: function (e) {
    this.setData({
      psw: e.detail.value
    });
  },
  inputFocus: function (e) {
    if (e.target.id == 'uid') {
      this.setData({
        'uid_focus': true
      });
    } else if (e.target.id == 'psw') {
      this.setData({
        'psw_focus': true
      });
    }
  },
  inputBlur: function (e) {
    if (e.target.id == 'uid') {
      this.setData({
        'uid_focus': false
      });
    } else if (e.target.id == 'psw') {
      this.setData({
        'psw_focus': false
      });
    }
  },

});