//获取应用实例
var location;
var isOpenSetting = false;
var longi;
var lat;
Page({
  data: {
    location: '金平区',
    hasRefresh: false,
    nowBackGround: [100, 8],
    nowTemperature: '0 ℃',
    nowWind: '晴/东北风  微风',
    nowAir: '50  优',
    hourlyArr: [],
    dailyForecast: [],
    lifeStyle: [],
    week: ''
  },
  gotest: function() {
    wx.navigateTo({
      url: '../scrollView/scrollView',
    })
  },
  //天气接口
  Weather: function(lat, longi) {
    var _this = this;
    //数据集合
    var url = "https://free-api.heweather.com/s6/weather";
    var data = {
      key: "bff5cc9bcfdf46b0a0e9bf0c260ff14f",
      location: "CN101280506",
      lang: "zh",
      unit: "m"
    };
    _this._get(url, data, function (res) {
      // console.log(res.data.HeWeather6[0])
      var now = res.data.HeWeather6[0].now;
      var hourly = res.data.HeWeather6[0].hourly;
      var daily = res.data.HeWeather6[0].daily_forecast;
      var lift = res.data.HeWeather6[0].lifestyle;
      _this.setData({
        nowBackGround: [now.cond_code, now.tmp],
        nowTemperature: now.tmp + "℃", 
        nowWind: now.cond_txt + "/" + now.wind_dir + "   " + now.wind_sc,
        hourlyArr: hourly,
        dailyForecast: daily,
        lifeStyle: [lift[2], lift[1], lift[6], lift[5]],
      })
    }, function (res) {

    }, function () {
      // 数据成功后，停止下拉刷新
      wx.stopPullDownRefresh();
      wx.hideLoading()
    });

  },

  onLoad: function () {
    this.Weather("", "");
    this.setData({
      week: this.weekDay()
    })
  },
  getLocationAction: function() {
    // var location;
    var _this = this;
    wx.getLocation({
      success: function (res) {
        lat = res.latitude
        longi = res.longitude
        wx.showLoading({
          title: '加载中',
          mask: true
        })
        _this.genCodeLocation(lat, longi)
      },
      fail: function () {
        _this.Weather("", "");
      }
    }) 
  },
  onShow : function() {
    // if (isOpenSetting) {
    //   this.getLocationAction()
    // }
  },

  onShareAppMessage: function () {
    return {
      title: '即时天气',
      path: '/pages/index/index',
    }
  },
  onPullDownRefresh: function() {
    this.Weather(longi, lat);
  },

  //查看历史上的今天
  lookHistory: function() {
    wx.navigateTo({
      url: '/pages/historytoday/historytoday',
    })
  },
  _get: function (url, data, success, fail, completed) {
    wx.request({
      url: url,
      method: "GET",
      data: data,
      success: function (res) {
        success(res)
      },
      fail: function (res) {
        fail(res)
      },
      complete: function () {
        completed()
      }
    })
  },
  weekDay: function () {
    var weekDay;
    var week = new Date().getDay()
  console.log(week)
  switch(week) {
    case 0:
    weekDay = '星期日'
      break;
    case 1:
    weekDay = '星期一'
      break;
    case 2:
    weekDay = '星期二'
      break;
    case 3:
    weekDay = '星期三'
      break;
    case 4:
    weekDay = '星期四'
      break;
    case 5:
    weekDay = '星期五'
      break;
    case 6:
    weekDay = '星期六'
      break;
  }
  return weekDay;
}
})
