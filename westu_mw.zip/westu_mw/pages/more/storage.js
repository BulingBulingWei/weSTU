// pages/more/storage.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    TabCur: 0
  },

  clearAdd: function() {
    wx.showModal({
      title: '提示',
      content: '确认之后所有自定义课程信息将会全部清除!!',
      success(res) {
        if (res.confirm) {
          wx.removeStorageSync('kb_add');
          wx.removeStorageSync('add');
          wx.showToast({
            title: '清除成功',
            duration: 2000
          })
          wx.reLaunch({
            url: '../index/index',
          })
        } else if (res.cancel) {
          wx.reLaunch({
            url: '../index/index',
          })
        }
      }
    })
  },


  clearKb: function() {
    wx.showModal({
      title: '提示',
      content: '确认之后用户课表信息（包括自定义课程）将会全部清除!!',
      success(res) {
        if (res.confirm) {
          wx.removeStorageSync('kb');
          wx.removeStorageSync('kb_list');
          wx.removeStorageSync('stu_kb_list');
          wx.removeStorageSync('kb_add');
          wx.removeStorageSync('add');
          wx.showToast({
            title: '清除成功',
            duration: 2000
          })
          wx.reLaunch({
            url: '../index/index',
          })
        } else if (res.cancel) {
          wx.reLaunch({
            url: '../index/index',
          })
        }
      }
    })
  },

  clearAll: function() {
    wx.showModal({
      title: '提示',
      content: '确认之后手机端所有缓存将会全部清除，需重新登陆!!',
      success(res) {
        if (res.confirm) {
          wx.clearStorageSync();
          app.saveCache('version', app.version);
          app.user = {
              is_bind: false,
              status: 'guest'
            },
            app.design = {
              textSize: 22,
              isWhite: false,
              isLine: true,
            },
            app.wx = {},
            app.cache = {},
            wx.showToast({
              title: '清除成功',
              duration: 2000
            })
          wx.reLaunch({
            url: '../index/index',
          })
        } else if (res.cancel) {
          wx.navigateBack({
            data: 1
          })
        }
      }
    })
  },

  clearLogin: function() {
    !app.user.is_bind ? app.showError('提示', '请先登录哦~') :
      wx.showModal({
        title: '提示',
        content: '确认之后将注销用户所有登陆信息，同时取消与该微信的绑定，请深思',
        success(res) {
          if (res.confirm) {
            wx.showLoading({
              title: 'loading..',
            })
            wx.request({
              url: app.server + 'ykt/destroy',
              method: 'POST',
              data: {
                g_openid: app.wx.g_openid,
                id: app.user.id,
                uid:app.user.uid
              },
              success(e) {
                console.log('e',e)
                if (e.data.state == 1) {
                  wx.showToast({
                    title: e.data.msg,
                  })
                  wx.clearStorageSync();
                  app.saveCache('version',app.version);
                  app.user = { is_bind: false,status: 'guest'},
                  app.design = {
                    textSize: 22,
                    isWhite: false,
                    isLine: true,
                  },
                  app.wx = {},
                  app.cache = {},
                  wx.hideLoading();
                  wx.reLaunch({
                    url: '../index/index',
                  })
                } else {
                  app.showError('提示', e.data.msg || '绑定失败，未知错误')
                }
              },
              fail(e) {},
              complete(e) {
                wx.hideLoading();
              }
            })
          } else if (res.cancel) {
            wx.navigateBack({
              data: 1
            })
          }
        }
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})