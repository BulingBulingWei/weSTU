// pages/more/clock.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    timeList: [{
      time: '关闭',
      check: false,
      value: 0
    },{
      time: '17:00',
      check: false,
      value: 32400
    }, {
      time: '18:00',
      check: true,
      value: 36000
    }, {
      time: '19:00',
      check: false,
      value:39600
    }, {
      time: '20:00',
      check: false,
      value: 43200
    }, {
      time: '21:00',
      check: false,
      value:46800
    }, {
      time: '22:00',
      check: false,
      value: 50400
    }, {
      time: '08:00',
      check: false,
      value: 82800
    }],
    timeIndex: 2,
    isYkt: true,
    isKs: true
  },

  show(e){
    var index = 2;
    this.data.timeList.forEach(function(val,key){
      val.value == e.kb_remind ? index = key : 1;
    })
    var timeList = this.data.timeList;
    timeList[index].check = true;
    this.setData({
      timeIndex: index,
      isKs: e.ks_remind,
      isYkt: e.xf_remind,
      timeList:timeList
    })
  },

  chooseTime(e){
    console.log(e)
    this.setData({
      timeIndex: e.detail.value
    })
    var val = this.data.timeList[e.detail.value].value;
    this.remind(val,'kb_remind');
  },

  ykt(e){
    var val = 1;
    e.detail.value ? val = 1 : val =  0;
    this.setData({
      isYkt: val
    })
    this.remind(val, 'xf_remind');
  },

  ks(e){
    var val = 1;
    e.detail.value ? val = 1 : val = 0;
    this.setData({
      isKs: val
    })
    this.remind(val,'ks_remind');
  },

  /**
   * 上传修改设置
   */
  remind(val,type){
    var that = this;
    wx.showLoading({
      title: 'loading..',
    })
    app.post('login/remind',{
        type: type,
        val:val
      }).then(function(res){
        if (res.state == 1) {
          app.saveCache('remind', res.data);
          that.show(res.data);
          type != 'get' && wx.showToast({
            title: '修改成功',
          })
        } else {
          app.showError('错误', res.msg || '未知错误，请重试');
        }
      })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    app.checkLogin('login');
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {
    app.empty(app.cache.remind) || this.show(app.cache.remind);
    this.remind(1, 'get');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },
  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },

})