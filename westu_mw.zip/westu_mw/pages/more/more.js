const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    user:false
  },
  onShow(e){
    console.log('moreuser',app.user)
    if(!app.empty(app.user) && app.user.psw){
      this.setData({
        user: app.user
      })
    }
  },

  toLogin(){
    if(!app.empty(app.user) && app.user.psw)return
    wx.navigateTo({
      url: '../login/login',
    })
  }
})