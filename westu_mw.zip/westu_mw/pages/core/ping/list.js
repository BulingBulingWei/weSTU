
// pages/index/index.js

var WxSearch = require('../../../utils/wxSearch/wxSearch.js')
var Ping = require('../../../utils/ping.js')
const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    Custom: app.globalData.Custom,
    data_all: [],
    show_data: 1,
    hotdata: [],
    newdata: [],
    department: '分类',
    ping_sub: Ping.sub
  },

  onLoad: function (options) {
    app.checkLogin('../../login/login');
    console.log('onLoad')
    var that = this
    //初始化的时候渲染wxSearchdata
    WxSearch.init(that, that.data.CustomBar + that.data.StatusBar + 30, ["\u6c55\u5927\u6574\u5408\u601d\u7ef4", "\u0045\u004c\u0043", "\u7fbd\u6bdb\u7403", "\u5fae\u79ef\u5206", "\u4e2d\u56fd\u8fd1\u73b0\u4ee3\u53f2\u7eb2\u8981","\u9a6c\u514b\u601d\u4e3b\u4e49\u57fa\u672c\u539f\u7406"]);
    WxSearch.initMindKeys(Ping.qiu);
    if(options && options.key){
      this.setData({
        showlast: options.key
      })
      this.wxSearchFn()
    }else{
      this.loadList();
    }

  },

  onShow(){

  },

  loadList(){
    var that = this;
    wx.showLoading({
      title: 'loading...',
    })
    app.post('pingjia/index',{
      die:0
    }).then(function(res){
      that.setData({
        hotdata: res.data.hot,
        newdata: res.data.new
      })
      wx.hideLoading()
    })
  },

  loadhot() {
    var that = this;
    wx.showLoading({
      title: 'loading..',
    })
    app.post('pingjia/loadhot', {
      die: 1
    }).then(function (res) {
      that.setData({
        hotdata: res.data
      })
    })
  },

  wxSearchFn: function () {
    var that = this
    WxSearch.wxSearchAddHisKey(that);
    console.log(this.data.showlast)

    if (this.data.showlast != null && this.data.show_data != 2) {
      console.log("11")
      wx.request({
        url: 'https://www.stuhb.top/api/public/we/pingjia/search',
        data: app.key({
          key: this.data.showlast
        }),
        method: "POST",
        success: res => {
          console.log(res.data.data)
          app.empty(res.data.data) ? that.setData({
            margin: '抱歉，当前学期开课计划中没有该门课哦~',
            show_data: 2,
          }):  that.setData({
            data_all: res.data.data,
            show_data: 2,
            margin: null
          })
          console.log(this.data.data_all)
        },
      })
    }
    if (this.data.show_data == 2) {
      this.setData({
        show_data: 1,
        department: '分类'
      })
      //WxSearch.init(that, that.data.CustomBar + that.data.StatusBar + 30, ["\u7ba1\u7406\u5b66", "\u4e2a\u4eba\u5f62\u8c61\u8bbe\u8ba1", "\u7ec6\u80de\u5de5\u7a0b", "\u4eba\u6587\u5b66\u901a\u8bc6", "\u6587\u521b\u4e13\u9898\uff1a\u4f20\u627f\u4e0e\u521b\u65b0"]);
    }

  },
  wxSearchInput: function (e) {
    var that = this
    that.setData({
      showlast: e.detail.value
    })
    WxSearch.wxSearchInput(e, that);
  },
  wxSerchFocus: function (e) {
    var that = this
    console.log(e)
    this.setData({
      show_data: 1
    })
    WxSearch.wxSearchFocus(e, that);
  },
  wxSearchBlur: function (e) {
    var that = this
    WxSearch.wxSearchBlur(e, that);
  },
  wxSearchKeyTap: function (e) {
    var that = this
    WxSearch.wxSearchKeyTap(e, that);
  },
  wxSearchDeleteKey: function (e) {
    var that = this
    WxSearch.wxSearchDeleteKey(e, that);
  },
  wxSearchDeleteAll: function (e) {
    var that = this;
    WxSearch.wxSearchDeleteAll(that);
  },
  wxSearchTap: function (e) {
    var that = this
    WxSearch.wxSearchHiddenPancel(that);
  },

  hotDel(e){
    let id = e.currentTarget.dataset.id;
    app.ping = this.data.hotdata[id];
    wx.navigateTo({
      url: 'detail',
    })
  },

  newDel(e) {
    let id = e.currentTarget.dataset.id;
    app.ping = this.data.newdata[id];
    wx.navigateTo({
      url: 'detail',
    })
  },

  searchDel(e) {
    let id = e.currentTarget.dataset.id;
    app.ping = this.data.data_all[id];
    wx.navigateTo({
      url: 'detail',
    })  
  },

  toMy(){
    wx.navigateTo({
      url: 'myclass',
    })
  },

  /**
 * 页面相关事件处理函数--监听用户下拉动作
 */
  onPullDownRefresh: function () {
    this.loadList();
    wx.stopPullDownRefresh()
  },

  showModal(){
    this.setData({
      modalName: 'sub'
    })
  },

  hideModal(){
    this.setData({
      modalName: null,
      department: '分类'
    })
  },

  ChooseCheckbox(e){
    var id = e.currentTarget.dataset.value,
        sub = this.data.ping_sub;
    sub.forEach(function(val){
      val.checked = false
    })
    sub[id].checked = true;
    this.setData({
      ping_sub: sub,
      department: sub[id].department
    })
  },

  searchBtn(){
    var that = this;
    wx.showLoading({
      title: 'loading',
    })
    app.post('pingjia/loadEach',{
      department: that.data.department
    }).then(function(res){
      that.setData({
        data_all: res.data,
        show_data: 2,
        margin: null,
        modalName: null
      })
    })
  },

  toExchange(){
    // wx.navigateTo({
    //   url: './e/myclass',
    // })
    wx.showToast({
      title: '开发中...',
      duration:2000,
      icon: 'none'
    })
  }
})