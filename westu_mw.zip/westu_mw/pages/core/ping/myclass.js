// pages/myclass/myclass.js
const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    Custom: app.globalData.Custom,
    show_what: 99
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    this.getMy()
  },

  getMy(){
    var that = this,
        my = app.cache.myClass;
    if(my){
      //有就直接加载
      this.setData({
        data_all: my,
        show_what: my.length-3
      })
    }else{
      app.post('pingjia/loadmy',{
        username: app.user.username,
        psw: app.user.psw
      }).then(function(res){
        //补充本学期课程列表
        var current = {
          name:'当前学期',
          list:[]
        };
        // app.cache.kb_list.forEach(function(val,key){
        //   let cid = val.sub.match(/\[(.*?)\]/);
        //   current.list.push({
        //     sub: val.title,
        //     teacher: val.teacher,
        //     gpa: val.score,
        //     cid: cid[1]
        //   });
        // })
        // res.data.push(current)
        app.saveCache('myClass',res.data)
        that.setData({
          data_all: res.data,
          show_what: res.data.length-1
        })
      })
    }
  },

  show_class: function (e) {
    console.log(e)
    var id = e.currentTarget.id,
        now = this.data.show_what;
    this.setData({
      show_what: id==now?99:id
    })
  },

  release: function (e) {
    this.setData({
      show_what: 99
    })
  },

  /**
   * 评价课程
   */
  toPing(e){
    var item = e.currentTarget.dataset;
    wx.navigateTo({
      url: './ping?id=my&id1=' + item.id1 + '&id2=' + item.id2,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})