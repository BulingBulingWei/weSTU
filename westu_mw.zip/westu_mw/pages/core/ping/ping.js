// pages/core/ping/ping.js
const app = getApp();
Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    textareaValue: '',
    star: 3
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    try {
      if (options.id == 'my') {
        //来自我的页面
        var item = app.cache.myClass[options.id1].list[options.id2];
        this.setData({
          item: item
        })
      } else if (options.id == 'index') {
        //来自首页
        this.setData({
          item: app.ping
        })
      } else if (options.id == 'sumc') {
        //来自医学院评课
        var item = app.ping;
        item.sub = item.a;
        this.setData({
          item: item,
          sumc: true
        })
      }
    } catch (e) {
      app.showError('提示', '获取课程信息失败')
    }

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  Submit(e) {
    var that = this;
    console.log('submit', e)
    var data = e.detail.value,
      item = this.data.item;
    //检查基本信息是否填写完整
    if (!data.attendance || !data.work || !data.exam || !data.active) {
      app.showError('提示', '请填写完基本信息哦')
      return
    }
    //检查是否医学院评课
    if (that.data.sumc == true) {
      that.sumc_submit(data, item);
      return;
    }

    data.star = that.data.star;
    data.cid = item.cid;
    data.teacher = item.teacher;
    data.sub = item.sub;
    data.credits = item.gpa;
    data.openid = app.wx.g_openid;
    wx.showLoading({
      title: 'loading',
    })
    app.post('pingjia/ping', data).then(function (res) {
      console.log('res', res)
      if (res.state == 1) {
        wx.showToast({
          title: '评价成功',
          duration: 1500
        })
        setTimeout(function () {
          console.log('111')
          wx.navigateBack({
            data: 1
          })
        }, 1500)
      }
    })
  },

  sumc_submit(data, item) {
    var that = this;
    data.star = that.data.star;
    data.cid = item.id;
    data.openid = app.wx.g_openid;
    wx.showLoading({
      title: 'loading',
    })
    app.post('pingjia/sumc_ping', data).then(function (res) {
      console.log('res', res)
      if (res.state == 1) {
        wx.showToast({
          title: '评价成功',
          duration: 1500
        })
        setTimeout(function () {
          console.log('111')
          wx.navigateBack({
            data: 1
          })
        }, 1500)
      }
    })
  },

  textareaInput(e) {
    console.log(e.detail.value)
    this.setData({
      textareaValue: e.detail.value
    })
  },

  to_star(e) {
    this.setData({
      star: e.currentTarget.dataset.id + 1
    })
  }
})