// pages/core/kb/list.js
const app = getApp();
const Tools = require('../../../../utils/common.js');
const KB = require('../../../../utils/toKb.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    ColorList: app.globalData.ColorList,
    list: [],
    xn_xq: [{
      xn: '2018-2019',
      xq: 1
    },
    {
      xn: '2018-2019',
      xq: 2,
      checked: true
    },
    {
      xn: '2019-2020',
      xq: 1
    },
    {
      xn: '2019-2020',
      xq: 2
    }
    ],
    xn_index: 1,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.checkLogin('../../../login/login');
    var that = this;
    if (app.user.status == 'stu') {
      var data = KB.load_stu_kb();
      that.setData({
        list: data,
        xn: app.user.xn,
        xq: app.user.xq
      })
    } else if (app.user.status == 'sumc') {
      var data = KB.load_sumc_list();
      that.setData({
        list: data,
        xn: '2018-2019',
        xq: 2
      })
    }
  },

  edit(e) {
    let index = e.currentTarget.dataset.index;
    
  },

  exchange(e){
    let index = e.currentTarget.dataset.index;
    this.setData({
      modalName: index
    })
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    app.removeCache('kb_list_' + app.user.xn + '-' + app.user.xq);
    this.onLoad();
    wx.stopPullDownRefresh()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },


  ping_kb(e) {
    if (app.user.department == '医学院') {
      app.showError('提示', '医学院的同学暂不支持评课哦')
      return;
    }
    console.log(e)
    var list = this.data.list,
      index = e.currentTarget.dataset.index,
      item = list[index];
    app.ping = {
      sub: item.title,
      cid: item.cid,
      teacher: item.teacher
    }
    wx.navigateTo({
      url: '..//ping?id=index',
    })
  },

  hideModal(e) {
    this.setData({
      modalName: null
    })
  },


})