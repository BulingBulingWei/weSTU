// pages/core/kb/list.js
const app = getApp();
const Tools = require('../../../../utils/common.js');
const KB = require('../../../../utils/toKb.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    ColorList: app.globalData.ColorList,
    list: [],
    xn_xq: [{
      xn: '2018-2019',
      xq: 1
    },
    {
      xn: '2018-2019',
      xq: 2,
      checked: true
    },
    {
      xn: '2019-2020',
      xq: 1
    },
    {
      xn: '2019-2020',
      xq: 2
    }
    ],
    xn_index: 1,
  },

  /**
   * 加载自定义课表
   */
  load_add() {
    var add = [],
      list = this.data.list;
    if (app.empty(app.cache.add)) {
      return;
    } else {
      add = app.cache.add;
    }
    add.forEach(function (val, key) {
      add[key].id = key + 100;
      val.nick = '';
      val.title = val.sub;
      val.showtime = '周' + Tools.toStrDay(val.day) + val.jieci + '节 ';
      list.push(val);
    })
    app.saveCache('add', add);
    this.setData({
      list: list
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    app.checkLogin('../../../login/login');
    var that = this;
    if (app.user.status == 'stu') {
      var data = KB.load_stu_kb();
      that.setData({
        list: data,
        xn: app.user.xn,
        xq: app.user.xq
      })
    } else if (app.user.status == 'sumc') {
      var data = KB.load_sumc_list();
      that.setData({
        list: data,
        xn: '2018-2019',
        xq: 2
      })
    }
    that.load_add();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    app.removeCache('kb_list_' + app.user.xn + '-' + app.user.xq);
    this.onLoad();
    wx.stopPullDownRefresh()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },



  edit(e) {
    wx.navigateTo({
      url: 'edit?index=' + e.currentTarget.dataset.index + '&url=list',
    })
  },

  del_kb(e) {
    console.log(e)
    //判断是否为自定义课程
    var list = this.data.list,
      index = e.currentTarget.dataset.index,
      kb_list = app.cache.kb_list,
      add = app.cache.add;
    console.log(list[index])
    if (list[index].id < 100) {
      kb_list.forEach(function (val, key) {
        if (val.id == list[index].id) {
          kb_list.splice(key, 1);
        }
      })
      app.saveCache('kb_list', kb_list);
      app.user.status == 'stu' ? KB.sort_stu_kb(kb_list) : 1;
    } else {
      add.forEach(function (val, key) {
        if (val.id == list[index].id) {
          add.splice(key, 1);
        }
      })
      app.saveCache('add', add);
      var sort_add = KB.sort_add_kb(add);
    }
    list.splice(index, 1);
    this.setData({
      list: list,
      modalName: null
    })
  },

  ping_kb(e) {
    if (app.user.department == '医学院') {
      app.showError('提示', '医学院的同学暂不支持评课哦')
      return;
    }
    console.log(e)
    var list = this.data.list,
      index = e.currentTarget.dataset.index,
      item = list[index];
    app.ping = {
      sub: item.title,
      cid: item.cid,
      teacher: item.teacher
    }
    wx.navigateTo({
      url: '../../ping/ping?id=index',
    })
  },

  addClass(e) {
    wx.redirectTo({
      url: 'edit?index=add&url=list',
    })
  },

  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },

  hideModal(e) {
    this.setData({
      modalName: null
    })
  },

  showxn(e) {
    if (app.user.status != 'stu') return;
    var xn_xq = this.data.xn_xq;
    for (var i in xn_xq) {
      xn_xq[i].xn == app.user.xn && xn_xq[i].xq == app.user.xq ? xn_xq[i].checked = true : xn_xq[i].checked = false;
    }
    this.setData({
      xn_xq: xn_xq,
      modalName: 'RadioModal',

    })
  },

  xnxq(e) {
    console.log(e)
    var xn_xq = this.data.xn_xq,
      index = e.detail.value;
    app.user.xn = xn_xq[index].xn;
    app.user.xq = xn_xq[index].xq;
    app.saveCache('user', app.user)
    for (var i in xn_xq) {
      i == index ? xn_xq[i].checked = true : xn_xq[i].checked = false;
    }
    this.hideModal();
    var data = KB.load_stu_kb();
    this.setData({
      list: data,
      xn_xq: xn_xq,
      xn: app.user.xn,
      xq: app.user.xq
    })
  }
})