// pages/core/ping/sumc_detail.js
var Ping = require('../../../../utils/ping.js')
const app = getApp();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        sumcList: Ping.sumc
    },

    onReady: function (options) {
        var that = this,
        sumc = that.data.sumcList,
        list = [];

        var temp = {
            nj: sumc[0].c,
            cl: [sumc[0]]
        }
        sumc[0].id = 0;
        for(let i=1; i<sumc.length; i++){
            if(sumc[i].c == temp.nj){
                temp.cl.push(sumc[i])
            }else{
                list.push(temp);
                temp = {
                    nj: '',
                    cl: []
                }
                temp.nj = sumc[i].c
                temp.cl.push(sumc[i])
            }
        }
        //结束补最后一个
        list.push(temp);
        this.setData({
            list: list
        })
    },

    toDetail(e) {
        let item = e.currentTarget.dataset.id;
        app.ping = item;
        wx.navigateTo({
            url: 'detail',
        })
    },


    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    }
})