// pages/core/cj/cj.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    remind: '加载中',
    all: 0,
    ave: 0,
    gpa: 0,
    cjInfo: [],
    stu: false
  },

  onLoad: function() {
    var user = app.user;
    var that = this;
    app.checkLogin();
    if (!app.user.psw && app.user.status == "stu") {
      wx.showModal({
        title: '提示',
        content: '您好，使用查询成绩功能需要先登录，是否前往？',
        success: function (res) {
          if (res.confirm) {
            wx.navigateTo({
              url: '../../login/login'
            })
          }
        }
      })
      return;
    }
    if (!user.ucpsw && app.user.status == "sumc") {
      that.setData({
        remind: '未登陆成绩查询页面'
      })
      setTimeout(function() {
        wx.showModal({
          title: '提示',
          content: app.user.name + "同学您好！由于医学院成绩查询系统的密码独立于其他系统，需要登陆账号后才能使用，是否前往？",
          cancelText: '以后再说',
          confirmText: '前往绑定',
          success: function(res) {
            if (res.confirm) {
              wx.redirectTo({
                url: '../../login/login?step=1'
              });
            } else {
              wx.navigateBack();
            }
          }
        });
      }, 1000);
    } else if (app.user.status == "stu") {
      // if(app.cache.showcj!='show'){
      //   app.showError('提醒','由于学分及GPA并非来源于学分制，仅供参考，学分及GPA请以学分制为准！待所有成绩公布之后再恢复学分制的访问，谢谢！')
      //   app.saveCache('showcj','show')
      // }
      this.setData({
        stu: true
      })
    }
  },

  onReady: function() {
    var that = this;
    var user = app.user,
      cjInfo = that.data.cjInfo;
    var that = this;
    var user = app.user,
      cjInfo = that.data.cjInfo;
    that.setData({
      id: user.uid,
      name: user.name
    });
    //判断并读取缓存
    if (that.data.stu) {
      if (app.cache.cj) {
        stucj(app.cache.cj);
      }
      loadstu();
    } else {
      if (app.cache.cj) {
        sumccj(app.cache.cj);
      }
      loadsumc();
    }

    function loadstu() {
      wx.showNavigationBarLoading();
      wx.request({
        //url: "https://www.stuhb.top/beta0.2.0/stu/cj.php",
        url: app.server + 'stucj/index',
        method: 'POST',
        data: app.key({
          username: app.user.username,
          userid: app.user.uid,
          psw: app.user.psw,
          name: app.user.name,
          g_openid: app.wx.g_openid

        }),
        success: function(res) {
          if (res.data.state == 1) {
            var data = res.data.data;
            if (data.cj) {
              //保存成绩缓存
              console.log('返回数据', data.cj)
              app.saveCache('cj', data); //此处保存的是传回的全部数据
              stucj(data);
              wx.showToast({
                title: '同步成功！',
                icon: 'none'
              })
              // that.setData({
              //   modalName: 'bottomModal'
              // }), setTimeout(function () {
              //   that.setData({
              //     modalName: ''
              //   }), app.modal = {}
              // }, 2000)
            } else if (app.cache.cj) {
              wx.showToast({
                title: res.data.msg || '刷新失败！',
                icon: 'none'
              })
            } else {
              that.setData({
                remind: '暂无成绩'
              });
            }
          } else if (app.cache.cj) {
            wx.showToast({
              title: res.data.msg||'刷新失败！',
              icon: 'none'
            })
          } else {
            //app.removeCache('cj');
            that.setData({
              remind: res.data.msg || '未知错误'
            });
          }
        },
        fail: function(res) {
          if (app.cache.cj) {
            wx.showToast({
              title: '刷新失败！',
              icon: 'none'
            })
          } else if (that.data.remind == '加载中') {
            that.setData({
              remind: '网络错误'
            });
          }
        },
        complete: function() {
          wx.hideNavigationBarLoading();
        }
      })
    }

    function stucj(res) {
      console.log("data", res)
      var data = res.cj,
        all = res.all;
      //循环每个学期成绩
      var cjInfo = [];
      for (var i = data.length - 1; i >= 0; i--) {
        var temp = {
          term: '',
          open: false,
          num: 0,
          score: 0,
          gpa: []
        };
        temp.cj = data[i].cj;
        temp.term = data[i].name; //学期名
        temp.num = data[i].all.num;
        temp.score = data[i].all.xf || data[i].all.credit;
        temp.gpa = data[i].all.gpa;
        console.log('temp', temp)
        cjInfo.push(temp);
      }
      cjInfo[0].open = true;
      that.setData({
        cjInfo: cjInfo,
        all: all.num,
        ave: all.xf || all.credit,
        gpa: all.gpa,
        remind: ''
      })
    }

    function sumccj(data) {
      console.log("data", data)
      //循环每个学期成绩
      var cjInfo = [];
      for (var i = data.length - 1; i > 0; i--) {
        var temp = {
          term: '',
          open: false,
          num: 0,
          ave: 0,
          cj: []
        };
        var ave = 0,
          all = 0,
          info = {
            sub: '',
            score: ''
          };
        temp.cj = [];
        temp.term = termstr(i); //学期名
        temp.num = data[i].length;
        //平均分
        data[i].forEach(v => {
          info = {
            sub: '',
            score: ''
          }
          all += parseFloat(v.score);
          info.sub = v.sub;
          if (v.re1 == '') {
            info.score = v.score;
          } else if (v.re2 == '') {
            info.score = v.re1;
          } else if (v.re3 == '') {
            info.score = v.re2;
          } else {
            info.score = v.re3;
          }
          temp.cj.push(info);
        })
        ave = all / data[i].length;
        temp.ave = ave.toFixed(2);
        console.log('temp', temp)
        cjInfo.push(temp);
      }
      cjInfo[0].open = true;
      that.setData({
        all: data[0].all,
        ave: data[0].gua,
        gpa: data[0].re,
        cjInfo: cjInfo,
        remind: ''
      })
    }

    function loadsumc() {
      if (!app.user.ucpsw) {
        return;
      }
      wx.showNavigationBarLoading();
      wx.request({
        url: "https://www.stuhb.top/beta0.2.0/sumc/score.php",
        method: 'POST',
        data: app.key({
          userid: user.uid,
          cjpsw: user.ucpsw
        }),
        success: function(res) {
          if (res.data.state == 1) {
            var data = res.data;
            if (data.cj) {
              //保存成绩缓存
              app.saveCache('cj', data.cj);
              sumccj(data.cj);
            } else if (app.cache.cj) {
              wx.showToast({
                title: '刷新失败！',
                icon: 'none'
              })
            } else {
              that.setData({
                remind: '暂无成绩'
              });
            }
          } else if (app.cache.cj) {
            wx.showToast({
              title: '刷新失败！',
              icon: 'none'
            })
          } else {
            //app.removeCache('cj');
            that.setData({
              remind: res.data.message || '未知错误'
            });
          }

        },
        fail: function(res) {
          if (app.cache.cj) {
            wx.showToast({
              title: '刷新失败！',
              icon: 'none'
            })
          } else if (that.data.remind == '加载中') {
            that.setData({
              remind: '网络错误'
            });
          }
        },
        complete: function() {
          wx.hideNavigationBarLoading();
        }
      })
    }

    function changeNum(num) {
      var china = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
      var arr = [];
      var n = ''.split.call(num, '');
      for (var i = 0; i < n.length; i++) {
        arr[i] = china[n[i]];
      }
      return arr.join("")
    }

    function termstr(num) {
      console.log('num', num)
      var china = ['零', '一', '二', '三', '四', '五', '六', '七', '八', '九'];
      var xn = china[Math.ceil((num) / 2)]; //小数点后面有数字则进一
      var xq = (num % 2 == 0) ? '下' : '上';
      var term = '大' + xn + xq + '学期';
      return term;
    }
  },

  showcj: function(e) {
    console.log(e)
    var index = e.currentTarget.dataset.index,
      cj = this.data.cjInfo;
    var flag = cj[index].open;
    if (flag == true) {
      cj[index].open = false;
    } else {
      cj[index].open = true;
    }
    this.setData({
      cjInfo: cj
    })
  },

  onPullDownRefresh: function() {
    if (that.data.stu) {
      loadstu();
    } else if (!that.data.stu) {
      loadsumc();
    }
    wx.stopPullDownRefresh();
  },
  onShareAppMessage: function() {

  },

  toPing(e){
    app.ping = e.currentTarget.dataset.cj;
    wx.navigateTo({
      url: '../ping/ping?id=index',
    })
  }
})