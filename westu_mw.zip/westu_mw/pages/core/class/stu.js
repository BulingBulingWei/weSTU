// pages/core/class/stu.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    tagList: [],
    value: '',
    subIndex: 0,
    page: 1,
    list: [],
    userInfo: app.wx.userInfo
  },

  /**
   * 搜索学生
   */
  search(e){
    var that = this,
      key = that.data.value,
      page = that.data.page;
      console.log('key',key)
    if(typeof (key) == 'string') key = key.replace(/(^\s*)|(\s*$)/g, '');//去除首尾空格
    //防注入
    var temp = key;
    if (typeof (key) == 'string') key = key.replace(/\\|\/|\.|\'|\"|\<|\>/g, function (str) { return ''; });
    if(key.length<temp.length){
      wx.showError('提示', '请勿输入非法字符"\","/",".","\'","\"","<",">"!');
      return;
    }
    if (app.empty(key)) {
      app.showError('提醒', '请先输入搜索关键词');
      return;
    }
    
    that.setData({
      remind:true,
      isSearch: true
    })
    wx.request({
      url: app.server + 'stukb/searchXs',
      data: app.key({
        x_openid: app.wx.x_openid,
        value: key,
        uid: app.user.uid,
        page: page
      }),
      method: 'POST',
      success: function(res) {
        if (res.data.state == 1) {
          console.log(res.data)
          var list = that.data.list,
            data = res.data.data;
          res.data.data.forEach(function (val) {
            list.push(val)
          })
          var margin = '';
          app.empty(data) ? margin = '你搜索的同学正在飞往头大的路上' : data.length < 30 ? margin = '--我也是有底限的--' : margin = '--下拉加载更多--';
          that.setData({
            list: list,
            margin: margin,
          })
        } else {
          app.showError('查询失败', res.data.msg || '查询失败，请稍后重试');
        }
      },
      fail: function(res) {},
      complete: function(res) {
        that.setData({
          remind:false
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    if(!app.empty(options)){
      this.setData({
        value: options.key
      })
      this.search(options.key);
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var kb_list = app.cache.kb_list,
      tagList = [],
      temp = {};
    kb_list.forEach(function(val){
      temp = {};
      temp = {
        title: val.title,
        cid: val.cid
      }
      tagList.push(temp);
    })
    this.setData({
      tagList: tagList
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    if (this.data.margin == '--我也是有底限的--') return;
    var page = this.data.page;
    page++;
    this.setData({
      page: page
    })
    this.search()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  searchInput(e) {
    this.setData({
      value: e.detail.value
    })
  },

  searchCancel(e) {
    this.setData({
      value: '',
      isSearch: false,
      list: []
    })
  },

  tagSearch(e) {
    var index = e.currentTarget.dataset.index,
      tagList = this.data.tagList[index];
    this.setData({
      value: tagList.cid
    })
    this.search();
  },
})