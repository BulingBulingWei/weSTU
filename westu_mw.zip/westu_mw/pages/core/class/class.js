// pages/core/class/class.js
// pages/core/xs/class.js
const app = getApp();
const KB = require('../../../utils/toKb.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    Custom: app.globalData.Custom,
    classList: [],
    njList: [2015, 2016, 2017, 2018,2019],
    index: [0],
    week: app.time.week,
    TabCur: 0,
    MainCur: 0,
    VerticalNavTop: 0,
    load: true,
    animation: false,
    classname: app.user.classname
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    app.checkLogin('../../login/login');
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.loadClass();
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },


  btn: function () {
    var x = 0,
      classname = this.data.classname,
      name = '';
      classname == app.user.classname ? name = 'kb' : name = 'kb-' + classname;

    KB.load_sumc_kb(classname);
    //简化名称
    var abbr = KB.sortName(classname);
    //开始定时检查
    x>60 || countSecond();
  console.log('name',name)
    function countSecond() {
      var that = this;
      x = x + 1
      console.log('x', x)
      if (!app.empty(app.cache[name])) {
        wx.redirectTo({
          url: '../kb/sumckb?view=' + name + '&abbr=' + abbr,
        })
        return;
      }
      setTimeout(function () {
        countSecond();
      }, 500)
    }
  },

  changeWeek: function (e) {
    this.setData({
      week: e.detail.value
    })
  },

  changeClass: function (e) {
    console.log(e);
    var index = e.detail.value;
    this.setData({
      index: index
    })
  },

  loadClass: function () {
    console.log("?????");
    var that = this;
    var classList = app.cache.classList;
    if (!app.empty(classList)) {
     that.setData({
       classList: classList
     })
     that.toMy();
    } else {
      wx.showLoading({
        title: 'loading...',
      });
      wx.request({
        method: 'GET',
        url: app.server + 'sumckb/loadclass',
        success: function (res) {
          if(res.data.state == 1){
            let list = {
              2015: {id: 0,list:[]},
              2016: { id: 1, list: [] },
              2017: { id: 2, list: [] },
              2018: { id: 3, list: [] },
              2019: { id: 4, list: [] }
            };  
            res.data.data.forEach(function(val,key){
              let temp = val.match(/(\d\d\d\d)级(.*)/),
                nj = temp[1];
              console.log(temp)
              list[nj].list.push(temp[2]);
            })
            app.saveCache('classList',list)
            that.setData({
              classList: list
            })
            that.toMy();
          }else{
            app.showError('错误','下载列表失败，请退出该页面重试！');
          }
        },
        fail: function (res) {
          wx.hideLoading();
          wx.showModal({
            title: '请求超时',
            content: '可能是您的网络环境不太好，亦或者是服务端出现了故障',
            confirmText: '重新加载',
            cancelText: '取消',
            success: function (res) {
              if (res.confirm) {
                that.loadClass();
              }
            }
          });
        },
        complete: function(res){
          wx.hideLoading();
        }
      })
    }
  },

  toMy(){
    var that = this,
      classname = app.user.classname,
      list = this.data.classList,
      preg = classname.match(/(\d\d\d\d)级(.*)/),
      nj = preg[1],
      id = nj == 2015 ? 0 : 
           nj == 2016 ? 1 :
           nj == 2017 ? 2 :
           nj == 2018 ? 3 : 4,
      class_id = 0;
    console.log('list', list)
    list[nj].list.forEach(function(val,key){
      val == preg[2] ? class_id = key : 1; 
    })
    this.setData({
      TabCur: id,
      MainCur: id,
      njCur: id,
      class_id: class_id,
      VerticalNavTop: (id - 1) * 50,
    })
  },

  /**
   * 滚到当前班级
   */
  toWeek(){
    var that = this;
    if (app.empty(app.view)) {
      var view = app.user.classname
    } else {
      var view = app.view
    }
    console.log('view',view)
    var list = app.cache.loadClass;
    list.forEach(function (val, key) {
      if (val == view) {
        var index = [];
        index.push(key);
        console.log(val, key, index);
        that.setData({
          index: index,
        })
      }
    })
  },

  toClass(e){
    console.log(e.currentTarget.dataset)
    let id = e.currentTarget.dataset.id,
      classList = this.data.classList,
      nj = e.currentTarget.dataset.nj,
      list = classList[nj].list;
    this.setData({
      class_id: id,
      njCur: nj - 2015,
      classname: nj+'级'+list[id]
    })
  },

  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      MainCur: e.currentTarget.dataset.id,
      VerticalNavTop: (e.currentTarget.dataset.id - 1) * 50
    })
  },
  VerticalMain(e) {
    let that = this;
    let list = this.data.classList;
    let tabHeight = 0;
    if (this.data.load) {
      console.log('load',list[2017])
      for (let i = 2015; i < 2019; i++) {
        console.log(i,list[i],list[i].id)
        let view = wx.createSelectorQuery().select("#main-" + list[i].id);
        view.fields({
          size: true
        }, data => {
          console.log('data',data)
          list[i].top = tabHeight;
          tabHeight = tabHeight + data.height;
          list[i].bottom = tabHeight;
        }).exec();
      }
      that.setData({
        load: false,
        classList: list
      })
    }
    let scrollTop = e.detail.scrollTop + 20;
    for (let i = 2015; i < 2019; i++) {
      if (scrollTop > list[i].top && scrollTop < list[i].bottom) {
        that.setData({
          VerticalNavTop: (list[i].id - 1) * 50,
          TabCur: list[i].id,
          animation: true
        })
        return false
      }
    }
  }
})