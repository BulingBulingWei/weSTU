// pages/core/kb/sumckb.js
const app = getApp();
const Tools = require('../../../utils/common.js');
const KB = require('../../../utils/toKb.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    
    TabCur: 0,
    navigation: '我的课表',
    scrollLeft: 0,
    scrollTop: 50,
    days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    dates: ['02-24', '02-25', '02-26', '02-27', '02-28', '03-01', '03-02'],
    jieci: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 'A', 'B'],
    kbArr: [[], [], []],
    week: 1,
    modal: false,
    time_list: Tools.stu_time,
    animation: 0
  },

  /**
   * 将其展示为三段课表
   * @param {int} current 
   */
  Look(week) {
    var that = this,
      template = this.data.template,
      navigation = Tools.toStrWeek(week),
      kbArr = this.data.kbArr,
      TabCur = this.data.TabCur;
    //计算日期
    this.setdate(week);
    //计算课表

    for (var i = week - 1; i <= week + 1; i++) {
      var w = tow(i);
      console.log('w',i, w)
      if (app.empty(template[w]['lesson'])) {
        that.showKb(w)
      }
    }
    kbArr[tot(TabCur)] = template[tow(week)];
    kbArr[tot(TabCur - 1)] = template[tow(week-1)];
    kbArr[tot(TabCur + 1)] = template[tow(week+1)];
    this.setData({
      kbArr:kbArr,
      week: week
    })

    //设置领班标题
    var view = this.data.view,
      abbr = this.data.abbr;
    navigation = app.empty(view) ? navigation : navigation + '~' + abbr;
    this.setData({
      navigation: navigation,
    })

    function tow(i) {
      return i <= -1 ? 19 : i >= 20 ? 0 : i;
    }
    function tot(i) {
      return i == -1 ? 2 : i == 3 ? 0 : i;
    }
  },

  /**
   * 展示课表
   * TabCur 当前的值
   * week 第几周
   */
  showKb(week = 1) {
    var kb_list = app.cache.kb_list,
      list = [],
      template = this.data.template,
      flag = false;
    if (template[week].hide) {
      if (app.empty(this.data.view)) {
        //本班课表
        kb = app.cache['kb'][week];
        console.log('kb', kb);
        template[week].hide = false;
        //正式课表上色
        kb.forEach(function (val, key) {
          flag = false;
          for (var i = 0; i < kb_list.length; i++) {
            if (val.sub == kb_list[i].sub) {
              flag = true;
              kb[key].color = kb_list[i].color;
              kb[key].nick = kb_list[i].nick;
              kb[key].start = parseInt(kb[key].start);
              kb[key].length = parseInt(kb[key].length);
              kb[key].id = kb_list[i].id;

              break;
            }
          }
          flag == false ? kb[key] = [] : 1; //不显示删除课表
        })
        //自定义课表
        if (app.empty(!app.cache.kb_add)) {
          var kb_add = app.cache.kb_add[week];
          kb_add.forEach(function (val, key) {
            kb.push(val);
          })
        }
        template[week].lesson = kb;
        console.log('template', template);
        this.setData({
          template: template
        })
      } else {
        var name = this.data.view,
          kb = app.cache[name][week],
          ColorList = this.data.ColorList,
          cid = 0,
          len = ColorList.length;
        //邻班课表
        template[week].hide = false;
        //正式课表上色
        kb.forEach(function (val, key) {
          cid = val['index'];
          if (cid < len) {
            console.log('color', cid, val)
            kb[key].color = ColorList[cid].color;
          } else {
            console.log('??', cid - len)
            kb[key].color = ColorList[cid - len].color;
          }
        })
        template[week].lesson = kb;
        console.log('template', template);
        this.setData({
          template: template
        })
      }
    }

  },

  /**
   * 下载汕医课表
   */
  load_sumc_kb(e) {
    var that = this,
      kb_list = KB.load_sumc_list();
    var name = app.empty(e) ? 'kb' : e;
    var kb = app.cache[name];
    if (!app.empty(kb)) {
      that.Look(app.time.week);
      this.setData({
        week: app.time.week,
        TabCur: 0
      })
    } else if (KB.load_sumc_kb(e)) {
      that.Look(app.time.week);
      that.setData({
        TabCur: 0
      })
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({//自动更新时需重新设值
      StatusBar: app.globalData.StatusBar,
      CustomBar: app.globalData.CustomBar,
      ColorList: KB.colors,
      CustomHeight: app.globalData.CustomHeight,
      CustomWidth: app.globalData.CustomWidth,
    })
    if (app.user.is_bind == false) {
      wx.redirectTo({
        url: '../../login/login'
      })
      return;
    }
    this.init(options)
  },
  /**
   * 重置页面
   */
  init(options) {
    console.log('options', options)
    if (!app.empty(options)) {
      options.view != 'kb' && this.setData({
        view: options.view,
        abbr: options.abbr
      })
    }
    var list = [];
    for (var i = 0; i < 20; i++) {
      list.push({
        hide: true
      })
    }
    this.setData({
      width: (750 - 70) / 7,
      height: (this.data.CustomHeight - 40) / 6.5,
      template: list
    })
    //加载课表
    if (!app.empty(this.data.view)) {
      //分享课表or邻班课表
      if(!this.data.stopRefresh){
        this.refresh();//刷新
      }else{
        this.load_sumc_kb();
      }
    } else {
      this.load_sumc_kb();
    }
  },

  /**
   * 同步加载课表
   */
  loadkbSync() {
    var _that = this;
    var x = 0;
    function countSecond() {
      var that = this;
      x = x + 1
      console.log('x', x)
      var kb_list = app.cache['kb_list_' + app.user.xn + '-' + app.user.xq];
      console.log('kb_list', kb_list)
      if (!app.empty(kb_list)) {
        console.log(kb_list)
        _that.init();
        KB.sort_stu_kb(kb_list);
        _that.showKb(app.time.week);
        _that.setData({
          TabCur: app.time.week
        })
        return;
      }
      if (x > 30) {
        //app.showError('提示', '课表加载失败')
        return;
      }
      setTimeout(function () {
        countSecond();
      }, 500)
    }
    console.log('here')
    KB.load_sumc_kb()
    //开始定时检查
    countSecond();
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      design: app.design
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    this.refresh();
    wx.stopPullDownRefresh()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    var view = this.data.view,
        abbr = this.data.abbr;
    app.empty(view) ? view = 'kb-'+ app.user.classname:1;
    app.empty(abbr) ? abbr = KB.sortName(app.user.classname):1;
    return {
        title: '分享课表——' + abbr,
      path: '/pages/core/kb/sumckb?view=' + view + ' & abbr=' + abbr,
    }
  },

  get_detail(cid){
    var modal = this.data.modal,  
        that = this;

    wx.request({
      url: app.server + 'syjx/getDetail',
      method: 'post',
      data: app.key({
        cid: cid
      }),
      success(res){
        console.log('kb',res)
        if (!app.empty(res.data[1]) && res.data[1]['errcode']==0){
          var d = res.data[1];
          modal.content = d.teaching_content;
          modal.type = d.teaching_formname;
          modal.teacher= d.teachername;
          modal.num = d.stu_num;
          modal.room = d.areaname;
          that.setData({
            modal: modal
          })
        }
      }
    })
  },

  append: function (e) {
    var that = this;
    wx.showActionSheet({
      itemList: ['刷新课表', '个性化背景', '课程列表', '添加课程'],
      success: function (res) {
        switch (res.tapIndex) {
          case 0:
            that.refresh()
            break;
          case 1:
            wx.navigateTo({
              url: 'append/design',
            })
            break;
          case 2:
            wx.navigateTo({
              url: 'append/list',
            })
            break;
          case 3:
            wx.navigateTo({
              url: 'append/edit?index=add&url=sumc',
            })
            break;
        }
      },
      fail: function (res) { },
      complete: function (res) { },
    })
  },

  edit(e) {
    if (!app.empty(this.data.view)) return;
    wx.navigateTo({
      url: 'append/edit?index=' + this.data.modal.id + '&url=sumc',
    })
  },

  // longtap(e) {
  //   console.log('long', e)
  //   if (!app.empty(this.data.view)) return;
  //   var index = e.currentTarget.dataset.index,
  //     TabCur = this.data.TabCur,
  //     kb = this.data.template[TabCur].lesson[index],
  //     that = this;
  //   wx.showActionSheet({
  //     itemList: ['编辑课程', '删除课程'],
  //     success: function (res) {
  //       switch (res.tapIndex) {
  //         case 0:
  //           wx.navigateTo({
  //             url: 'append/edit?index=' + kb.id + '&url=sumc',
  //           })
  //           break;
  //         case 1:
  //           wx.showModal({
  //             title: '提示',
  //             content: '确认删除后该课程将不会显示在课表中，删除后可在>我的>系统设置 中恢复默认课表',
  //             success: function (res) {
  //               if (res.confirm) {
  //                 that.del_kb(kb.id);
  //               }
  //             },
  //           })
  //           break;
  //       }
  //     },
  //     fail: function (res) { },
  //     complete: function (res) { },
  //   })
  // },

  del_kb(id) {
    //判断是否为自定义课程
    var kb_list = app.cache.kb_list,
      add = app.cache.add;
    if (id < 100) {
      kb_list.forEach(function (val, key) {
        if (val.id == id) {
          kb_list.splice(key, 1);
        }
      })
      app.saveCache('kb_list', kb_list);
    } else {
      add.forEach(function (val, key) {
        if (val.id == id) {
          add.splice(key, 1);
        }
      })

      app.saveCache('add', add);

      var sort_add = KB.sort_add_kb(add);
    }
    wx.redirectTo({
      url: 'sumckb',
    })
  },

  showModal: function (e) {
    var index = e.currentTarget.dataset.index,
      TabCur = this.data.TabCur,
      kb = this.data.kbArr[TabCur].lesson[index];
    this.setData({
      modal: kb,
      scrollTop: 50
    })
    this.get_detail(kb.cid);
  },

  hideModal: function () {
    this.setData({
      modal: false
    })
  },

  tabSelect(e) {
    var tab = e.currentTarget.dataset.id,
        TabCur = this.data.TabCur,
        week = this.data.week;
    var c = tab - week;
    if(c > 0){
      TabCur ++;
    }else if(c < 0){
      TabCur --;
    }
    this.setData({
      TabCur: tot(TabCur),
      scrollTop: 50,
      showWeek: false
    })
    this.Look(tow(tab));

    function tow(i) {
      return i <= -1 ? 19 : i >= 20 ? 0 : i;
    }
    function tot(i) {
      return i == -1 ? 2 : i == 3 ? 0 : i;
    }
  },

  swiper: function (e) {
    var that = this;
    var current = e.detail.current,
      week = this.data.week,
      TabCur = that.data.TabCur;
    //计算变动的周数
    var c = current - TabCur;
    if (c == 1 || c == -2){
      week++;
    }else if(c == -1 || c == 2){
      week--;
    }
    this.setData({
      TabCur: current,
      scrollTop: 50,
      showWeek: false
    })
    console.log(current)
    this.Look(tow(week));

    function tow(i) {
      return i <= -1 ? 19 : i >= 20 ? 0 : i;
    }
  },

  scroll: function (e) {
    console.log('scorll', e)
    var scroll = e.detail.scrollTop;
    if (scroll > 60) {
      this.setData({
        scrollTop: 50
      })
    }
  },
  showWeek(e) {
    this.setData({
      showWeek: true
    })
  },
  /*
   *获取当前周日期
   */
  setdate: function (week) {
    var a = new Date(2019, 7, 17);
    var dates = [];
    var start = Date.parse(a);
    var len = 24 * 3600 * 1000;

    for (var j = 1; j <= 7; j++) {
      var end = start + len * 7 * week + j * len;
      var D = Tools.GetTime(end);
      dates.push((D.M + 1) + '-' + D.D);
    }
    console.log('dayes', dates)
    this.setData({
      dates: dates
    })
  },

  refresh(){
    var x=0;
    var that = this;
    if(this.data.view){
      var name = this.data.view,
          classname = name.replace(/kb-/,'')
      KB.load_sumc_kb(classname);
    }else{
      var name = 'kb'
      KB.load_sumc_kb();
    }

    //开始定时检查
    x > 60 || countSecond();
    console.log('name', 'kb-'+name)
    function countSecond() {
      x = x + 1
      console.log('x', x)
      if (!app.empty(app.cache[name])) {
        that.setData({
          stopRefresh : true
        })
        console.log('12e')
        that.init();
        return;
      }
      setTimeout(function () {
        countSecond();
      }, 500)
    }
  },

  navigateBack(){
    if (getCurrentPages().length > 1) {
      wx.navigateBack({
        delta: 1
      })
    } else {
      wx.reLaunch({
        url: '/pages/index/index',
      })
    }
  }
})