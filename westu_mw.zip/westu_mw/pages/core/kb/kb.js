// pages/core/kb/kb.js
const app = getApp();
const Tools = require('../../../utils/common.js')
const KB = require('../../../utils/toKb.js');
Page({
  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    ColorList: KB.colors,
    CustomHeight: app.globalData.CustomHeight,
    CustomWidth: app.globalData.CustomWidth,
    TabCur: 0,
    navigation: '我的课表',
    scrollLeft: 0,
    scrollTop: 50,
    days: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
    dates: ['02-24', '02-25', '02-26', '02-27', '02-28', '03-01', '03-02'],
    jieci: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0, 'A', 'B', 'C'],
    week: 1,
    modal: false,
    time_list: Tools.stu_time,
    animation: 0,
    xn_xq: [{
        xn: '2019-2020',
        xq: 1
      },
      {
        xn: '2019-2020',
        xq: 2
      },
      {
        xn: '2020-2021',
        xq: 1,
        checked: true
      },
      {
        xn: '2020-2021',
        xq: 2
      },
      {
        xn: '2021-2022',
        xq: 1
      },
      {
        xn: '2021-2022',
        xq: 2
      }
    ],
    xn_index: 2,
    modalName: null
  },

  /**
   * 展示课表
   */
  showKb(index = 0) {
    this.setdate();
    var cache = app.cache['kb_' + app.user.xn + '-' + app.user.xq];
    if (app.empty(cache)) {
      app.showError('提示', '当前学期暂无课表信息')
      return;
    }
    var kb = cache[index],
      TabCur = this.data.TabCur,
      navigation = Tools.toStrWeek(TabCur),
      list = [],
      template = this.data.template;
    console.log("template")  
    console.log(index);
    if (template[index].hide) {
      template[index].hide = false;
      //自定义课表
      if (app.empty(!app.cache.kb_add)) {
        var kb_add = app.cache.kb_add[index];
        kb_add.forEach(function (val, key) {
          kb.push(val);
        })
      }
      template[index].lesson = kb;
      this.setData({
        template: template,
      })
    }
    this.setData({
      navigation: navigation,
    })
  },

  /**
   * 下载汕大课程列表
   */
  loadkb() {
    var that = this;
    var kb_list = app.cache.kb_list,
      kb = app.cache.kb,
      user = app.user;
    if(app.empty(user.psw)){
      wx.showModal({
        title: '提示',
        content: '您好，自动登录未输入密码，从学分制更新课表功能需要先登录，是否前往？',
        success:function(res){
          if(res.confirm){
            wx.navigateTo({
              url: '../../login/login'
            })
          }
        }
      })
      return;
    }
    if (!app.empty(kb_list) && app.empty(kb)) {
      var sort_kb = Tools.sort_stu_kb(kb_list);
      that.showKb(app.time.week);
      this.setData({
        TabCur: app.time.week
      })
    } else if (!app.empty(kb)) {
      that.showKb(app.time.week);
      this.setData({
        TabCur: app.time.week
      })
    } else {
      that.loadkbSync()
    }
  },

  /**
   * 同步加载课表
   */
  loadkbSync() {
    var _that = this;
    var x = 0;

    function countSecond() {
      var that = this;
      x = x + 1
      console.log('x', x)
      var kb_list = app.cache['kb_list_' + app.user.xn + '-' + app.user.xq];
      console.log('kb_list', kb_list)
      if (!app.empty(kb_list)) {
        console.log(kb_list)
        _that.init();
        KB.sort_stu_kb(kb_list);
        _that.showKb(app.time.week);
        _that.setData({
          TabCur: app.time.week
        })
        return;
      }
      if (x > 30) {
        //app.showError('提示', '课表加载失败')
        return;
      }
      setTimeout(function () {
        countSecond();
      }, 500)
    }
    console.log('here')
    KB.load_stu_kb()
    //开始定时检查
    countSecond();
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({ //自动更新时需重新设值
      StatusBar: app.globalData.StatusBar,
      CustomBar: app.globalData.CustomBar,
      ColorList: KB.colors,
      CustomHeight: app.globalData.CustomHeight,
      CustomWidth: app.globalData.CustomWidth,
    })
    if (app.user.is_bind == false) {
      wx.redirectTo({
        url: '../../login/login'
      })
      return;
    }
    this.init()
  },

  /**
   * 重置页面
   */
  init() {
    var kbArr = [];
    for (var i = 0; i < 63; i++) {
      kbArr.push(i);
    }
    var width = (750 - 70) / 7,
      height = ((this.data.CustomHeight - 40) / 6.5),
      list = [];

    for (var i = 0; i < 20; i++) {
      list.push({
        hide: true
      })
    }
    this.setData({
      width: width,
      height: height < 90 ? 90 : height,
      kbArr: kbArr,
      template: list
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.loadkb();
    if (app.user.xn != '2020-2021' || app.user.xq != 1) {
      //app.removeCache('kb_list_' + app.user.xn + '-' + app.user.xq);
      this.loadkbSync();
    }

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    this.setData({
      design: app.design
    })
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log('a', app)
    if (!app.user.psw || app.user.uid == 0) {
      wx.showModal({
        title: '提示',
        content: '您好，自动登录未输入密码，从学分制更新课表功能需要先登录，是否前往？',
        success: function (res) {
          if (res.confirm) {
            wx.navigateTo({
              url: '../../login/login'
            })
          }
        }
      })
      wx.stopPullDownRefresh()
      return;
    }
    app.removeCache('kb_list_' + app.user.xn + '-' + app.user.xq);
    this.loadkbSync();
    wx.stopPullDownRefresh()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  append: function (e) {
    var that = this;
    wx.showActionSheet({
      itemList: ['刷新课表', '个性化背景', '课程列表', '添加课程', '切换学期'],
      success: function (res) {
        switch (res.tapIndex) {
          case 0:
            KB.load_stu_kb();
            break;
          case 1:
            wx.navigateTo({
              url: 'append/design',
            })
            break;
          case 2:
            wx.navigateTo({
              url: 'append/list',
            })
            break;
          case 3:
            wx.navigateTo({
              url: 'append/edit?index=add&url=kb',
            })
            break;
          case 4:
            that.changeXq();
            break;
        }
      },
      fail: function (res) {},
      complete: function (res) {},
    })
  },

  changeXq() {
    console.log('changexq')
    var xn_xq = this.data.xn_xq;
    for (var i in xn_xq) {
      xn_xq[i].xn == app.user.xn && xn_xq[i].xq == app.user.xq ? xn_xq[i].checked = true : xn_xq[i].checked = false;
    }
    this.setData({
      xn_xq: xn_xq,
      modalName: 'RadioModal'
    })
  },

  hideModal() {
    console.log('hide')
    this.setData({
      modalName: ''
    })
  },

  xnxq(e) {
    console.log(e)
    var xn_xq = this.data.xn_xq,
      index = e.detail.value;
    app.user.xn = xn_xq[index].xn;
    app.user.xq = xn_xq[index].xq;
    app.saveCache('user', app.user)
    this.setData({
      xn_xq: xn_xq,
      modalName: null
    })
    app.removeCache('kb_list_' + app.user.xn + '-' + app.user.xq);
    this.loadkbSync();
  },

  edit(e) {
    wx.navigateTo({
      url: 'append/edit?index=' + this.data.modal.id + '&url=kb',
    })
  },

  longtap(e) {
    console.log('long', e)
    var index = e.currentTarget.dataset.index,
      TabCur = this.data.TabCur,
      kb = this.data.template[TabCur].lesson[index],
      that = this;
    wx.showActionSheet({
      itemList: ['编辑课程', '删除课程'],
      success: function (res) {
        switch (res.tapIndex) {
          case 0:
            wx.navigateTo({
              url: 'append/edit?index=' + kb.id + '&url=sumc',
            })
            break;
          case 1:
            wx.showModal({
              title: '提示',
              content: '确认删除后该课程将不会显示在课表中，删除后可在>我的>系统设置 中恢复默认课表',
              success: function (res) {
                if (res.confirm) {
                  that.del_kb(kb.id);
                }
              },
            })
            break;
        }
      },
      fail: function (res) {},
      complete: function (res) {},
    })
  },

  del_kb(id) {
    //判断是否为自定义课程
    var kb_list = app.cache.kb_list,
      add = app.cache.add;
    if (id < 100) {
      kb_list.forEach(function (val, key) {
        if (val.id == id) {
          kb_list.splice(key, 1);
        }
      })
      app.saveCache('kb_list', kb_list);
    } else {
      add.forEach(function (val, key) {
        if (val.id == id) {
          add.splice(key, 1);
        }
      })

      app.saveCache('add', add);

      var sort_add = KB.sort_add_kb(add);
    }
    wx.redirectTo({
      url: 'sumckb',
    })
  },

  showModal: function (e) {
    var index = e.currentTarget.dataset.index,
      TabCur = this.data.TabCur,
      kb = this.data.template[TabCur].lesson[index];
    this.setData({
      modal: kb,
      scrollTop: 50
    })
  },

  hideModal: function () {
    this.setData({
      modal: false
    })
  },

  tabSelect(e) {
    console.log(e);
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 1) * 60,
      scrollTop: 50,
      showWeek: false
    })
    this.showKb(e.currentTarget.dataset.id);
  },

  seeStu(e) {
    console.log(e)
    wx.navigateTo({
      url: '../class/stu?key=' + this.data.modal.cid,
    })
  },

  swiper: function (e) {
    var that = this;
    var current = e.detail.current,
      TabCur = that.data.TabCur;
    this.setData({
      TabCur: current,
      scrollTop: 50,
      showWeek: false,
      animation: 500
    })
    this.showKb(current);
  },

  scroll: function (e) {
    console.log('scorll', e)
    var scroll = e.detail.scrollTop;
    if (scroll > 60) {
      this.setData({
        scrollTop: 50
      })
    }
  },

  showWeek(e) {
    this.setData({
      showWeek: true
    })
  },

  /*
   *获取当前周日期
   */
  setdate: function () {
    var week = this.data.TabCur;
    var a =  new Date(2020, 7, 22) ;
    var dates = [];
    var start = Date.parse(a);
    var len = 24 * 3600 * 1000;

    for (var j = 1; j <= 7; j++) {
      var end = start + len * 7 * week + j * len;
      var D = Tools.GetTime(end);
      dates.push((D.M + 1) + '-' + D.D);
    }
    console.log('dayes', dates)
    this.setData({
      dates: dates
    })
  },
  navigateBack() {
    if (getCurrentPages().length > 1) {
      wx.navigateBack({
        delta: 1
      })
    } else {
      wx.reLaunch({
        url: '/pages/index/index',
      })
    }
  }
})