// pages/core/kb/edit.js
const app = getApp();
const KB = require('../../../../utils/toKb.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    ColorList: KB.colors,
    list: [{}],
    add_list:[{
      weekA:0,
      weekB:15,
      day:1,
      jieciA:1,
      jieciB:2
    }],
    weekArray:[
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20],
      [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]
    ],
    weekIndex:[0,15],
    timeArray:[
      ['日','一','二','三','四','五','六'],
      [1,2,3,4,5,6,7,8,9,0,'A','B','C'],
      [1,2,3,4,5,6,7,8,9,0,'A','B','C']
    ],
    timeIndex:[1,0,1],
    nickBlur:true
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

    app.checkLogin();
    if(app.empty(options)){
      wx.navigateBack({
        data:1
      })
    }else{
      this.setData({
        index:options.index,
        url:options.url
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    var that = this,
      index = that.data.index;
    if(index == 'add'){
      this.setData({
        item: { sub: '快给我取个名呗', color:'#1cbbb4'},
        isAdd: true,
        disabled: true
      })
    }else{
      var list = [];
      index < 100 ? list = app.cache.kb_list : list = app.cache.add; 
      list.forEach(function(val){
        if(val.id == index){
          var item = val;
          that.setData({
            item: item,
            add_list: []
          })
          return;
        }
      })
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 保存课程
   */
  confirm(e){
    var that = this,
      index = that.data.index,
      item = that.data.item;
    if (index == 'add') {
      //处理时间
      var arr = this.data.add_list,
          add = [],
          temp = {};
      app.empty(app.cache.add) ? add = [] : add = app.cache.add;
      arr.forEach(function(val,key){
        temp = {day:0,week0:1,week1:15,jieci:'1-2',length:2};
        temp.day = val.day;
        temp.week0 = (Number(val.weekA) + 1);
        temp.week1 = (Number(val.weekB) + 1);
        temp.jieci = (val.jieciA) + '-' + (val.jieciB);
        temp.length = Number(val.jieciB) - Number(val.jieciB) + 1;
        temp.sub = item.sub;
        temp.color = item.color;
        temp.teacher = item.teacher;
        temp.nick = item.nick;
        temp.room = item.room;
        temp.id = add.length +100;
        console.log('item0', temp)
        add.push(temp);
      })
      app.saveCache('add',add);
      var sort_add = KB.sort_add_kb(add);
      console.log('add', sort_add)
    } else if(app.user.status == 'sumc'){
      app.cache.kb_list[index] = this.data.item;
      app.saveCache('kb_list',app.cache.kb_list);
    }else{
      app.cache.kb_list[index] = this.data.item;
      app.saveCache('stu_kb_list', app.cache.kb_list);
      var sort_stu = KB.sort_stu_kb(app.cache.kb_list);
      console.log('add', sort_add)
    }
    var url = that.data.url;
    url == 'list' ? url = 'list' : url == 'sumc' ? url = '../sumckb' : url = '../kb';
    wx.redirectTo({
      url: url,
    })
  },

  weekChange(e) {
    var index = e.currentTarget.dataset.index,
      arr = this.data.add_list;
    if(e.detail.value[0] > e.detail.value[1]){
      app.showError('提醒','起始周不能大于结束周哦');
      return;
    }
    arr[index].weekA = e.detail.value[0];
    arr[index].weekB = e.detail.value[1];
    this.setData({
      add_list: arr
    })
  },

  timeChanging(e){
    console.log('修改的列为', e.detail.column, '，值为', e.detail.value);
    var timeIndex = this.data.timeIndex,
        index = e.currentTarget.dataset.index,
        timeArray = this.data.timeArray,
        arr = this.data.add_list,
        column = e.detail.column,
        value = e.detail.value;
    if(column==0){
      arr[index].day = value;
      timeIndex[0] = value;
    }else if(column==1){
      arr[index].jieciA = timeArray[1][value];
      timeIndex[1] = value;
      timeIndex[2] < value ? timeIndex[2] = value : 1;  
      arr[index].jieciB = timeArray[1][timeIndex[2]];
    }else{
      arr[index].jieciB = timeArray[1][value];
      timeIndex[2] = value;
      timeIndex[2] < value ? timeIndex[2] = value : 1;  
      arr[index].jieciB = timeArray[1][timeIndex[2]];
    }
   
    this.setData({
      add_list: arr,
      timeIndex: timeIndex
    })
  },

  timeChange(e) {
    console.log(e)
    var index = e.currentTarget.dataset.index,
      timeIndex = this.data.timeIndex,
      arr = this.data.add_list,
      timeArray = this.data.timeArray;
    if (e.detail.value[1] > e.detail.value[2]) {
      app.showError('提醒', '起始节数不能大于结束节数哦');
      return;
    }
   arr[index].day = e.detail.value[0];
    arr[index].jieciA = timeArray[1][e.detail.value[1]];
    arr[index].jieciB = timeArray[1][e.detail.value[2]];
    timeIndex = [e.detail.value[0],e.detail.value[1], e.detail.value[2]]
    this.setData({
      add_list: arr,
      timeIndex: timeIndex
    })
  },

  addTime(){
    if(app.empty(this.data.disabled))return;
    var arr = this.data.add_list;
    arr.push({
      weekA: 0,
      weekB: 15,
      day: 1,
      jieciA: 1,
      jieciB: 2
    })
    this.setData({
      add_list: arr
    })
  },

  delTime(e){
    if (app.empty(this.data.disabled)) return;
    console.log(e)
    var index = e.currentTarget.dataset.index,
      arr = this.data.add_list;
      arr.splice(index,1)
    this.setData({
      add_list: arr
    })
  },

  setColor(e){
    this.setData({
      color: e.currentTarget.dataset.color,
      'item.color': e.currentTarget.dataset.color,
      modalName: null
    })
  },


  showModal(e) {
    this.setData({
      modalName: e.currentTarget.dataset.target
    })
  },
  hideModal(e) {
    this.setData({
      modalName: null
    })
  },

  subInput: function (e) {
    this.setData({
      sub: e.detail.value,
      'item.title': e.detail.value,
      'item.sub': e.detail.value
    });
  },
  nickInput: function (e) {
    this.setData({
      nick: e.detail.value,
      'item.nick': e.detail.value
    });
  },
  teaInput: function (e) {
    this.setData({
      tea: e.detail.value,
      'item.teacher': e.detail.value
    });
  },
  roomInput: function (e) {
    this.setData({
      room: e.detail.value,
      'item.room': e.detail.value
    });
  },

  subFocus: function (e) {
    this.setData({
      subBlur: true
    });
  },
  nickFocus: function (e) {
    this.setData({
      nickBlur: true
    });
  },
  teaFocus: function (e) {
    this.setData({
      teaBlur: true
    });
  },
  roomFocus: function (e) {
    this.setData({
      roomBlur: true
    });
    if(!app.empty(this.data.index) && this.data.index != 'add'){
      if(app.empty(this.data)){
        app.showError('提醒', '一旦更改授课地点，则该门课程全部地点将会变成修改后的地点');
      }
      this.setData({ first: true })
    }
  },

  subBlur: function (e) {
    this.setData({
      subBlur: false
    });
  },
  nickBlur: function (e) {
    this.setData({
      nickBlur: false
    });
  },
  teaBlur: function (e) {
    this.setData({
      teaBlur: false
    });
  },
  roomBlur: function (e) {
    this.setData({
      roomBlur: false
    });
  },
  navigateBack(){
    wx.navigateBack({
      data: 1
    })
  }
})