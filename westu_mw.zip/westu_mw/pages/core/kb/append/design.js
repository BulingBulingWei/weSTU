// pages/core/kb/design.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    ColorList: app.globalData.ColorList,
    isWhite: false,
    bgOpacity:20,
    isLine: true,
    cellOpacity: 20,
    sm: false,
    df: true,
    lg: false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (app.empty(app.design)) {
      app.design = {
        isWhite: false,
        bgOpacity: 20,
        isLine: true,
        cellOpacity: 20,
        sm: false,
        df: true,
        lg: false
      }
      app.saveCache('design', app.design)
    }
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    var design = app.design,
      sm = false,
      df = false,
      lg = false;
    switch (design.textSize) {
      case '20':
        sm = true;
        break;
      case '22':
        df = true;
        break;
      case '24':
        lg = true;
        break;
      default:
        df = true;
    }
    this.setData({
      isWhite: design.isWhite,
      bgOpacity: design.bgOpacity||0,
      isLine: design.isLine,
      cellOpacity: design.cellOpacity||0,
      sm: sm,
      df: df,
      lg: lg
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {
    app.saveCache('design', app.design)
    console.log('design', app.design)
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {
    app.saveCache('design', app.design)
    console.log('design', app.design)
  },

  /**
   * 设置背景图片
   */
  setBg(e) {
    var that = this;
    wx.chooseImage({
      count: 1,
      sizeType: ['original'],
      sourceType: ['album', 'camera'],
      success: function(res) {
        wx.showLoading({
          title: '上传照片中..',
        })
        wx.uploadFile({
          url: 'https://file.stuhb.top/api/public/index.php/index/qiniu/upload',
          name: 'smfile',
          filePath: res.tempFilePaths[0],
          header: {
            "Content-Type": "multipart/form-data"
          },
          success: function (res) {
            console.log(res)
            try{
              var data = JSON.parse(res.data);
            }catch(e){
              app.showError('设置失败',  '上传照片失败，请重试');
            }
            console.log('token', data)
            if (data.state == 1) {
              var url = data.data;
              app.design.url = url;
              //定义图片默认设置
              app.design.bgOpacity = 20;
              app.design.isWhite = true;
              app.design.isLine = false;
              app.design.cellOpacity = 20;
              that.setData({
                isWhite: app.design.isWhite,
                bgOpacity: app.design.bgOpacity,
                isLine: app.design.isLine,
                cellOpacity: app.design.cellOpacity,
              })
              wx.showToast({
                title: '设置成功'
              })
            } else {
              app.showError('设置失败', data.msg || '上传照片失败，请重试');
            }
          },
          fail: function (res) {
            //console.log(res)
          },
          complete: function (res) {
            wx.hideLoading()
          }
        })
      },
      complete: function(res) {
      }
    })
  },

  /**
   * 删除背景图片
   */
  clearBg(e) {
    app.design.url = '';
    app.design.bgOpacity = 0;
    app.design.isWhite = false;
    app.design.isLine = true;
    app.design.cellOpacity = 0;
    this.setData({
      isWhite: app.design.isWhite,
      bgOpacity: app.design.bgOpacity,
      isLine: app.design.isLine,
      cellOpacity: app.design.cellOpacity,
    })
    wx.showToast({
      title: '清除成功',
    })
  },

  /**
   * 设置背景图片透明度
   */
  changeBg(e) {
    console.log('bg', e)
    this.setData({
      bgOpacity: e.detail.value
    })
    app.design.bgOpacity = e.detail.value;
  },

  /**
   * 表头文字白色
   */
  headText(e) {
    console.log('head', e)
    this.setData({
      isWhite: e.detail.value
    })
    app.design.isWhite = e.detail.value;
  },

  /**
   * 定义文字大小
   */
  setSize(e) {
    console.log('radio', e)
    this.setData({
      textSize: e.detail.value
    })
    app.design.textSize = e.detail.value
  },

  /**
   * 是否显示横线
   */
  showLine(e) {
    console.log('line', e)
    this.setData({
      isLine: e.detail.value
    })
    app.design.isLine = e.detail.value;
  },

  /**
   * 设置格子透明度
   */
  changeCell(e) {
    console.log('cell', e)
    this.setData({
      cellOpacity: e.detail.value
    })
    app.design.cellOpacity = e.detail.value;
  },


})