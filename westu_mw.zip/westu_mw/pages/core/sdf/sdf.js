import * as echarts from '../../../ec-canvas/echarts';

const app = getApp();

function initChart(canvas, width, height) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);

  var sdf = getSdf();
  console.log(sdf)

  var option = {
    title: {
      text: '最近6个月水电费',
      subtext: '仅为一卡通扣费记录，包括代缴电费数据'
    },
    color: ["#0c3483"],
    legend: {},
    grid: {
      containLabel: true
    },
    tooltip: {
      show: true,
      trigger: 'axis'
    },
    xAxis: {
      type: 'category',
      boundaryGap: true,
      data: sdf.months,
      // show: false
    },
    yAxis: {
      x: 'center',
      type: 'value',
      splitLine: {
        lineStyle: {
          type: 'dashed'
        }
      }
      // show: false
    },
    series: [{
      name: '金额',
      type: 'line',
      smooth: false,
      data: sdf.money,
      markLine: {
        data: [{
          type: 'average',
          name: '平均值'
        }]
      }
    }],
  };

  chart.setOption(option);
  return chart;
}

function getSdf() {
  var that = this;
  if (!app.empty(app.cache.sdf)) {
    var len = 0,
      months = [],
      money = [],
      sdf = app.cache.sdf,
      cookie = '';
    sdf.length >= 6 ? len = 6 : len = sdf.length;
    for (var i = len - 1; i >= 0; i--) {
      months.push(sdf[i].month + '月');
      money.push(-Number(sdf[i].money));
    }
    return {
      months: months,
      money: money
    };
  } else {
    var now = Date.parse(app.time.year + '/' + app.time.month + '/01') / 1000;
    wx.showLoading({
      title: 'loading..',
    });
    !app.empty(app.cache.todayYkt) ? cookie = app.cache.todayYkt.cookie : cookie = '';
    app.post('ykt/getsdf', {
      now: now,
      cookie: cookie
    }).then(function (res) {
      if (!app.empty(res.data)) {
        app.saveCache('sdf', res.data);
        wx.redirectTo({
          url: 'sdf',
        })
      }
    })

  }
};

Page({

  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    debt: '-',
    last: '-',
    ec: {
      onInit: initChart
    }
  },

  onLoad() {
    app.checkLogin();
    //获取当前时间
    var M = app.time.M + 1;
    M = M <= 10 ? M = '0' + M : M;
    var D = app.time.D < 10 ? D = '0' + app.time.D : app.time.D;
    this.setData({
      name: app.user.name,
      uid: app.user.uid,
      date: M + "/" + D
    })
  },

  onReady() {
    // this.getDorm();
    this.getDebt();
    if (!app.empty(app.cache.sdf)) {
      var sdf = app.cache.sdf,
        last = -Number(sdf[0].money);
      this.setData({
        last: last
      })
    }
    app.user.name == 'wxtest' && this.setData({
      ispay: true
    })

  },

  getDorm() {
    var that = this;
    if (!app.empty(app.user.dorm) && app.user.dorm != '加载失败') {
      this.setData({
        dorm: app.user.dorm
      })
      that.getDebt();
    } else {
      wx.showLoading({
        title: '加载宿舍信息中..',
      })
      app.post('sdf/getdorm', {
        username: app.user.username,
        psw: app.user.psw
      }).then(function (res) {
        console.log("res",res)
        if (res.data != '加载失败') {
          app.user.dorm = res.data;
          app.saveCache('user', app.user);
          that.setData({
            dorm: app.user.dorm
          })
          that.getDebt();
        }

      })
    }
  },

  getDebt() {
    var that = this,
      dorm = that.data.dorm;

    wx.showLoading({
      title: '加载电费信息中',
    })
    app.post('sdf/debt', {
      username: app.user.username,
      psw: app.user.psw
    }).then(function (res) {
      console.log('getdebt', res)
      app.cache.debt = res.data;
      that.setData({
        debt: res.data.money
      })
    })
  },

  pay() {
    var that = this;
    console.log('debt', app.cache.debt);
    if (that.data.debt == '-') {
      app.showError('提示', '哎呀,好像校园网断了,亦或是电费信息加载失败');
      return;
    } else if (that.data.debt == 0) {
      app.showError('提示', '当前暂无欠费，不用交哦');
      return;
    } else {
      wx.showModal({
        title: '提示',
        content: '确认缴费后，将会从一卡通中扣除水电费，是否继续',
        showCancel: true,
        success: function (res) {
          wx.showLoading({
            title: '缴费中...',
          })
          app.post('sdf/pay', {
            username: app.user.username,
            psw: app.user.psw,
            dorm: app.user.dorm,
            payId: app.cache.debt.payId
          }).then(function (res) {
            wx.showModal({
              title: '提示',
              content: res.msg || '请核对一卡通是否扣费，如已扣费就付款成功',
              showCancel: false,
              success: function (res) {
                wx.showToast({
                  title: '缴费成功',
                  duration: 2000
                })
                app.cache.debt = {};
                app.removeCache('sdf');
                getSdf();
              },
              fail: function (res) {},
              complete: function (res) {},
            })
          })
        },
      })
    }
  }
});