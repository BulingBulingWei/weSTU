//ks.js
//获取应用实例
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    ColorList: app.globalData.ColorList,
    remind: '加载中',
    list: [],
    first: 1,
    sumc: true,
    user: []
  },

  onLoad: function(options){
    var that = this;
    var user = app.user
    that.setData({
      user:app.user
    })
    if(options.classname == 'STU'){
      user.bind = "stu";
      user.status = "stu";
      user.uid = options.id;
      user.name = options.name;
      user.username = "guest";
      user.psw = "guest";
      that.setData({
        user:user,
        sumc:false
      })
    }else if(options.id){
      user.bind = "sumc";
      user.status = "sumc";
      user.username = "guest";
      user.uid = options.id;
      user.name = options.name;
      user.classname = options.classname
      that.setData({
        user: user,
        sumc:true
      })
    }
  },

  onReady: function() {
    var that = this;
    var user = that.data.user
    if (user.status == "sumc" && user.classname) {
      that.sumcks()
    } else if (user.status == "sumc" && !user.classname){
      wx.redirectTo({
        url: '../../login/login',
      })
    }else if (user.status == "stu") {
      that.stuks()
      that.setData({
        sumc:false
      })
    } else {
      wx.redirectTo({
        url: '../../login/login',
      })
    }
  },

  sumcks:function(e){
    var that = this;
    //判断并读取缓存
    if (app.cache.ks) {
      that.ksRender(app.cache.ks);
    }
    wx.showNavigationBarLoading();
    wx.request({
      url: app.server + 'stuks/sumcks',
      method: 'POST',
      data: app.key({
        classname: that.data.user.classname
      }),
      success: function (res) {
        if (res.data && res.data.state == 1){
          var list = res.data.data;
          if (list){
            //保存考试缓存
            that.data.user.username!='guest' && app.saveCache('ks', list);
            that.ksRender(list);
          }else{
            that.setData({
              remind: '暂无数据'
            });
          }
        } else if (res.data.state == 2){
          that.setData({
            remind: res.data.msg || '当前学期暂无成绩'
          });
        } else if (app.cache.ks){
          wx.showToast({
            title: res.data.msg || '未知错误',
            icon: 'none'
          })
        } else {
          app.removeCache('ks');
          that.setData({
            remind: res.data.msg || '未知错误'
          });
        }
      },
      fail: function (res) {
        if (that.data.remind == '加载中') {
          that.setData({
            remind: '网络错误'
          });
        }
        console.warn('网络错误');
      },
      complete: function () {
        wx.hideNavigationBarLoading();
        wx.stopPullDownRefresh();
      }
    });
  },

  stuks:function(e) {
    var that = this;
    //判断并读取缓存
    if (app.cache.ks) {
      that.ksRender(app.cache.ks);
    }
    app.empty(this.data.list) && wx.showLoading({
      title: 'loading...',
    })
    wx.request({
      url: app.server+'stuks/getks',
      method: 'POST',
      data: app.key({
        username: that.data.user.username,
        uid:that.data.user.uid,
        psw: that.data.user.psw
      }),
      success: function(res) {
        if (res.data && res.data.state == 1) {
          var list = res.data.data;
          if (list) {
            //保存考试缓存
            that.data.user.username != 'guest' &&app.saveCache('ks', list);
            that.ksRender(list);
          } else {
            that.setData({
              remind: '暂无数据'
            });
          }
        } else if (res.data.state == 2) {
          that.setData({
            remind: res.data.msg || '当前学期暂无成绩'
          });
        } else if (app.cache.ks) {
          wx.showToast({
            title: res.data.msg || '未知错误',
            icon: 'none'
          })
        } else {
          app.removeCache('ks');
          that.setData({
            remind: res.data.msg || '未知错误'
          });
        }
      },
      fail: function(res) {
        if (app.cache.ks) {
          wx.showToast({
            title: '网络错误！加载失败！',
            icon: 'none'
          })
        } else {
          app.removeCache('ks');
          that.setData({
            remind: '网络错误！加载失败！'
          });
        }
      },
      complete: function() {
        wx.hideLoading()
        wx.stopPullDownRefresh();
      }
    });
  },

  ksRender: function(list) {
    var that = this
    if (!list || !list.length) {
      that.setData({
        remind: '无考试安排'
      });
      return false;
    }
    var days = ['','一', '二', '三', '四', '五', '六', '日'];
    for (var i = 0, len = list.length; i < len; ++i) {
      list[i].open = false;
      list[i].index = i;
      list[i].day = that.data.sumc == true && typeof(list[i].day) == 'number' ? days[Number(list[i].day)] : list[i].day;
      list[i].time = list[i].time.trim().replace('-', '~');
      if(that.data.sumc){
        var reg = RegExp(/^1月/);
        if (list[i].date.match(reg)){
          list[i].date = list[i].date.trim().replace(/-/g, '/');
        }else{
          list[i].date = list[i].date.trim().replace(/-/g, '/');
        }
      }else{
        list[i].date = list[i].date.trim().replace(/\./g, '/');
      }
      //list[i].sub = list[i].sub.replace(',', '-');

      console.log('list',list)
      //计算倒计时天数
      var oDate1, oDate2, iDays 
      oDate1 = Date.parse(new Date())
      oDate2 = Date.parse(new Date(list[i].date))
      list[i].days = Math.ceil((oDate2 - oDate1) / 1000 / 60 / 60 / 24) //把毫秒数转换为天数
      console.log('days',list[i].days)

      //倒计时提醒
      if(list[i].noon == '-'){
        list[i].countdown = list[i].ps
      }else if (list[i].days > 0) {
        list[i].countdown = '还有' + list[i].days + '天考试';
        list[i].place = '（' + list[i].week + '周星期' + list[i].day + '）@' + list[i].room;
      } else if (list[i].days < 0) {
        list[i].countdown = '考试已结束了' + (-list[i].days) + '天';
        list[i].place = '';
      }else {
        list[i].countdown = '今天考试';
        list[i].place = list[i].time + '@' + list[i].room;
      }
    }
    //排序今天>正数>负数
    list.sort(function (x, y) {
      if (x.days>0 && y.days>0){
        return (x.days - y.days);
      } else if (x.days<0 && y.days >0){
        return (1);
      } else if(x.days>0 && y.days<0){
        return (-1);
      } else if (x.days==0){
        return (-1);
      } else if(y.days==0){
        return (1);
      }else{
        return (y.days - x.days);
      }
    });
    list[0].open = true;
    that.setData({
      list: list,
      id:that.data.user.uid,
      name:that.data.user.name,
      remind: ''
    });
  },

  //下拉更新
  onPullDownRefresh: function() {
    this.onReady();
  },

  // 展示考试详情
  slideDetail: function(e) {
    var id = e.currentTarget.dataset.id,
      list = this.data.list;
    // 每次点击都将当前open换为相反的状态并更新到视图，视图根据open的值来切换css
    for (var i = 0, len = list.length; i < len; ++i) {
      if (i == id) {
        list[i].open = !list[i].open;
      } else {
        list[i].open = false;
      }
    }
    this.setData({
      list: list
    });
  },

  //分享
  onShareAppMessage: function (e) {
    var that = this
    var name = that.data.user.name,
      id = that.data.user.uid,
      list = ['快来瞧瞧吧！','快来瞅瞅吧~'],
      index = Math.floor((Math.random() * list.length)),
      desc = list[index];
    if (that.data.user.department == '医学院') {
      var classname = that.data.user.classname
    } else {
      var classname = 'STU'
    }
    console.log(e)
    return {
      title: name + '的考试安排\n———' + desc,
      //desc: 'We汕大 - '+desc,
      path: '/pages/core/ks/ks?id=' + id + '&classname=' + classname + '&name=' + name
    };
  },

});