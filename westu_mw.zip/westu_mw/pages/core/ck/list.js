// pages/core/ck/ck.js
const app = getApp()
var Ping = require('../../../utils/ping.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    list: [],
    page: 1,
    margin: '空空如也，换个条件搜索试试吧',
    remind: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.search()
  },

  search(){
    var that = this;
    this.setData({
      remind: true
    })
    var params = app.ck;
    params.page = this.data.page;
    app.post('ck/search',{
      teacher: params.teacher,
      name: params.name,
      day: params.day,
      page: params.page,
      department: params.department
    }).then(function(res){
      var arr = that.data.list,
        data = res.data;
      if(app.empty(data)){
        var margin = that.data.margin;
        that.data.page > 1 ? margin = '我也是有底限哒' : 1; 
        that.setData({
          remind: false,
          margin: margin
        })
      }else{
        var i = 0;
        for (var item in data) {
          //处理时间
          var t = '';
          data[item]['Sunday'] ? t = t + '周日 ' + data[item]['Sunday'] + '节；' : 1;
          data[item]['Monday'] ? t = t + '周一 ' + data[item]['Monday'] + '节；' : 1;
          data[item]['Tuesday'] ? t = t + '周二 ' + data[item]['Tuesday'] + '节；' : 1;
          data[item]['Wednesday'] ? t = t + '周三 ' + data[item]['Wednesday'] + '节；' : 1;
          data[item]['Thursday'] ? t = t + '周四 ' + data[item]['Thursday'] + '节；' : 1;
          data[item]['Friday'] ? t = t + '周五 ' + data[item]['Friday'] + '节；' : 1;
          data[item]['Saturday'] ? t = t + '周六 ' + data[item]['Saturday'] + '节；' : 1;
          data[item]['t'] = t;
          data[item]['start_end'] = data[item]['start_end'].replace(/ /,'')
          arr.push(data[item])
          i++;
        }
        var margin = that.data.margin;
        console.log('i',i,data)
        i == 20 ? margin = '下拉加载更多' : margin = '我也是有底限哒';
        that.setData({
          list: arr,
          margin: margin,
          remind: false
        })
      }

    })
  },

  tap_kb(e){
    var index = e.currentTarget.dataset.index,
        item = this.data.list[index];
    app.ckPing = item;
    wx.navigateTo({
      url: './detail?id=search',
    })

  },

  /**
 * 页面上拉触底事件的处理函数
 */
  onReachBottom: function () {
    console.log('here')
    var that = this;
    var margin = that.data.margin,
        page = that.data.page;
    if(margin == '我也是有底限哒'){
      return;
    }
    this.setData({
      page: ++page
    })
    that.search();
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})