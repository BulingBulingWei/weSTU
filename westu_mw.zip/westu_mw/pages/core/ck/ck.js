// pages/core/ck/ck.js
const app = getApp()
var Ping = require('../../../utils/ping.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    ping_sub:[],
    day_arr: ['All','Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
    day_index: 0,
    name: '',
    teacher:'',
    day:'',
    department:'全部教学单位'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var sub = Ping.sub;
    sub.unshift({department:'全部教学单位'});
    this.setData({
      ping_sub: sub
    })
    //this.search()
  },

  search(){
    var that = this;
    if (that.data.department == '全部教学单位' && that.data.name == '' && that.data.teacher =='' && that.data.day == ''){
      app.showError('提示','请至少选择一种筛选条件');
      return;
    }
    app.ck = {
      department: that.data.department,
      name: that.data.name,
      teacher: that.data.teacher,
      day: that.data.day,
      page: 1
    }
    wx.navigateTo({
      url: './list',
    })
  },

  inputName(e){
    this.setData({
      name: e.detail.value
    })
  },

  inputDoc(e){
    this.setData({
      teacher: e.detail.value
    })
  },

  pickDay(e){
    var data = this.data.day_arr[e.detail.value];
    this.setData({
      day_index : e.detail.value,
      day: data == 'All' ? '' : data
    })
  },

  ChooseCheckbox(e) {
    var id = e.currentTarget.dataset.value,
      sub = this.data.ping_sub;
    sub.forEach(function (val) {
      val.checked = false
    })
    sub[id].checked = true;
    this.setData({
      ping_sub: sub,
      department: sub[id].department
    })
  },

  showModal() {
    this.setData({
      modalName: 'sub'
    })
  },

  hideModal() {
    this.setData({
      modalName: null,
    })
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})