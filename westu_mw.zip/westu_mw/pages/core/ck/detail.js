// pages/core/ping/detail.js
const app = getApp()
const Tools = require('../../../utils/common.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show_: 2,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    var val = app.ckPing;
    //检查长度
    val.sub = Tools.beautySub(val.name, 10)
    val.tea = Tools.beautySub(val.teacher, 10)
    this.setData({
      val: val
    })
    this.loadDel()
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  loadDel() {
    wx.showLoading({
      title: 'loading...',
    })
    var that = this,
      val = that.data.val;
    app.post('pingjia/loadClass', {
      id: val.id,
    }).then(function(res) {
      console.log('res', res)
      var margin = app.empty(res.data.ping) == false ? '' : '空';
      that.setData({
        del: res.data.del,
        ping: res.data.ping,
        margin: margin
      })
      app.class_temp = res.data.ping
    })
  },

  showdel() {
    this.setData({
      modalName: 'del'
    })
  },

  hideModal(e) {
    this.setData({
      modalName: null
    })
  },


  toAdd(){
    app.toast('开发中~')
  },

  /**
   * 点赞评论
   */
  likeit(e) {
    var that = this,
      id = e.currentTarget.dataset.id,
      ping = this.data.ping,
      item = ping[id];
    app.post('pingjia/like', {
      openid: app.wx.g_openid,
      like: item.like || 0,
      ping_id: item.id
    }).then(function(res) {
      if (res.data !== 0) {
        //点赞成功
        item.like = res.data;
        item.likes++;
      } else {
        //取消点赞
        item.like = 0;
        item.likes--;
      }
      ping[id] = item;
      that.setData({
        ping: ping
      })
    })
  },

  /**
   * 按点赞数量排序
   */
  showmuch() {
    let that = this,
      list = app.class_temp;
    list.sort(function(x, y) {
      return y['likes'] - x['likes'];
    });
    this.setData({
      ping: list,
      show_: 0
    })
  },

  /**
   * 按评论时间排序
   */
  shownew() {
    let that = this,
      list = app.class_temp;
    list.sort(function(x, y) {
      return y['id'] - x['id'];
    });
    this.setData({
      ping: list,
      show_: 1
    })
  },

  /**
   * 默认排序
   */
  showall() {
    this.setData({
      ping: app.class_temp,
      show_: 2
    })
  },

  /**
 * 好评
 */
  show5() {
    let that = this,
      list = app.class_temp,
      ping = [];
    list.forEach(function(val){
      if(val.star == 5 || val.star == 4){
        ping.push(val)
      }
    })
    this.setData({
      ping: ping,
      show_: 3
    })
  },

  /**
 * 中评
 */
  show3() {
    let that = this,
      list = app.class_temp,
      ping = [];
    list.forEach(function (val) {
      if (val.star == 2 || val.star == 3) {
        ping.push(val)
      }
    })
    this.setData({
      ping: ping,
      show_: 4
    })
  },

  /**
 * 差评
 */
  show1() {
    let that = this,
      list = app.class_temp,
      ping = [];
    list.forEach(function (val) {
      if (val.star == 1) {
        ping.push(val)
      }
    })
    this.setData({
      ping: ping,
      show_: 5
    })
  },

  showModal(e) {
    this.setData({
      modalName: 'comment',
      comment_id: e.currentTarget.dataset.id
    })
  },

  comment_input(e) {
    this.setData({
      comment_input: e.detail.value
    })
  },

  comment() {
    var that = this,
      index = that.data.comment_id,
      list = that.data.ping,
      item = list[index],
      value = this.data.comment_input;
    console.log('item', item)
    if (app.empty(value)) {
      app.showError('提示', '评论的内容不能为空哦');
      return;
    }
    wx.showLoading({
      title: 'loading...',
    })
    app.post('pingjia/comment', {
      ping_id: item.id,
      content: value
    }).then(function(res) {
      console.log(res)
      res.state == 1 ? that.loadDel() : app.showError("提示", res.msg || '评论失败，请重试')
    })
    this.hideModal()
  }

})