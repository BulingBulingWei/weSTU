// pages/core/xl/xl.js
const app = getApp();
const X = require('../../../utils/event.js');
const Tools = require('../../../utils/common.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    CustomWidth: app.globalData.CustomWidth,
    CustomHeight: app.globalData.CustomHeight,
    time_list: Tools.sumc_time,
    year: '',
    month: '',
    day: "",
    monArr: ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'],
    dayArr: ['日', '一', '二', '三', '四', '五', '六'],
    weekArr: [],
    dateArr: [],
    firstDay: '',
    lastDay: '',
    param: null,
    clockNum: 3,
    selectDay: 0
  },

  getDate: function(months) { //获取当月日期
    var mydate = new Date();
    var year = mydate.getFullYear();
    var month = mydate.getMonth();
    isNaN(months) && (months = month + 1);
    this.data.year = year;
    this.data.month = months;
    this.data.day = mydate.getDate();
    var fist = new Date(year, month, 1);
    this.data.firstDay = fist.getDay();
    var last = new Date(year, months, 0);
    this.data.lastDay = last.getDate();

    this.setData({
      year: this.data.year,
      month: this.data.month,
      day: this.data.day,
      firstDay: this.data.firstDay,
      lastDay: this.data.lastDay
    })
    console.log("今天：" + this.data.day);
  },
  setDate: function() {
    var item = {},
      v = 0,
      firstDay = this.data.firstDay,
      lastDay = this.data.lastDay,
      year = this.data.year,
      month = this.data.month,
      dateArr = [];

    //计算周数
    var stamp = Date.parse(year + '/' + month + '/' + '01');
    var nowTime = Tools.GetTime(stamp,app.globalData.xn_start);
    nowTime.M = nowTime.M < 10 ? ('0' + nowTime.M) : nowTime.M;
    nowTime.D = nowTime.D < 10 ? ('0' + nowTime.D) : nowTime.D;
    var week = nowTime.week,
      weekArr = [];
    var weekLen = Math.ceil((firstDay + lastDay) / 7);
    for (var i = 0; i < weekLen; i++) {
      if (week + i >= 0 && week + i <= 20) {
        weekArr.push(week + i);
      } else {
        weekArr.push('');
      }
    }
    //第一天开始前空余日期
    for (var i = 0; i < firstDay; i++) {
      dateArr.push('');
    }
    if (app.user.is_bind==true) {
      //添加课表内容
      var json = JSON.stringify(app.cache.kb),
        reg = /(03\/17)/,
        time = {};
        console.log('json',json)
      for (var i = 1; i <= lastDay; i++) {
        item = {};
        if (i <= lastDay) {
          let date = year + '/' + month + '/' + i;
          //添加校历内容
          if (X.event[date]) {
            let event = X.event[date];
            item = {
              day: i,
              bg: event.bg,
              text: event.text
            };
          } else {
            item = {
              day: i
            }
          }
          //添加课表内容
          time = Tools.GetTime(Date.parse(date),app.globalData.xn_start);
          if (app.user.status == 'sumc') {
            var ctoe = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
            time.eday = ctoe[time.day]
            reg = new RegExp('"week":"' + time.week + '","day":"' + time.eday + '"', "i");
          } else {
            reg = new RegExp('"xl":"' + time.week + '->' + time.day, "i");
            // console.log(reg)
          }
          if (json.match(reg)) {
            console.log(reg, 'lala',json.match(reg))
            item.status = 1;
          } else {
            item.status = 0;
          };
          dateArr.push(item);
        } else {
          dateArr.push('');
        }
      }
    } else {
      for (var i = 1; i <= lastDay; i++) {
        item = {};
        if (i <= lastDay) {
          let date = year + '/' + month + '/' + i;
          //添加校历内容
          if (X.event[date]) {
            let event = X.event[date];
            item = {
              day: i,
              bg: event.bg,
              text: event.text
            };
          } else {
            item = {
              day: i
            }
          }
          dateArr.push(item);
        } else {
          dateArr.push('');
        }
      }
    }

    //最后一天之后空余日期
    for (var i = 0; i < weekLen * 7 - firstDay - lastDay; i++) {
      dateArr.push('');
    }
    //加载课表
    this.viewDay(0, 0)

    this.setData({
      dateArr: dateArr,
      firstDay: firstDay,
      weekArr: weekArr,
      selectDay: 0
    })
  },

  prevMonth: function() { //上一月
    var months = "";
    var years = "";
    var item = {},
      v = 0,
      firstDay = this.data.firstDay,
      lastDay = this.data.lastDay,
      year = this.data.year,
      month = this.data.month,
      dateArr = this.data.dateArr;
    if (month == 1) {
      years = year - 1
      month = 12;
      months = month;
    } else {
      years = year;
      months = month - 1;
    }

    var first = new Date(years, months - 1, 1);
    firstDay = first.getDay();
    var last = new Date(years, months, 0);
    lastDay = last.getDate();

    this.setData({
      month: months,
      year: years,
      firstDay: firstDay,
      lastDay: lastDay
    })
    this.setDate();
  },

  nextMonth: function() { //下一月
    var months = "";
    var years = "";
    var item = {},
      v = 0,
      firstDay = this.data.firstDay,
      lastDay = this.data.lastDay,
      year = this.data.year,
      month = this.data.month,
      dateArr = this.data.dateArr;
    if (month == 12) {
      month = 0;
      months = month;
      years = year + 1;
    } else {
      months = month + 1;
      years = year;
    }
    var months = month + 1;
    var first = new Date(years, months - 1, 1);
    firstDay = first.getDay();
    var last = new Date(years, months, 0);
    lastDay = last.getDate();
    this.setData({
      month: months,
      year: years,
      firstDay: firstDay,
      lastDay: lastDay
    })
    this.setDate();
  },

  viewDay: function(e, tap = true) {
    console.log(e)
    if (tap) {
      var date = e.currentTarget.dataset.date,
        item = e.currentTarget.dataset.item;
    } else {
      date = this.data.year + '/' + this.data.month + '/' + this.data.day;
    }

    var time = Tools.GetTime(Date.parse(date), app.globalData.xn_start),
      event = {},
      selectDay = 0;
    time.M++;
    time.M = time.M < 10 ? ('0' + time.M) : time.M;
    time.D = time.D < 10 ? ('0' + time.D) : time.D;
    event.date = date;
    event.week = time.week;
    event.day = Tools.toStrDay(time.day);

    //添加课表
    var todaykb = [];
    var D = time.M + '/' + time.D;
    //console.log(D)
    if (app.user.is_bind == true && time.week>0 && time.week<=18) {
      console.log('week',time.week)
      app.cache.kb[time.week].forEach(function(val, key) {
        if (app.user.status == 'sumc') {
          var ctoe = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
          time.eday = ctoe[time.day];
          //D == val.date ? todaykb.push(val) : 1;
          time.week == val.week && time.eday == val.day ? todaykb.push(val) : 1;
        } else if (app.user.status == 'stu') {
          time.week == val.week && time.day == val.day ? todaykb.push(val) : 1;
        }
      })
      app.empty(todaykb) ? event.kb = 0 : event.kb = todaykb;
      console.log(event)
    }
    //判断选择的是不是当天
    time.D == this.data.day ? selectDay = 0 : selectDay = time.D;
    //加载校历内容
    if (X.event[date]) {
      let xl = X.event[date].ps;
      event.ps = xl;
    } 
    this.setData({
      event: event,
      selectDay: selectDay
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getDate();
    this.setDate();
    var param = 90;
    this.setData({
      param: param,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  },

  showModal: function (e) {
    if(app.user.status!='sumc')return;
    var index = e.currentTarget.dataset.id,
      kb = this.data.event.kb[index];
    this.setData({
      modal: kb,
      scrollTop: 50
    })
  },

  hideModal: function () {
    this.setData({
      modal: false
    })
  },
})