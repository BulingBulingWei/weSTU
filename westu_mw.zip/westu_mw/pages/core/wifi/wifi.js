// pages/core/wifi/wifi.js
const app = getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    items: [
      { name: '1.0GB,1.0元', value: '1000', checked: true },
      { name: '2.0GB,2.5元', value: '2000' },
      { name: '3.0GB,4.0元', value: '3000' },
    ],
    value: 1000
  },

  radio(e){
    console.log(e)
    this.setData({
      value: e.detail.value
    })
  },

  submit: function () {
    var that = this;
    wx.showModal({
      title: '提示',
      content: "您确认要添加该套餐吗？一旦添加将直接从一卡通扣款且无法退回。",
      cancelText: '我再想想',
      confirmText: '确认',
      success: (res) => {
        var that = this;

        if (res.confirm) {
          that.buy();
        } else {
          wx.navigateBack();
        }
      }
    });
  },

  buy: function () {
    var that = this,
      value = that.data.value;
    wx.showLoading({
      title: 'loading...',
    })
    wx.request({
      url: app.server + 'ykt/buyllb',
      method: 'POST',
      data: app.key({
        cookie: app.cache.todayYkt.cookie,
        g_openid: app.wx.g_openid,
        llb: value
      }),
      success: (res) => {
        wx.hideLoading()
        if (res.data.state == 1) {
          wx.showToast({
            title: res.data.msg,
            icon: 'success',
            duration: 2000
          })
        } else {
          wx.showModal({
            title: '购买失败',
            content: res.data.msg,
            confirmText: '重试',
            cancelText: '取消',
            success: function (res) {
              if (res.confirm) {
                that.buy();
              }
            }
          });
        }
      },
      fail: (res) => {
        wx.hideLoading()
        wx.showModal({
          title: '请求超时',
          content: '可能是您的网络环境不太好，亦或者是服务端出现了故障',
          confirmText: '重新加载',
          cancelText: '取消',
          success: function (res) {
            if (res.confirm) {
              that.loadkb();
            }
          }
        });
      }
    });
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    app.user.name == 'wxtest' && this.setData({
      items: []
    })
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})