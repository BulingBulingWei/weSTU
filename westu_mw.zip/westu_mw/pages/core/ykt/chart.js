import * as echarts from '../../../ec-canvas/echarts';

const app = getApp();

function initChart(canvas, width, height, data) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);

  var option = {
    backgroundColor: "#ffffff",
    color: ["#e54d42", "#f37b1d", "#8dc63f", "#39b54a", "#0081ff", "#9c26b0", "#8799a3"],
    series: [{
      label: {
        normal: {
          fontSize: 24
        }
      },
      type: 'pie',
      center: ['50%', '50%'],
      radius: [0, '60%'],
      data: data,
      itemStyle: {
        emphasis: {
          shadowBlur: 10,
          shadowOffsetX: 0,
          shadowColor: 'rgba(0, 2, 2, 0.3)'
        }
      }
    }]
  };

  chart.setOption(option);
  return chart;
}

Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    TabCur: 1,
    ec: {},
    scrollLeft: 0,
    list: [],
    icon: ['pos', 'food', 'food_1', 'food_2', 'food_3', 'sdf', 'wifi', 'income', 'income', 'other', 'other', 'other', 'other'],
    ye: 0,
    sum: 0
  },

  onReady() {

  },

  /**
   * 分类整理
   */
  ecList() {
    var ykt = app.cache.ykt,
      ecList = ykt.ecList,
      chartList = [],
      temp = {};
    ecList.forEach(function (val, key) {
      temp = { name: '', value: '' }
      if (val.times > 0) {
        if(!app.empty(val.name.match(new RegExp(/(\S*?)，/), ""))){
          val.name = val.name.match(new RegExp(/(\S*?)，/), "")[1];
        }
        temp.name = val.name;
        temp.value = val.cost / ykt.sum;
        chartList.push(temp);
      }
    })
    console.log('chartList', chartList);
    this.setData({
      chartList: chartList,
      ye: ykt.ye,
      sum: ykt.sum,
      ecList: ykt.ecList,
      month: app.time.M
    })
  },

  echartInit(e) {
    console.log(e)
    this.ecList();
    initChart(e.detail.canvas, e.detail.width, e.detail.height,this.data.chartList);
  },

  tabSelect(e) {
    console.log(e);
    if (e.currentTarget.dataset.id == 0) {
      wx.navigateBack({
        data: 1
      })
    }
  },
});
