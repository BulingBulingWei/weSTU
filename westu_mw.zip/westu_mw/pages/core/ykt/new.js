// pages/core/ykt/ykt.js
import * as echarts from '../../../ec-canvas/echarts';

const app = getApp();

function setOption(chart, option) {
  chart.setOption(option);
}

Page({
  data: {
    StatusBar: app.globalData.StatusBar,
    CustomBar: app.globalData.CustomBar,
    TabCur: 0,
    ec: {
      // 将 lazyLoad 设为 true 后，需要手动初始化图表
      lazyLoad: true
    },
    isLoaded: false,
    isDisposed: false,
    date: '2019/03',
    scrollLeft: 0,
    list: [],
    icon: ['pos', 'food', 'food_1', 'food_2', 'food_3', 'sdf', 'wifi', 'income', 'income', 'other', 'other', 'other', 'other'],
    ye: 0,
    sum: 0
  },

  /**
   * 加载消费数据
   */
  getbill(start, end) {
    var that = this;
    //先显示已有数据
    if (!app.empty(app.cache.ykt)) {
      var billList = app.cache.ykt.billList,
        ye = app.cache.ykt.ye,
        sum = app.cache.ykt.sum,
        ecList = app.cache.ykt.ecList;
      that.setData({
        list: billList,
        ye: ye,
        sum: sum,
        ecList: ecList
      })
      //查询最新记录
      var latest = Date.parse(billList[0].date) / 1000,
        start = latest;
    }
    wx.showLoading({
      title: 'loading..',
    })
    app.post('ykt/index', {
      start: start,
      end: end,
      cookie: app.cache.todayYkt.cookie,
      ye: true
    }).then(function (res) {
      var bill = res.data.bill,
        ye = res.data.ye;
      if (app.empty(bill)) {
        app.showError('提醒', '当月暂无消费记录哦~');
        that.setData({ ye: ye })
        return;
      }
      //设置diff插入
      var ykt = that.sortXf(bill, ye);
      if (!app.empty(latest)) {
        //添加新数据
        sum -= billList[0].cost;
        billList.splice(0, 1)
        for (var i = ykt.billList.length - 1; i >= 0; i--) {
          billList.unshift(ykt.billList[i])
        }
        for (var i = 0; i < 10; i++) {
          ecList[0].cost += ykt.ecList[0].cost;
          ecList[0].times += ykt.ecList[0].times;
        }
        sum += ykt.sum
      } else {
        //没有新数据
        billList = ykt.billList;
        ecList = ykt.ecList;
        sum = ykt.sum
      }
      that.setData({
        list: billList,
        ye: ykt.ye,
        sum: sum,
        ecList: ecList
      })
      var ykt = {
        billList: billList,
        ye: ykt.ye,
        sum: sum,
        ecList: ecList,
        month: app.time.M + 1
      };
      app.saveCache('ykt', ykt)
    })
  },

  /**
   * 处理新的消费数据
   */
  sortXf(bill, ye) {
    console.log('bill_ye', bill, ye);
    var billList = [],
      dayAll = {
        date: '',
        cost: 0,
        income: 0,
        dayList: []
      },
      sum = 0,
      income = 0,
      ecList = [];//图表统计列表
    for (let i = 1; i <= 10; i++) {
      ecList.push({
        cost: 0,
        times: 0,
        name: ''
      })
    }
    //开始构造第一天列表数据
    var dayList = {
      cost: Number(bill[0].money),
      where: bill[0].where,
      time: bill[0].time,
      type: bill[0].type
    };
    dayAll.date = bill[0].date;
    dayList.cost <= 0 ? dayAll.cost += dayList.cost : dayAll.income += dayList.cost;
    dayAll.dayList.push(dayList);
    sum += dayAll.cost;
    income += dayAll.income; //第一天构造完毕

    var stamp = Date.parse(bill[0].date),
      stamp1 = 0; //用以比较是否满一周

    //开始统计第一天图表列表
    let money = -num2(bill[0].money),
      type = bill[0].type;
    if (money > 0) {
      ecList[type].cost += money;
      ecList[type].name = bill[0].where;
      ecList[type].times++;

      ecList[type].cost = num2(ecList[type].cost);
    }
    ecList[type].type = bill[0].type;

    //循环构造表单列表
    for (let i = 1; i < bill.length; i++) {
      //判断是否与前一天相同
      if (bill[i].date != dayAll.date) {
        //判断是否为同一周
        stamp != 0 && 1, stamp1 = Date.parse(dayAll.date);
        if (stamp != 0 && stamp - stamp1 >= 518400000) {
          stamp = 0;//到一周，标记结束
          if (stamp - stamp1 == 518400000) {//刚好一周
            tempObj.weekCost = num2(sum);
            tempObj.weekIncome = num2(sum);
          } else {//超过一周
            console.log(billList)
            var len = billList.length - 1;
            billList[len].weekCost = num2(sum);
            billList[len].weekIncome = num2(income);
          }
        }
        //插入最终表单
        billList.push(dayAll);
        //清空变量！！！
        dayAll = {
          date: '',
          cost: 0,
          income: 0,
          dayList: []
        };
      }
      //新一个消费数据
      dayList = {
        cost: num2(bill[i].money),
        where: bill[i].where,
        time: bill[i].time,
        type: bill[i].type
      };
      dayAll.date = bill[i].date;
      dayList.cost <= i ? dayAll.cost += dayList.cost : dayAll.income += dayList.cost;
      dayAll.dayList.push(dayList);
      sum += dayAll.cost;
      income += dayAll.income; //当天消费构造完毕

      //开始统计第一天图表列表
      let money = -num2(bill[i].money),
        type = bill[i].type;
      if (money > 0) {
        ecList[type].cost += money;
        ecList[type].name = bill[i].where;
        ecList[type].times++;

        ecList[type].cost = num2(ecList[type].cost);
      }
      ecList[type].type = bill[i].type;
    }
    //处理最后一天
    //判断是否为同一周
    stamp != 0 && 1, stamp1 = Date.parse(dayAll.date);
    if (stamp != 0 && stamp - stamp1 >= 518400000) {
      stamp = 0;//到一周，标记结束
      if (stamp - stamp1 == 518400000) {//刚好一周
        tempObj.weekCost = num2(sum);
        tempObj.weekIncome = num2(sum);
      } else {//超过一周
        console.log(billList)
        var len = billList.length - 1;
        billList[len].weekCost = num2(sum);
        billList[len].weekIncome = num2(income);
      }
    }
    //最后一天插入
    billList.push(dayAll);

    console.log('ec', ecList)
    console.log('billList', billList)
    var ykt = {
      billList: billList,
      ye: ye,
      sum: num2(sum),
      ecList: ecList,
      month: app.time.M + 1
    };
    return ykt;

    //将保留两位小数封装成函数
    function num2(e) {
      return Math.round(e * 100) / 100;
    }
  },

  /**
   * 选择月份
   */
  selectMonth(e) {
    console.log(e)
    var date = e.detail.value;
    date = date.match(new RegExp(/(\d\d\d\d)-(\d\d)/), "");
    console.log('date', date);
    if (date[2] > app.time.M + 1) {
      app.showError('提醒', '哎呀，原谅我还不能未仆先知！')
      return;
    } else if (date[2] == this.data.month) {
      return;
    }
    this.setData({
      date: date[0],
      year: date[1],
      month: date[2],
      select: true
    })
    var start = Date.parse(date[1] + '/' + date[2] + '/01') / 1000,
      end = (Date.parse(date[1] + '/' + (Number(date[2]) + 1) + '/01') / 1000) - 86400;
    app.removeCache('ykt')

    this.getbill(start, end, true);
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var date = app.time.Y + '/' + (app.time.M + 1);
    this.setData({
      date: date,
      year: app.time.Y,
      month: app.time.M + 1
    })
    var start = Date.parse(date + '/01') / 1000,
      end = app.time.stamp;
    console.log('000', start, end)
    this.getbill(start, end);
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 获取组件
    this.ecComponent = this.selectComponent('#mychart-dom-pie');
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

  // 点击按钮后初始化图表
  init: function () {
    var that = this;
    wx.createSelectorQuery().select('#tab-nav').boundingClientRect(function (rect) {
      let margin = rect.bottom  // 节点的下边界坐标
      console.log('rect', rect)
      that.setData({ margin_nav: margin + 5 })
    }).exec()
    this.ecSort();
    this.ecComponent.init((canvas, width, height) => {
      // 获取组件的 canvas、width、height 后的回调函数
      // 在这里初始化图表
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      var option = {
        backgroundColor: "#ffffff",
        color: ["#e54d42", "#f37b1d", "#8dc63f", "#39b54a", "#0081ff", "#9c26b0", "#8799a3"],
        series: [{
          label: {
            normal: {
              fontSize: 12
            }
          },
          type: 'pie',
          center: ['50%', '50%'],
          radius: [0, '60%'],
          data: this.data.chartList,
          itemStyle: {
            emphasis: {
              shadowBlur: 10,
              shadowOffsetX: 0,
              shadowColor: 'rgba(0, 2, 2, 0.3)'
            }
          }
        }]
      };

      setOption(chart, option);

      // 将图表实例绑定到 this 上，可以在其他成员函数（如 dispose）中访问
      this.chart = chart;

      this.setData({
        isLoaded: true,
        isDisposed: false,
        TabCur: 1
      });

      // 注意这里一定要返回 chart 实例，否则会影响事件处理等
      return chart;
    });
  },

  /**
 * 分类整理
 */
  ecSort() {
    var ykt = app.cache.ykt,
      ecList = ykt.ecList,
      chartList = [],
      temp = {};
    ecList.forEach(function (val, key) {
      temp = { name: '', value: '' }
      if (val.times > 0) {
        if (!app.empty(val.name.match(new RegExp(/(\S*?)，/), ""))) {
          val.name = val.name.match(new RegExp(/(\S*?)，/), "")[1];
        }
        temp.name = val.name;
        temp.value = val.cost / ykt.sum;
        chartList.push(temp);
      }
    })
    console.log('chartList', chartList);
    this.setData({
      chartList: chartList
    })
  },

  dispose: function () {
    wx.redirectTo({
      url: 'ykt',
    })
  },

  /**
 * 生命周期函数--监听页面隐藏
 */
  onHide: function () {
    if (this.data.month != app.time.M) {
      app.removeCache('ykt')
    }
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    if (this.data.month != app.time.M) {
      app.removeCache('ykt')
    }
  },


})