//common.js

/**
 * 优化字符串长度
 */
const beautySub = (str, len) => {
  var reg = /[\u4e00-\u9fa5]/g,    //专业匹配中文
    slice = str.substring(0, len),
    chineseCharNum = (~~(slice.match(reg) && slice.match(reg).length)),
    realen = slice.length * 2 - chineseCharNum;
  return str.substr(0, realen) + (realen < str.length ? "..." : "");
}

/**
 * 返回一系列时间
 * @param js时间戳
 */
const GetTime = (stamp,xn_start) => {
  var time = {};
  stamp = stamp / 1000;
  var n = stamp * 1000;
  time.stamp = stamp;
  var date = new Date(n);
  var Y = date.getFullYear(); //年
  time.Y = Y;
  var M = date.getMonth(); //月份从零开始算
  time.M = M;
  var D = date.getDate(); //日
  time.D = D;
  var day = date.getDay() //周日为0，周一为1
  time.day = day;
  var H = date.getHours(); //小时
  time.H = H;
  var Min = date.getMinutes();
  time.Min = Min;

  var a = xn_start; //月份减一
  var b = new Date(Y, M, D);
  var week = Math.floor(((b - a) / (24 * 60 * 60 * 1000) / 7)); /*周日为新的一周用floor不能用ceil*/
  time.week = week

  return time;
}

function toStrWeek(e) {
  var week = '我的课表';
  switch (e) {
    case 0:
      week = '第零周';
      break;
    case 1:
      week = '第一周';
      break;
    case 2:
      week = '第二周';
      break;
    case 3:
      week = '第三周';

      break;
    case 4:
      week = '第四周';
      break;
    case 5:
      week = '第五周';
      break;
    case 6:
      week = '第六周';
      break;
    case 7:
      week = '第七周';
      break;
    case 8:
      week = '第八周';
      break;
    case 9:
      week = '第九周';
      break;
    case 10:
      week = '第十周';
      break;
    case 11:
      week = '第十一周';
      break;
    case 12:
      week = '第十二周';
      break;
    case 13:
      week = '第十三周';
      break;
    case 14:
      week = '第十四周';
      break;
    case 15:
      week = '第十五周';
      break;
    case 16:
      week = '第十六周';
      break;
    case 17:
      week = '第十七周';
      break;
    case 18:
      week = '第十八周';
      break;
    case 19:
      week = '第十九周';
      break;
    case 20:
      week = '第二十周';
      break;
  }
  return week;
}
/**
 * num week-> str week
 */
function toStrDay(e) {
  var day = '';
  switch (e) {
    case 0:
      day = '日';
      break;
    case 1:
      day = '一';
      break;
    case 2:
      day = '二';
      break;
    case 3:
      day = '三';
      break;
    case 4:
      day = '四';
      break;
    case 5:
      day = '五';
      break;
    case 6:
      day = '六';
      break;
  }
  return day;
}

var stu_time = [{
      begin: '8:00', //1
      end: '8:45'
    },
    {
      begin: '8:55', //2
      end: '9:40'
    },
    {
      begin: '10:00', //3
      end: '10:45'
    },
    {
      begin: '10:55', //4
      end: '11:40'
    },
    {
      begin: '11:50', //5
      end: '12:35'
    },
    {
      begin: '14:00', //6
      end: '14:45'
    },
    {
      begin: '14:55', //7
      end: '15:40'
    },
    {
      begin: '16:00', //8
      end: '16:45'
    },
    {
      begin: '16:55', //9
      end: '17:40'
    },
    {
      begin: '17:50', //0
      end: '18:35'
    },
    {
      begin: '19:20', //A
      end: '20:05'
    },
    {
      begin: '20:15', //B
      end: '21:00'
    },
    {
      begin: '21:10', //C
      end: '21:55'
    }
  ];
  var sumc_time = [{
      begin: '8:00', //1
      end: '8:50'
    },
    {
      begin: '9:00', //2
      end: '9:50'
    },
    {
      begin: '10:10', //3
      end: '11:00'
    },
    {
      begin: '11:10', //4
      end: '12:00'
    },
    {
      begin: '14:30', //5
      end: '15:20'
    },
    {
      begin: '15:30', //6
      end: '16:20'
    },
    {
      begin: '16:30', //7
      end: '17:20'
    },
    {
      begin: '19:30', //8
      end: '20:20'
    },
    {
      begin: '20:30', //9
      end: '21:20'
    },
    {
      begin: '21:30', //10
      end: '22:20'
    }
  ];

  const swiperList = [
    {
      type: 'w',
      tap: 'w'
    },
    {
      type: 'img',
      img: "https://ae01.alicdn.com/kf/H0850c387154243e69fd2da2ca759a0592.jpg",
      tap: 'https://mp.weixin.qq.com/s/4wS6v82ztZnk0Tre0_5MeA'

    },
    {
      type: 'img',
      img: "https://ae01.alicdn.com/kf/Heb2ef71fa023449bab0c26ae944fcd54c.jpg",
      tap: 'https://mp.weixin.qq.com/s/sLBROxJqV-smLA1LKvLqcg'
    },
    // {
    //   type: 'img',
    //   img: "https://ae01.alicdn.com/kf/H344387a0bf334ffdbda9d4f369ae6d437.png",
    //   tap: 'https://mp.weixin.qq.com/s/9BTwCIdme5fJMJ7_uoSNrA'
    // },
    // {
    //   type: 'img',
    //   img: "https://ae01.alicdn.com/kf/H49332d42db30480ca1636e42c7c958a3K.png",
    //   mini: 'wetrack'
    // },
    
  ]



  module.exports = {
    beautySub: beautySub,
    toStrWeek: toStrWeek,
    toStrDay: toStrDay,
    GetTime: GetTime,
    stu_time,
    sumc_time,
    swiperList: swiperList
  }