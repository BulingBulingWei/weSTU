"use strict";
const md5 = require('./md5.js');
const Tools = require('./common.js')


module.exports = {
    extend: extend,
    checkLogin: checkLogin,
    post: post,
    saveCache: saveCache,
    removeCache: removeCache,
    key:key,
    empty: empty,
    showError: showError,
    showLoad: showLoad,
    checkUpdate: checkUpdate,
    toast: toast,
}



/**
 * 拓展对象
 * 浅拷贝与深拷贝
 */
function extend() {
    var aLength = arguments.length;
    var options = arguments[0];
    var target = {};
    var copy;
    var i = 1;
    if (typeof options === "boolean" && options === true) {
        //深拷贝 (仅递归处理对象)
        for (; i < aLength; i++) {
            if ((options = arguments[i]) != null) {
                if (typeof options !== 'object') {
                    return options;
                }
                for (var name in options) {
                    copy = options[name];
                    if (target === copy) {
                        continue;
                    }
                    target[name] = this.extend(true, options[name]);
                }
            }
        }
    } else {
        //浅拷贝
        target = options;
        if (aLength === i) {
            target = this;
            i--;
        } //如果是只有一个参数，拓展功能 如果两个以上参数，将后续对象加入到第一个对象
        for (; i < aLength; i++) {
            options = arguments[i];
            for (var name in options) {
                target[name] = options[name];
            }
        }
    }
    return target;
}



/**
 * 判断是否登录
 * @param e为1则关闭跳转，为零则不关闭跳转
 */
function checkLogin(url, e = 1) {
    if (this.user.is_bind === false) {
        if (e) {
            wx.redirectTo({
                url: url,
            })
        } else {
            wx.navigateTo({
                url: url,
            })
        }
    }
}

//分享时自动登录
function shareLogin() {

}

/**
 * 发出网络请求
 * @param {string} url 
 * @param {Array} data 
 */
function post (url = '', data = {}) {
    var app = this;
    //return data.g_openid = app.wx.g_openid, console.log(data), new Promise(function (n, s) {
    return data.g_openid = app.wx.g_openid, console.log(data), new Promise(function (resolve, reject) {
        wx.request({
            url: app.server + url,
            data: app.key(data),
            method: "post",
            success: function (res) {
                wx.hideLoading(), 1 != res.data.state && showError('提醒', res.data.msg || '未知错误'), resolve(res.data);
            },
            fail: function (res) {
                wx.hideLoading(), showError('提醒', res.data.msg || '未知错误'), reject(res);
            }
        });
    });
}

/**
 * 保存缓存同时添加到全局变量
 * @param {string} key 
 * @param {*} value 
 */
function saveCache(key, value) {
    if (!key || !value) {
        return;
    }
    var app = this;
    app.cache[key] = value;
    wx.setStorageSync(key, value)
}

/**
 * 删除缓存同时清空全局变量
 * @param {*} key 
 */
function removeCache(key) {
    if (!key) {
        return;
    }
    var app = this;
    app.cache[key] = '';
    wx.removeStorageSync(key)
}

/**
 * 加密请求信息
 * @param {array} data 
 */
function key(data) {
    var mingwen = '',
        anwen = '';
    for (var key in data) {
        if (typeof (data[key]) !="undefined"){
            mingwen = mingwen + data[key]
        }
    }
    console.log(mingwen)
    anwen = md5.md5("#@qb.+" + mingwen);
    data.hash = anwen;
    return data;
}

/**
 * 判断JS变量是否空值，如果是undefined， null， ''， NaN，false，0，[]，{} ，空白字符串，都返回true，否则返回false
 * @param {*} v 
 */
function empty(v) {
    switch (typeof v) {
        case 'undefined':
            return true;
        case 'string':
            if (v.replace(/(^[ \t\n\r]*)|([ \t\n\r]*$)/g, '').length == 0) return true;
            break;
        case 'boolean':
            if (!v) return true;
            break;
        case 'number':
            if (0 === v || isNaN(v)) return true;
            break;
        case 'object':
            if (null === v || v.length === 0) return true;
            for (var i in v) {
                return false;
            }
            return true;
    }
    return false;
}

/**
 * 
 * @param {string} title 
 * @param {string} content 
 */
function showError(title, content) {
    wx.showModal({
        title: title || '加载失败',
        content: content || '未知错误',
        showCancel: false
    });
}

/**
 * 显示加载弹窗
 * @param {int} option
 * @param {string} title 
 * @param {int} duration 
 */
function showLoad (option,title, duration) {
    switch (option) {
        case 1:
            wx.showNavigationBarLoading();
            break;
        case 2:
            wx.showNavigationBarLoading();
            wx.setNavigationBarTitle({
                title: title || 'loading'
            })
            break;
        case 3:
            wx.showLoading({
                title: title || 'loading',
                mask: true,
                duration: duration || 1500
            })
            break;
    }
}

/**
 * 小程序更新
 */
function checkUpdate() {
    if (!wx.getUpdateManager) return false;
    wx.getUpdateManager().onCheckForUpdate((res) => {
        console.log("Update:" + res.hasUpdate);
        if (res.hasUpdate) { //如果有新版本
            wx.getUpdateManager().onUpdateReady(() => { //当新版本下载完成
                wx.showModal({
                    title: '更新提示',
                    content: '新版本已经准备好，单击确定重启应用',
                    success: (res) => {
                        if (res.confirm) wx.getUpdateManager().applyUpdate(); //applyUpdate 应用新版本并重启
                    }
                })
            })
            wx.getUpdateManager().onUpdateFailed(() => { //当新版本下载失败
                wx.showModal({
                    title: '提示',
                    content: '检查到有新版本，但下载失败，请检查网络设置',
                    showCancel: false
                })
            })
        }
    })
}

/**
 * 弹窗提醒
 * @param {string} e 
 * @param {int} time 
 * @param {string} icon 
 */
function toast(e, time = 2000, icon = 'none') {
    wx.showToast({
        title: e,
        icon: icon,
        duration: time
    })
}