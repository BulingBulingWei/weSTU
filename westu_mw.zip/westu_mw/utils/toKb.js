const app = getApp();
const Tools = require('common.js');
/**
 * 将stu列表转化成数组
 */
const sort_stu_kb = e => {
  var that = this;
  var week = 0,
    weekkb = [],
    kb = [new Array(), new Array(), new Array(), new Array(),
           new Array(), new Array(), new Array(), new Array(), 
           new Array(), new Array(), new Array(), new Array(), 
           new Array(), new Array(), new Array(), new Array(),
          new Array(), new Array(), new Array(), new Array()],
    id = 0,
    jieci = '', 
    startjc = '',
    len = '', 
    temp = {};
  for (var i = 0; i < e.length; i++) { //每门课循环
    for (var j = parseInt(e[i]['week0']); j <= parseInt(e[i]['week1']); j++) { //起始周至结束周循环
      for (var k = 0; k < 7; k++) { //每周7天循环
        var n = k; //数据库中的星期几
        if (e[i]['time'][n] != "") { //如果当天有课则参与循环
          temp = {
            id: 0
          };
          temp.id = e[i]['id']; //0
          temp.cid = e[i]['cid']; //1->id
          temp.week = parseInt(j); //2->week
          temp.day = n; //3->day
          temp.xl = temp.week+'->'+temp.day;
          temp.week0 = e[i]['week0'];
          temp.week1 = e[i]['week1'];
          var day = k + 1;
          var reg1 = /([单双])/;
          var ds = e[i]['time'][n].match(reg1);

          if (ds != null) {
            ds = e[i]['time'][n].substr(0, 1);
            //console.log(ds)
          }
          if (ds == '单') {
            if (j % 2 != 0) {
              //console.log('单', ds)
              var pureJieci = e[i]['time'][n].replace(/单/, '');
              //console.log('dan', e);
              var info = new Array();
              info = stu_jieci(pureJieci);
              jieci = pureJieci;
              startjc = info[1];
              len = info[2];
            } else {
              temp.id = false;
            }
          } else if (ds == '双') {
            if (j % 2 == 0) {
              var pureJieci = e[i]['time'][n].replace(/双/, '');
              //console.log('shuang', e);
              var info = new Array();
              info = stu_jieci(pureJieci);
              jieci = pureJieci;
              startjc = info[1];
              len = info[2];
            } else {
              temp.id = false;
            }
          } else {
            info = stu_jieci(e[i]['time'][n]);
            //console.log('info',info)
            jieci = e[i]['time'][n];
            startjc = info[1];
            len = info[2];
          }

          temp.jieci = jieci; //4->jieci

          temp.start = startjc; //5->startjc

          temp.length = len; //6->length
          var preg = /](.*)/
          var title = e[i]['sub'].match(preg);
          title = title[1];

          temp.title = title; //7->title
          temp.sub = e[i]['sub']; //8->content
          temp.teacher = e[i]['teacher']; //9->teacher
          temp.room = e[i]['room']; //10->room
          temp.score = e[i]['score']; //11->score
          temp.color = e[i]['color'];
          temp.nick = e[i]['nick'];

          console.log("temp",temp)

          if (temp.id !== false) {
            week = temp.week;
            weekkb = kb[week];
            weekkb.push(temp);
            kb[week] = weekkb;
          }
        }
      }
    }
  }
  if (app.user.xn == '2020' && app.user.xq == 1) {
    app.saveCache('kb', kb);
    app.saveCache('kb_' + app.user.xn + '-' + app.user.xq, kb);
  } else {
    app.saveCache('kb_' + app.user.xn + '-' + app.user.xq, kb);
  }
  //app.saveCache('kb', kb)
  console.log('kb', kb)
  return kb;
}

/**
 * 将汕大字母节次转化为数字
 */
const stu_jieci = e => {
  var jieci = '';
  var len = e.length;
  for (var l = 0; l < len; l++) {
    var str = e.substring(l, l + 1);
    var m = 2;
    if (str == 'A') {
      str = 11;
    } else if (str == 'B') {
      str = 12;
    } else if (str == 'C') {
      str = 13;
    } else if (str == 0) {
      str = 10;
    } else {
      str = parseInt(str);
      m = 1;
    }
    jieci = jieci + str + ",";
  }
  jieci = jieci.substr(0, jieci.length - 1);
  var startjc = jieci.substr(0, m);
  var info = new Array();
  info[0] = jieci; //jieci
  info[1] = parseInt(startjc); //startjc
  info[2] = len; //len
  return info;
}

/**
 * 将add列表转化成数组
 */
const sort_add_kb = e => {
  var that = this;
  var week = 0,
    weekkb = [],
    kb = [new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array(), new Array()],
    id = 0,
    jieci = '',
    startjc = '',
    len = '',
    temp = {};
  for (var i = 0; i < e.length; i++) { //每门课循环
    for (var j = parseInt(e[i]['week0']); j <= parseInt(e[i]['week1']); j++) { //起始周至结束周循环
      var n = e[i].day; //数据库中的星期几
      temp = {
        id: 0
      };
      temp.id = e[i]['id']; //0
      temp.cid = e[i]['id']; //1->id
      temp.week = parseInt(j); //2->week
      temp.day = n; //3->day
      var last = e[i].jieci.substr(-1, 1),
          start = e[i].jieci.substr(0,1),
        jieci = e[i].jieci;
      switch (last) {
        case '0':
          start = 10;
          break;
        case 'A':
          last = 11;
          break;
        case 'B':
          last = 12;
          break;
        case 'C':
          last = 13;
          break;
        default:
          last = parseInt(last);
      }
      switch (start) {
        case '0':
          start = 10;
          break;
        case 'A':
          start = 11;
          break;
        case 'B':
          start = 12;
          break;
        case 'C':
          start = 13;
          break;
        default:
          start = parseInt(start);
      }
      temp.jieci = jieci;
      temp.start = start;
      temp.length = last - start + 1; //len

      temp.title = e[i]['sub']; //7->title
      temp.sub = e[i]['sub']; //8->content
      temp.teacher = e[i]['teacher']; //9->teacher
      temp.room = e[i]['room']; //10->room
      temp.color = e[i]['color'];
      temp.nick = e[i]['nick'];
      temp.type = e[i]['type'] || '自定义';

      week = temp.week;
      weekkb = kb[week];
      weekkb.push(temp);
      kb[week] = weekkb;
    }
  }
  app.saveCache('kb_add', kb)
  console.log('kb', kb)
  return kb;
}

/**
 * 下载汕医课程列表
 */
const load_sumc_list = e => {
  var that = this,
    classname = app.user.classname,
    uid = app.user.uid,
    kb = app.cache.kb,
    kb_list = wx.getStorageSync('kb_list');
  if (!app.empty(kb_list)) {
    app.empty(app.cache.kb) && load_sumc_kb();
    return kb_list;
  } else {
    app.post('syjx/loadlist', {
      classname: classname,
    }).then(function(e) {
      if (e.state == 1) {
        console.log('sumc_kb_list', e);
        var data = e.data;
        app.saveCache("kb_list", data);
        data = sortId(data)
        load_sumc_kb();
        return data;
      }
    });
  }

}

/**
 * 下载汕大课程列表
 */
const load_stu_kb = res => {
  var that = this,
    kb_list = wx.getStorageSync('kb_list_' + app.user.xn + '-' + app.user.xq),
    user = app.user;
    console.log('load',kb_list)
  // if(!app.user.psw){
  //   wx.showModal({
  //     title: '提示',
  //     content: '您好，自动登录未输入密码，从学分制更新课表功能需要先登录，是否前往？',
  //     success:function(res){
  //       if(res.confirm){
  //         wx.navigateTo({
  //           url: '../login/login'
  //         })
  //       }
  //     }
  //   })
  //   return;
  // }
  if (!app.empty(kb_list)) {
    return kb_list;
  } else {
    wx.showLoading({
      title: 'loading...',
    })
    app.post('Stukb/loadkb', {
      uid: user.uid,
      username: user.username,
      psw: user.psw,
      xn: 2020,
      xq: 1
    }).then(function(e) {
      console.log('stu_kb_list', e);
      if (e.state == 1) {
        var data = e.data.kb;
        //app.saveCache("kb_list", data);
        data = sortId(data, true);
        sort_stu_kb(data);
        return data;
      }
    });
  }
}

/**
 * 为每门课程增加Id,输出列表
 * @param e 课程列表
 * @param stu 是否为汕大
 */
const sortId = (e, stu = false) => {
  console.log('origin', e)
  var that = this;
  //var colors = this.colors;
  var manyColor = colors.concat(colors)
  console.log('color',colors)
  var list = [];
  e.forEach(function(val, key) {
    val.id = key;
    val.color = manyColor[key].color;
    val.nick = '';
    if (stu) {
      var preg = /](.*)/;
      val.title = val.sub.match(preg)[1];
      val.showtime = sort_stu_time(val.time);
    } else {
      val.title = val.sub;
      val.day = Tools.toStrDay(val.day);
      val.showtime = '周' + val.day + val.jieci + '节 ';
    }
    list.push(val);
  })
  console.log('list', list)
  if(!stu){
    //非医学院
    app.saveCache('kb_list', list);
  }else if(app.user.xn == '2020-2021' && app.user.xq == 1){
    app.saveCache('kb_list', list);
    app.saveCache('kb_list_' + app.user.xn + '-' + app.user.xq, list);
  }else{
    app.saveCache('kb_list_'+app.user.xn+'-'+app.user.xq, list);
  }

  return list;
}

/**
 * 整理汕大时间
 *@param array 数据库传回的时间格式
 */
const sort_stu_time = e => {
  var that = this;
  var time = '';
  e.forEach(function(val, key) {
    //console.log(key,val)
    if (!app.empty(val)) {
      time = '周' + Tools.toStrDay(key) + val + '节 ';
    }
  })
  return time;
}

/**
 * 下载汕医课表
 * @param string 需下载的班级
 */
const load_sumc_kb = res => {
  console.log('e', res)
  var that = this;
  var kb_list = app.cache.kb_list,
    kb = app.cache.kb,
    user = app.user,
    classname = '';
  app.empty(res) ? classname = user.classname : classname = res;
  wx.showLoading({
    title: 'loading...',
  })
  app.post('syjx/loadkb', {
    uid: user.uid,
    classname: classname,
    xn: '2020-2021',
    xq: 1
  }).then(function(e) {
    if (e.data == 'login') {
      wx.navigateTo({
        url: '/pages/login/ucLogin'
      })
    }else{
      console.log('sumc_kb', e);
      var data = e.data,
        name = '';
      app.empty(res) ? name = 'kb' : name = 'kb-' + res;
      app.saveCache(name, data);
      return true;
    }
  })
}

const sortName = classname =>{
  //简化名称
  var arr = classname.split("级"),
    bj = arr[1];
  switch (bj) {
    case "口腔班":
      bj = "口腔";
      break;
    case "本科口腔班":
      bj = "口腔";
      break;
    case "全英班":
      bj = "全英";
      break;
    case "一体化全英班":
      bj = "全英";
      break;
    case "儿科班":
      bj = "儿科";
      break;
    case "护理班":
      bj = "护理";
      break;
    case "护理全英":
      bj = "护理全英";
      break;
    case "主动学习班":
      bj = "主学";
      break;
    case "中港班":
      bj = "中港";
      break;
    default:
      bj = bj.replace(/全英/, "");
      bj = bj.replace(/一体化/, "本硕");
  }
  return arr[0].substr(2, 2) + ' ' + bj;
}

/**
 *课表颜色
 */
const colors = [{
    title: '橄榄',
    name: 'red',
    color: '#afec37'
  },
  {
    title: '雪清',
    name: 'white',
    color: '#b0a4e3'
  },

  {
    title: '雅黄',
    name: 'orange',
    color: '#fadd5b'
  },
  {
    title: '粉红',
    name: 'yellow',
    color: '#ff9295'
  },
  {
    title: '石青',
    name: 'grey',
    color: '#3de1ad'
  },

  {
    title: '森绿',
    name: 'green',
    color: '#39b54a'
  },
  {
    title: '天蓝',
    name: 'cyan',
    color: '#73b4ef'
  },
  {
    title: '墨灰',
    name: 'blue',
    color: '#8baaaa'
  },
  {
    title: '蔚蓝',
    name: 'purple',
    color: '#76eaea'
  },
  {
    title: '桃粉',
    name: 'mauve',
    color: '#ee5197'
  },
  {
    title: '水红',
    name: 'pink',
    color: '#ffa17d'
  },
  {
    title: '翡翠',
    name: 'brown',
    color: '#59f0a3'
  },
  {
    title: '黛紫',
    name: 'olive',
    color: '#764ba2 '
  },

  {
    title: '秋色',
    name: 'gray',
    color: '#c79081'
  },
  {
    title: '枣红',
    name: 'black',
    color: '#c32136'
  },
]






module.exports = {
  sort_stu_kb: sort_stu_kb,
  sort_add_kb: sort_add_kb,
  load_sumc_list: load_sumc_list,
  load_stu_kb: load_stu_kb,
  sortId: sortId,
  sort_stu_time: sort_stu_time,
  load_sumc_kb: load_sumc_kb,
  colors: colors,
  sortName: sortName
}