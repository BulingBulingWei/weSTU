//app.js
const utils = require('utils/util')
const Tools = require('utils/common')

App({
  //定义全局变量
  version: 'Beta 2.0.1',
  globalData: {
    sys_update: true,//是否强制更新版本
    /**
     * 是否重新登陆获取信息
     * 0 重新输入账号密码
     * 1 自动重新登陆
     * 2 清空课表一卡通等信息缓存
     */
    sys_clearCache: 1,
    sys_modal: '',
    xn: 2020,
    xq: 1,
    xn_start: new Date(2020, 7, 22)
  },
  user: {
    is_bind: false,
    status: 'guest',
  },
  design: {
    textSize: 22,
    isWhite: false,
    isLine: true,
    //bgOpacity:20,
    //cellOpacity:20,
    //url:'http://img.stuhb.top/7bd80201906241439197186.png'  
  },
  wx: {

  },
  cache: {},
  time: {},
  _server: 'http://localhost/tp5/public/we/',
  server: 'https://www.stuhb.top/api/public/we/',

  /**
   * 小程序启动函数
   */
  onLaunch: function () {
    console.log("APP INIT", this);
    var app = this;
    //检测新版本
    if (app.globalData.sys_update) {
      const updateManager = wx.getUpdateManager();
      updateManager.onUpdateReady(function () {
        updateManager.applyUpdate()
      })
    }
    /**获取当前屏幕信息 */
    wx.getSystemInfo({
      success: e => {
        this.globalData.StatusBar = e.statusBarHeight;
        this.globalData.CustomBar = e.platform == 'android' ? e.statusBarHeight + 50 : e.statusBarHeight + 45;
        this.globalData.CustomHeight = e.windowHeight;
        this.globalData.CustomWidth = e.windowWidth;
        console.log('sysInfo0', e, this.globalData)
      },
      fail: e => {
        this.globalData.StatusBar = 20;
        this.globalData.CustomBar = e.platform == 'android' ? 20 + 50 : 20 + 45;
        this.globalData.CustomHeight = e.windowHeight;
        this.globalData.CustomWidth = e.windowWidth;
        console.log('sysInfo00', e, this.globalData)
      }
    })
    //获取当前时间
    var timestamp = Date.parse(new Date());
    console.log('timestamp',timestamp);
    app.time = Tools.GetTime(timestamp, app.globalData.xn_start);
    console.log('time', app.time)

    //检查缓存是否为空
    var user = wx.getStorageSync('user');
    var oldwx = wx.getStorageSync('wx')
    // if (!user) {
    //   this.reLogin('');
    //   return;
    // }
    //读取缓存
    try {
      wx.getStorageSync('version') !== app.version && wx.clearStorageSync();
      switch (this.globalData.sys_clearCache) {
        case 0:
          if (empty(user) || user.status == 'sumc' || empty(user.uid)) {
            console.log('here')
            if (wx.getStorageSync('version') != app.version) {
              wx.clearStorageSync()
            }
            break;
          }

        case 1:
          if (wx.getStorageSync('version') != app.version) {
            this.user.psw = user.psw;
            this.user.username = user.username;
            this.user.cjpsw = user.cjpsw;
            this.reLogin(user,oldwx);
            wx.setStorageSync('version', app.version)
          }
          break;

        case 2:
          if (wx.getStorageSync('version') != app.version) {
            var design = wx.getStorageSync('design'),
              Wxcache = wx.getStorageSync('wx');
            wx.clearStorageSync()
            saveCache('user', user);
            saveCache('wx', Wxcache);
            saveCache('design', design);
          }
          break;

        default:
          break;
      }
      //读取全部缓存
      wx.setStorageSync('version', app.version)
      var data = wx.getStorageInfoSync();
      if (data && data.keys.length) {
        data.keys.forEach(function (key) {
          var value = wx.getStorageSync(key);
          if (value) {
            app.cache[key] = value;
          }
        });

        if (!utils.empty(app.cache.user)) app.user = app.cache.user;
        if (!utils.empty(app.cache.wx)) app.wx = app.cache.wx;
        if (!utils.empty(app.cache.design)) app.design = app.cache.design;
      }
      console.log('app.cache', app.cache)
    } catch (e) {
      console.warn(e);
    }

  },
  /**
* 重新登陆
* @param {*} username 
* @param {*} psw 
* @param {*} g_openid 
* @param {*} x_openid 
*/
  reLogin: function (user,oldwx) {
    console.log('relogin', user)
    var that = this;
    wx.showLoading({
      title: '登录中...',
    });
    if (!user.psw) {
      console.log('autoLogin');
      //自动登录
      wx.login({
        success: res => {
          console.log('code', res)
          wx.request({
            url: 'https://www.stuhb.top/api/public/we/wemini/autoLogin',
            method: 'post',
            data: utils.key({
              code: res.code
            }),
            success: function (res) {
              that.successFun(res, user);
            },
            fail: function (res) {
              wx.showToast({
                title: '网络错误！请重新打开！',
                icon: 'none',
                duration: 2000
              });
            }
          })
        }
      })
    } else {
      //带密码重新登陆
      wx.request({
        method: 'POST',
        url: 'https://www.stuhb.top/api/public/we/login/relogin',
        data: utils.key({
          username: user.username,
          psw: user.psw,
          x_openid: oldwx.x_openid,
          g_openid: oldwx.g_openid,
        }),
        success: res => {
          that.successFun(res, user);
          app.modal = 'bottom';
        },
        fail: res => {
          console.log(res);
          showError('重新失败', res.errMsg);
        },
        complete: res => {
          wx.hideLoading();
        }
      })
    }


  },

  /**
   * 
   * @param {成功登录} res 
   */
  successFun: function (res, user) {

    if (res.data.state == 1) {
      var data = res.data.data;
      var newWx = wx.getStorageSync('wx');
      if (!newWx) newWx = {
        g_openid: data.g_openid,
        x_openid: data.x_openid
      }
      var newUser = {
        "id": 2,
        "name": data.name,
        "uid": data.uid,
        "department": data.department,
        "username": data.username,
        "psw": user.psw,
        "classname": data.classname,
        "is_bind": true,
        "ks_remind": data.ks_remind,
        "xf_remind": data.xf_remind,
        "kb_remind": data.kb_remind,
        "cjpsw": user.cjpsw,
        "xn": 2020,
        'xq': 1
      };
      data.department == "医学院" ? newUser.status = 'sumc' : newUser.status = 'stu';

      var oaHis = wx.getStorageSync('oaHistory');
      var design = wx.getStorageSync('design');
      wx.setStorageSync('user', newUser)
      wx.setStorageSync('wx', newWx);
      if (oaHis) wx.setStorageSync('oaHistory', oaHis);
      if (design) wx.setStorageSync('design', design);
      wx.showToast({
        title: '登陆成功',
        icon: 'success',
        duration: 1500
      });
      wx.reLaunch({
        url: 'index?action=reLogin'
      });
    } else {
      //showError('自动登陆失败', res.data.msg);
    }
  },
  extend: utils.extend
})



const app = getApp();

//拓展app功能
app.extend({
  checkLogin: utils.checkLogin,
  post: utils.post,
  saveCache: utils.saveCache,
  removeCache: utils.removeCache,
  key: utils.key,
  empty: utils.empty,
  showError: utils.showError,
  showLoad: utils.showLoad,
  checkUpdate: utils.checkUpdate,
  toast: utils.toast
});
