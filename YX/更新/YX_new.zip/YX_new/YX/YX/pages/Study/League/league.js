// pages/Study/league/league.js

/**
 * 处理脚本
 */
// $s = preg_replace("/[ ]+/", "','", $s);
// $s = str_replace("\n", "'],['", $s);
// $s = str_replace("\r", "", $s);
// echo $s;

Page({

  /**
   * Page initial data
   */
  data: {
    Data:['目前各个书院内都设有社团，在此不一一罗列'],
    data: [['招生宣传协会', '志愿公益类'],
      ['创意公益协会', '志愿公益类'],
      ['创业者协会', '创业实践类'],
      ['职业规划与发展协会', '创业实践类'],
      ['汕头大学商务实践中心', '创业实践类'],
      ['大学生心理成长协会', '思想政治类'],
      ['模拟联合国协会', '思想政治类'],
      ['青年马克思主义学会', '思想政治类'],
      ['法学社', '思想政治类'],
      ['街舞协会', '文化艺术类'],
      ['国标舞协会', '文化艺术类'],
      ['玉音乐社', '文化艺术类'],
      ['吉他协会', '文化艺术类'],
      ['弦乐社', '文化艺术类'],
      ['兴潮社', '文化艺术类'],
      ['手工社', '文化艺术类'],
      ['书画协会', '文化艺术类'],
      ['动漫协会', '文化艺术类'],
      ['Dreamers图文社', '文化艺术类'],
      ['摄影协会', '文化艺术类'],
      ['日语协会', '文化艺术类'],
      ['边缘设计协会', '文化艺术类'],
      ['灯谜爱好者协会', '文化艺术类'],
      ['魔术协会（转院级）', '文化艺术类'],
      ['科幻协会', '文化艺术类'],
      ['茶道社', '文化艺术类'],
      ['思凡戏剧社', '文化艺术类'],
      ['汕头大学鹿鸣文学社', '文化艺术类'],
      ['草根播报', '文化艺术类'],
      ['乒乓球协会', '体育健康类'],
      ['网球协会', '体育健康类'],
      ['排球协会', '体育健康类'],
      ['毽球协会', '体育健康类'],
      ['触式橄榄球协会', '体育健康类'],
      ['羽毛球协会', '体育健康类'],
      ['青羚健跑协会', '体育健康类'],
      ['雪豹户外协会', '体育健康类'],
      ['轮滑爱好者协会', '体育健康类'],
      ['滑板社', '体育健康类'],
      ['汕大空手道社', '体育健康类'],
      ['跆拳道协会', '体育健康类'],
      ['北极星自行车协会', '体育健康类'],
      ['划艇俱乐部', '体育健康类'],
      ['中华武术协会', '体育健康类'],
      ['足球协会', '体育健康类'],
      ['桌游竞技俱乐部', '体育健康类'],
      ['科技创造协会（转院级）', '学术科技类'],
      ['知识产权保护协会', '学术科技类'],
      ['数学建模协会', '学术科技类'],
      ['动漫技术与游戏开发协会', '学术科技类'],
      ['长江传媒中心', '学术科技类'],
      ['法学辩论社', '学术科技类'],
      ['法学社', '学术科技类'],
    ]

  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})