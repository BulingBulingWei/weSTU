// pages/Life/computer/computer.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:[
      "1. 上课安排的上机(J1)是免费的",
      "2. 每人每学期在J1有20小时免费上机时间,超时后直接扣校园卡收费(具体价格不清楚，可能是3元/h)",
      "3. 非课程安排去J1机房是不允许携带电脑的",
      "4. J13(计算机学院楼)上机是免费的，1楼与3楼机房只要开门并且近期无考试是允许所有同学入内的，可以携带自己的笔记本电脑"
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})