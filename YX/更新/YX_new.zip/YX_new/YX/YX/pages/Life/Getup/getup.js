// pages/Life/getup/getup.js
Page({

  /**
   * Page initial data
   */
  data: {
    data: [
      "1. 学校无早自习、跑操等，早上第一节课为八点",
      "2. 学校也无晚自习，但是晚上十一点半之后书院会有门禁，同时需要登记",
      "3.早起的小伙伴要注意轻手轻脚哦，不要影响到舍友~"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})