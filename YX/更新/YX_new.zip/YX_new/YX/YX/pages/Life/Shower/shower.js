// pages/Life/shower/shower.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "1. 敬一、明德、修远书院为公共卫浴（有隔间）需刷卡洗澡。第一次刷卡开始计费，洗完可以二次刷卡停止计费，到两元时自动停止热水，此时需再次刷卡才有热水",
      "2. 公共卫浴下午开始有热水，晚上十二点停止热水供应。目前各书院均有设置一至两间24小时供应热水的浴室",
      "3. 其他书院热水无需刷卡，24小时热水供应"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})