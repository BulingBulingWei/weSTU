// pages/DieJin/DJ_Network/dj_network.js
Page({

  /**
   * Page initial data
   */
  data: {
    data : [
      "1. 登陆校园网：\n一个账号只能绑定四台设备，在连接到校园网STU的WIFI后，在浏览器登陆1.1.1.2 接着输入自己的校园网账号就能访问网络了",
      "2. wifi套餐：学校的校园网分几种套餐，最主流的是9 RMB每月，每天包含2GB流量，如果当天2GB流量用完之后，我们还可以购买当日流量包，价格为1 RMB/1 GB。",
      "3. 校内网可以免费下载中国知网、万方等论文，图书馆电子资源极其丰富",
      "4.除了买校园网也可以在宿舍内自装宽带（自己买宽带、路由器以及拉网线），联通的宽带今年活动是660元买卡送一年宽带，然后将其中的600元按照人数平均返现给卡主号码，宿舍平摊下来平均每人100多一年。",
      "5. 录取通知书里会有一张移动电话卡，开学时学校会有许多移动工作人员摆摊激活电话卡，前期送很多话费且流量很多，可以自行选择是否使用",
      "6.由于网络带宽有限，将优先服务于教学科研，所以过渡校区是不能使用金凤BT的。"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})