// pages/NewStu/Necessary/necessary.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
    "1.文件：\n录取通知书、 团员证和入团相关档案（非共青团团员可忽略）、兵役证、户口迁移证（不办理户口迁移证可忽略）",
    "2.洗漱用品：\n  沐浴露、洗发水、洗衣液、牙膏、牙刷、漱口杯、毛巾、吹风机、衣架、夹子、盆、桶\n （以上物品可以到学校后再购置，但是由于不清楚国庆后学校是否还处于封校状态，若处于封校状态，可以在二三饭楼下卜蜂中心购置，或到东门处使用佳友超市下单小程序下单，让老板送到东门。亦可以在家购置后邮寄，亦可网购）",
    "3.生活用品：\n①床帘、蚊帐、被单、床单、被子、枕头 （建议在家购买后，清洗晒干后邮寄回学校）\n②电水壶、水杯、排插、药箱、梳子\n③饭盒、筷子、汤勺（因为疫情期间，饭堂仅收费提供一次性餐具，自带饭盒既环保又省钱）\n④换洗衣服、鞋子。\n⑤水瓶、伞、花露水等驱蚊用品（12月的汕头会有蚊子）\n",
    "4.学习用品:\n 笔、笔袋、笔记本、英语听力耳机（ELC期末考试、四六级要用到）、笔记本电脑、台式电脑、ipad等",
    "5.防疫相关：\n粤康码，返校申请，口罩，体温计",
    "6.邮寄地址：\n①校本部：\n    广东省汕头市金平区鮀江街道大学路243号汕头大学\n(学校快递会存放在近邻宝和东门快递站，到校后凭取件码取件即可)\n ②过渡校区：\n   广东省汕头市金平区鮀莲街道汕头市卫生学校 "
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
  
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})