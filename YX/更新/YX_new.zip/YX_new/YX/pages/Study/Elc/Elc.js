// pages/Study/Time/time.js
Page({

  /**
   * Page initial data
   */
  data: {
    Data0: [
      "根据不同学院不同专业情况，非英语专业学生入学后学校会进行英语分级，并参与修习学校提供的各4学分的ELC1、ELC2、ELC3、ELC4课程；艺术类学生有专门开设的ELCEA1、ELCEA2、ELCEA3；",
      "另外还有不计学分的基础级ELCF、以及自主选择进一步提升的ELC5课程。"
    ],
  },

})