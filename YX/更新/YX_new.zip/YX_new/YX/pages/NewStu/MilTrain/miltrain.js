// pages/NewStu/MilTrain/miltrain.js
Page({

  /**
   * Page initial data
   */
  data: {
    data: [
      "嘿嘿，入学没有军训哦，学校军训历来是安排在大一升大二的暑假",
      "1.	军训的时候，学校会通知大家统一购买军训服。\n2.	军训的时候，正是最热的时候，太阳猛烈，要注意做好防晒。多喝水，预防中暑，准备好纸巾或者小毛巾擦汗。\n3.	军训体力消耗大，一定要记得吃早餐。\n4.	军训的时候如有身体不适，可以随时向教官打报告，不要硬撑，一般都会备有葡萄糖，润喉糖和饮用水。\n5.	军训期间除了要上军事技能课，还需要上军事理论课，理论课需要考试（开卷考试，可以带手机）。",
    ],
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})