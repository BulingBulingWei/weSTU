// pages/Life/express/express.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "1. 邮政快递：位于学校789楼，位置较偏僻，且周末不上班，平时需正常上班时间才开门取件",
      "2. 其他快递均位于图书馆冷却房后面的近邻宝，大型及贵重物品放置在店内，其余物品放在室外储物柜，可24小时凭手机店外物品取件，店内营业时间：9：00-17：00，关注近邻宝公众号取件更方便哦",
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})