// pages/Life/Anti-epidemic/anti-epidemic.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
    "1.初次到校时候，需要扫描校门的二维码来检验返校申请是否通过。返校申请一般是学校会在学生返校前14天让学生填写的，具体要求看学校给的通知。（需要带口罩）",
    "2.学生到校后，每天都需要进行网上的健康情况开卡，网址为：http://yqfk.stu.edu.cn",
    "3.书院楼下也会有体温登记表，需要学生自行测温和登记。",
    "4. 如果返校后出现感冒和发烧等症状，需要及时报告导生，书院会根据具体情况处理。",
    "5.学校目前暂没有解封，原则上是不能出校门的，如果真的有事需要出去，关注汕头大学服务号公众号，导航栏选择汕头大学，进入外出申请页面进行申请，一般需要提前1至2天申请。（如果还要上课，还要找系主任拿请假批准然后给有课的任课老师，不然会被判逃课",
    "6.出于控制疫情的需要，学校暂时不会提供学生公共餐具，建议自带饭盒和餐具，也可直接用饭堂的一次性餐具，但是要加收1元餐盒费",
    "7.建议带口罩。"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
  
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})