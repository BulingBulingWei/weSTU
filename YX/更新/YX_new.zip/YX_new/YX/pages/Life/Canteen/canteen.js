// pages/Life/canteen/canteen.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "1. 校内共有四个餐厅：二饭，三饭，四饭，西苑餐厅",
      "2. 二饭、三饭是就餐区域是共通的，各有一个卖饮料的地方，最近两年重新装修过，看起来十分高大上，有一吧台，两边设有沙发；四饭分两层楼一楼二楼都是就餐区域，二楼还设有包厢；四饭后门还有一个单独的兰州拉面；西苑餐厅位置比较偏僻，但是室内环境不错",
      "3. 所有餐厅在星期一至星期五必须使用校园卡支付，不收现金不支持支付宝微信；周末可使用支付宝微信进行支付。",
      "4. 二三饭地理位置上靠近明德、修远、敬一、淑德书院，第四食堂靠近德馨书院和至诚书院，西苑餐厅靠近知行和思源书院，弘毅书院距离各个餐厅都差不多远",
      "5. 学校东门的美食一条街有很多饭店和小吃店"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
  
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})