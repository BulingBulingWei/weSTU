// pages/Life/traffic/traffic.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "1. 飞机:\n到达揭阳潮汕国际机场后乘坐机场大巴直达大学公交站台",
      "2. 高铁动车:\n到达厦深铁路潮汕站后于出站口乘坐181b公交车直达大学 \n到达汕头站后于出站口乘坐6路公交车或39路公交车直达大学公交站",
      "3. 汽车:火车站, 客运中心站(泰山路)可乘坐6路公交车直达大学\n中旅站(汕樟路), 华侨大厦站(长平路)可乘坐39路公交车直达大学\n汽车总站(潮汕路)可乘坐17路、39路公交车直达大学",
      "4. 从广东揭阳方向(国道206)来校新生可直接在大学站下车"
    ],
    b181:['潮汕站出发的每逢整点发车，学校出发的每逢整点发车']
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})