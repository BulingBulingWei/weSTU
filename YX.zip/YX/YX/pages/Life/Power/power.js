// pages/Life/power/power.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data:[
      "1. 宿舍无用电量限制，电费每月从一卡通中扣取",
      "2. 每月缴交电费前学校会在办公自动化通知，需保证一卡通中有足够余额，否则会扣费失败。扣费失败后需上网手动缴费，如宿舍中任一人未在规定时间内缴交电费，则第二天宿舍会断电。此时缴费后数小时才能恢复供电",
      "3. 宿舍内用禁止使用大功率电器，书院会不定期抽查宿舍大功率电器，有可能会被没收"
    ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})