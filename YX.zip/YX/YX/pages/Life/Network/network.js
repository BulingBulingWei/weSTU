// pages/Life/network/network.js
Page({

  /**
   * Page initial data
   */
  data: {
    data : [
      "1. 关于wifi：\n汕大基本实现wifi全覆盖，包括课室和宿舍，极少部分宿舍wifi信号较差。除各书院自习室及实验室，晚上12点后将连不到校园网",
      "2. 登陆校园网：\n一个账号只能绑定四台设备，在连接到校园网STU的WIFI后，在浏览器登陆1.1.1.2 接着输入自己的校园网账号就能访问网络了",
      "3. wifi套餐：学校的校园网分几种套餐，最主流的是9 RMB每月，每天包含2GB流量，如果当天2GB流量用完之后，我们还可以购买当日流量包，价格为1 RMB/1 GB。",
      "4. 宽带：目前只有至诚书院和德馨书院可以拉网线宽带",
      "5. 校内网可以免费下载中国知网、万方等论文，图书馆电子资源极其丰富",
      "6. 录取通知书里会有一张移动电话卡，开学时学校会有许多移动工作人员摆摊激活电话卡，前期送很多话费且流量很多，可以自行选择是否使用"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})