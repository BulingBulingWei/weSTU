// pages/NewStu/AntiFraud/antifraud.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "新生报到之日,骗子特别多,各种各样的骗子,大家都需要留意, 凡是涉及到钱, 不管他是你学姐还是学长, 务必慎重对待",
      "1. 寝室推销开学的时候,就会有很多穿着像“学长学姐”的狼外婆上门推销, 例如四六级资料(说是定期送之类的) 、刷鞋神器、或者其它的生活用品, 然而这些狼外婆并不一定真的是学长学姐, 直接告知不需要或者请他先出示证件。去年就有很多童鞋购买了骗子的四六级资料, 然后骗子跑路。",
      "2. 谨慎办理会员卡，在我上大一的时候就说要建游泳馆，然后推荐健身卡，现在我大四了还没有建起来游泳馆，当然健身还是不错的；另外就是理发卡，有同学交了500办理会员卡不到半年理发店跑路了，当然办卡是有优惠的，但是首先要跟学长了解一下周围理发店，另外不要一次充值特别多钱，可以选择几人用一张卡来减少风险",
      "3. 刚开学的时候,学校人比较多,也比较杂,这时候小偷就会伺机而动, 以找人、刷楼、走错寝室为借口, 发现宿舍没人, 就会拿走贵重物品, 例如手机、脑等。对于陌生人还是要确认身份, 宿舍出门或者休息要上锁。",
      "4. 以体验为名义强制消费,这种事情往往发生在万达、苏宁这些商业区域, 特别容易针对个人行动的, 当你逛街的时候, 有人会拉着你说某某品牌做活动送什么东西或者做什么体验, 当你盛情难却的时候, 正是你上当之时, 一旦你进入店里, 就会给你涂乱七八糟的东西, 然后让你掏钱。遇到这种事情, 一定要报警处理, 并且联系12315。",
      "5. 哥们,要iphone不。这是某位学长的亲身经历，在火车站或者学校周围，有一些社会小混混模样的人问, “哥们, iphoneⅩ要不 ? 便宜处理啊”。然后他告诉你这是他偷的, 然后急于销账, 所以给点就行。结果你会发现, 你买到的是个模型，别贪小便宜。另外注意以前在北门有人被强制拉到面包车推销电脑，十年前的电脑敢卖几千，千万不要因为害怕不敢拒绝，根据当时学长的帖子说拒绝购买后他们也没敢怎么样",
      "6. 注意人身安全，特别是晚上的时候，外出之后务必要把女同学送到宿舍楼下哦，这是多年来的传统！",
      "7. 注意保护好自己的账号密码，不要随意输入密码, 有时候你会收到好友突然发来的链接, 然后点进去需要qq登陆,但没有快捷登陆, 这基本上是你的朋友被盗号了, 那个网页是个钓鱼网站。如果大家的qq邮箱收到了以教务处、学生处为名义的各种邮件, 例如奖学金名单、考试成绩等等, 基本也是骗人的。点进去是个链接, 也会让你输入账号密码, 如果输入了, 请及时更改。"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})