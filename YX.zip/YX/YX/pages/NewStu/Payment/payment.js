// pages/NewStu/Payment/payment.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "1. 饭卡充值：\n可直接使用支付宝，搜索校园生活(菜单栏也有)，选择一卡通绑定校园卡以后即可缴费，充值后并不会立即到账，需要等待一两分钟刷卡消费时才会充值到校园卡",
      "2. 学费办理：\n学费缴纳按照收到的录取通知书进行操作",
      "3. 水卡充值：\n学校一卡通即为水卡，敬一、明德、修远书院需刷卡洗澡，第一次刷卡开始计费，洗完可以二次刷卡停止计费，到两元时自动停止热水，此时需再次刷卡才有热水",
      "4. 公交卡：\n手机微信搜索‘乘车码’小程序领取电子公交卡，即可乘坐公交",
      "5. 电费：\n电费按月扣费，学校每月统一在一卡通扣费，余额不足等导致扣费失败需充值后手动缴费"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
    
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})