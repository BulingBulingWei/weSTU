// pages/DieJin/DJ_Medical/dj_medical.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "1. 校医室在教学楼停车棚对面，有摔倒、感冒之类的小病可以去看。",
      "2. 生病比较严重的，可以乘坐27路车至附二院站，也可以乘坐39路车至东厦北路站前往附一",
      "3. 学校会组织办理社保，以后去校医院挂号买药相当便宜，特别是感冒药，但是有额度限制"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {

  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})