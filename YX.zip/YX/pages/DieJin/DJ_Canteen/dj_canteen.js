// pages/DieJin/DJ_Canteen/dj_canteen.js
Page({

  /**
   * Page initial data
   */
  data: {
    data:[
      "有一个三层的金香源餐厅，位于宿舍楼的后面，靠近操场的地方\n可以选择订购外卖，但需要到学校门口去拿。\n外卖的话一般本部外卖群的商家都会有配送过渡校区的，关于外卖的介绍，可以移步去小程序的【校园生活-外卖相关】进行了解。"
    ]
  },

  /**
   * Lifecycle function--Called when page load
   */
  onLoad: function (options) {

  },

  /**
   * Lifecycle function--Called when page is initially rendered
   */
  onReady: function () {

  },

  /**
   * Lifecycle function--Called when page show
   */
  onShow: function () {
  
  },

  /**
   * Lifecycle function--Called when page hide
   */
  onHide: function () {

  },

  /**
   * Lifecycle function--Called when page unload
   */
  onUnload: function () {

  },

  /**
   * Page event handler function--Called when user drop down
   */
  onPullDownRefresh: function () {

  },

  /**
   * Called when page reach bottom
   */
  onReachBottom: function () {

  },

  /**
   * Called when user click on the top right corner to share
   */
  onShareAppMessage: function () {

  }
})